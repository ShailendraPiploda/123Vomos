import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/booking_request_wiget.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/model/complete_model.dart';
import 'package:vamos/model/search_model.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class CompletedTripstScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _CompletedTripstScreen();
}

class _CompletedTripstScreen extends State<CompletedTripstScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String userIdMain = "";
  bool isLoding = false;
  bool hasData=true;
  List<CompleteModel>listBooking = new List();

  getBookingComplete() async {
    final uri = API.bookingRequest;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    loadProgress();

    if (statusCode == 200) {
      if (data["status"] == "true") {
        List list =data["data"]["data"][0]["completed_models"];



        if (list.isEmpty) {
          hasData=false;
          showDisplayAllert(
              context: this.context, isSucces: true, message: Constants.noDataAvailable);
        }

        else {
          for (int i = 0; i < list.length; i++) {
            String id = list[i]["id"].toString();
            String trackId = list[i]["trackId"].toString();
            String user_id = list[i]["user_id"].toString();
            String description = list[i]["description"].toString();
            String title = list[i]["title"].toString();
            String start_time = list[i]["start_time"].toString();
            String end_time = list[i]["end_time"].toString();
            String starting_location = list[i]["starting_location"].toString();
            String end_location = list[i]["end_location"].toString();
            String total_distance = list[i]["total_distance"].toString();
            String increase_parcent = list[i]["increase_parcent"].toString();
            String total_cost = list[i]["total_cost"].toString();
            String total_cost_old = list[i]["total_cost_old"].toString();
            String total_seat = list[i]["total_seat"].toString();
            String seat_available = list[i]["seat_available"].toString();
            String interval_time = list[i]["interval_time"].toString();
            String booking_process = list[i]["booking_process"].toString();
            String status = list[i]["status"].toString();
             String added_date = list[i]["added_date"].toString();
            String updated_date = list[i]["updated_date"].toString();
            String flexible = list[i]["flexible"].toString();
            String first_name = list[i]["user"]["first_name"].toString();
            String last_name = list[i]["user"]["last_name"].toString();
            String image = list[i]["user"]["image"].toString();
            String facebook_image = list[i]["user"]["facebook_image"].toString();
            String st = list[i]["booking_status"].toString();

            String statusBooking="";

            switch(st)
            {
              case "0":statusBooking=Constants.Pending;
              break;
              case "1":statusBooking=Constants.Paid;
              break;
              case "2":statusBooking=Constants.cancelByUser;
              break;
              case "3":statusBooking=Constants.cancelByDrive;
              break;
              case "4":statusBooking=Constants.claimAndRefund;
              break;
            }


            final rattingString = list[i]["user"]["avg_rating"];
            String ratting ="0.0";

            if(rattingString!="")
              {

                  ratting=rattingString["avg_rating"];

                  if(ratting!="null")
                    {
                      ratting ="0.0";
                    }

              }


            listBooking.add(new CompleteModel(id, trackId, user_id, title, description, start_time, end_time, starting_location, end_location, total_distance, increase_parcent, total_cost, total_cost_old, total_seat, seat_available, flexible, interval_time, booking_process, status, added_date, updated_date, first_name, last_name, image, facebook_image,statusBooking,ratting));

          }

        }
      } else {
        String dataString = data["message"].toString();
        dataString =
            dataString.substring(dataString.indexOf(":"), dataString.length)
                .replaceAll(":", "").replaceAll("{", "").replaceAll("}", "")
                .replaceAll("[", "")
                .replaceAll("]", "");
        showDisplayAllert(
            context: context, isSucces: false, message: dataString);
      }
    } else {
      showDisplayAllert(
          context: context, isSucces: false, message: (data["message"]));
    }
    setState(() {

    });
  }

  @override
  void initState() {
    loadProgress();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      getBookingComplete();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.completedTrips,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: screenSize.width,
        height: screenSize.height,
        child: Stack(children: <Widget>[
          ListView.builder(
            itemCount: listBooking.length,
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index) {
              String img = listBooking[index].image;
              return CompletedTripsWidget(
                bookingStatus:  listBooking[index].booking_status,
                  imageUrl:img==""?listBooking[index].facebook_image:API.baseProfileImageUrl+listBooking[index].image,
                  customerName:listBooking[index].first_name+" "+listBooking[index].last_name,
                  locationFrom: listBooking[index].starting_location,
                  locationTo: listBooking[index].end_location,
                  rating: listBooking[index].ratting,
                  dateTime: listBooking[index].start_time,
                  noOfSeatToBook:listBooking[index].total_seat,
                  paidAmount: listBooking[index].total_cost);
            },
          ),
          isLoding? Container(
            // color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),

          !hasData? Container(
            color: Colors.white,
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child:Text(Constants.noDataAvailable,style: AppTheme.textStyle.alertText.copyWith(color: Colors.black),)),

          ):SizedBox(height: 0.0,),
        ],),
      ),
    );
  }

  void loadProgress() {
    setState(() {
      isLoding = !isLoding;
    });
  }

}
