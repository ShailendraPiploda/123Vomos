import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class PaymentDetailsScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState()=>new _PaymentDetailsScreen();

}
class _PaymentDetailsScreen extends State<PaymentDetailsScreen>{

  final GlobalKey<ScaffoldState> _scaffoldKey =new GlobalKey<ScaffoldState>();
  TextEditingController accountHolderNameController = new TextEditingController();
  TextEditingController idNumberController = new TextEditingController();
  TextEditingController nameOfBankController = new TextEditingController();
  TextEditingController accountNumberController = new TextEditingController();
  TextEditingController typeOfAccountController = new TextEditingController();
  TextEditingController _infoDobController = new TextEditingController();
  String bankDetailsID="";
  int typePosition=0;
  Item accountType;
  var _loginFormKey = GlobalKey<FormState>();
  String _groupValue = "Male",userIdMain="";
  bool isLoading=false;
  List<Item> accountTypeList = List();
  saveBankDetails() async
  {

    String accountTypeCode="2";
    if(accountType.name==Constants.saving)
      {
        accountTypeCode="1";
      }

    final uri = API.saveBankDetails;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,
      "bank_details_id":bankDetailsID,
      "owner_name":accountHolderNameController.text.toString(),
      "banknote_number": idNumberController.text.toString(),
      "bank_name":nameOfBankController.text.toString(),
      "account_number": accountNumberController.text.toString(),
      "account_type": accountTypeCode,

    };

    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    progressLoad();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:context,isSucces: true,message:data["message"]);

      } else {


        String dataString = data["message"].toString();
       // dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {

      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  getBankDetails() async
  {

    final uri = API.getBankDetails;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,

    };
    final encoding = Encoding.getByName('utf-8');
    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    progressLoad();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        final subData =data["data"]["data"];

        bankDetailsID=subData["id"].toString();
        accountHolderNameController.text=subData["owner_name"].toString();
        idNumberController.text=subData["banknote_number"].toString();
        nameOfBankController.text=subData["bank_name"].toString();
        accountNumberController.text=subData["account_number"].toString();
        int type=int.parse(subData["account_type"].toString());

        if(type==1)
        {

          typePosition=0;
        }
        else{
          typePosition=1;
        }

        setState(() {

        });


      } else {


        String dataString = data["message"].toString();
      // dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {

      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }


  @override
  void initState() {
    accountTypeList.add(new Item(Constants.saving));
    accountTypeList.add(new Item(Constants.current));
    progressLoad();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      getBankDetails();
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.paymentDetails,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: double.maxFinite,
        height: double.maxFinite,
        child:Stack(children: <Widget>[
          SingleChildScrollView(
            child:    Column(children: <Widget>[
              SizedBox(height: AppSize.mediumLarge,),
              Form(
                key: _loginFormKey,
                child: Container(
                  child: Column(children: <Widget>[

                    Container(
                      padding: EdgeInsets.all(10.0),
                      width:  SizeConfig.widthMultiplier*90,
                      child: Text(Constants.paymentDetailsSubText,style: AppTheme.textStyle.lightText.copyWith(color: Colors.black,fontSize: AppFontSize.s20),textAlign: TextAlign.start,),
                    ),

                    Container(
                      padding: EdgeInsets.all(10.0),
                      width:  SizeConfig.widthMultiplier*90,
                      child: Text(Constants.paymentDetailsinfo,style: AppTheme.textStyle.lightText.copyWith(color: Colors.black,fontSize: AppFontSize.s14),textAlign: TextAlign.justify,),
                    ),

                    SizedBox(height: AppSize.medium,),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),

                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: accountHolderNameController,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.accountHolderName,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                            FontAwesomeIcons.user,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),

                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: idNumberController,
                        keyboardType: TextInputType.number,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.idNumber,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                            FontAwesomeIcons.idCard,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),

                      child: TextFormField(
                        validator: (String value) {

                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: nameOfBankController,
                        keyboardType: TextInputType.emailAddress,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.nameOfBank,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                            Icons.account_balance,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),

                      child: TextFormField(
                        validator: (String value) {

                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: accountNumberController,
                        keyboardType: TextInputType.number,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.accountNumber,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                            Icons.format_list_numbered,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(

                      margin: EdgeInsets.only(
                          top:2.0*SizeConfig.heightMultiplier,
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(
                              width: 1.0, color: Colors.grey[200])),
                      child: Row(
                        children: <Widget>[
                          SizedBox(width: 1.0,),
                          Container(
                            width:AppFontSize.textIcon ,
                            child: Icon(
                              Icons.merge_type,
                              color: Colors.black,
                              size:AppFontSize.textIcon,
                            ),
                          ),
                          SizedBox(width: 5.0,),
                          Container(
                            width: SizeConfig.widthMultiplier*75,
                            child: DropdownButton<Item>(
                              isExpanded:true,
                              hint: Text(Constants.accountType),
                              value: accountTypeList[typePosition],
                              onChanged: (Item Value) {
                                setState(() {
                                  accountType = Value;
                                  if(accountType.name==Constants.saving)
                                    {
                                      typePosition=0;
                                    }
                                  else{
                                    typePosition=1;
                                  }
                                  print(Value.name);
                                });
                              },
                              underline: SizedBox(
                                width: 1.0,
                              ),
                              items: accountTypeList.map((Item user) {
                                return DropdownMenuItem<Item>(
                                  value: user,
                                  child: Row(
                                    children: <Widget>[
                                      Container(
                                        child: Expanded(
                                          child: Text(
                                            user.name,
                                            style: TextStyle(color: Colors.black,fontSize: AppFontSize.s14,),
                                            maxLines: 2,

                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),






                    SizedBox(height: AppSize.medium,),

                    CustomRoundButtonWidget(
                      title: Constants.update,
                      callback: () {

                        if(_loginFormKey.currentState.validate())
                          {
                            progressLoad();
                            saveBankDetails();
                          }
                        //AppRoutes.replace(context, LoginScreen());
                      },
                    ),

                    SizedBox(height: AppSize.medium,),

                    Container(
                      margin: EdgeInsets.all(10.0),
                      child: Text(Constants.paymentDetailsTerms,style: TextStyle(color: Colors.black,fontSize: AppFontSize.s12),),
                    ),
                    SizedBox(height: AppSize.large,),



                  ],),
                ),
              ),


            ],),
          ),
          isLoading?Container(
              color: Colors.black.withOpacity(0.5),
              child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),))):
          SizedBox(width: 0.0,),
        ],),
      ),
    );
  }



  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }
}
class Item {
  const Item(this.name);

  final String name;

}