import 'package:flutter/material.dart';
import 'package:vamos/components/custom_round_border_button.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/round_border_button.dart';
import 'package:vamos/components/round_white_border_button.dart';
import 'package:vamos/screens/signup_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

import 'login_screen.dart';

class WelcomeScreeen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _WelcomeScreeen();

}

class _WelcomeScreeen extends State<WelcomeScreeen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  double _logoPadding = AppSize.xxL;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        key: _scaffoldKey,
        backgroundColor: Colors.white,
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: ExactAssetImage(Assets.banner),
                fit: BoxFit.cover
            )
        ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[

              SizedBox(height: SizeConfig.heightMultiplier*30,),

              SizedBox(height: AppSize.xxL,),

            Container(

              margin: EdgeInsets.only(right:SizeConfig.widthMultiplier*2,left: SizeConfig.widthMultiplier*2),


              child:Column(children: <Widget>[
                Image(
                   // color: Colors.white,
                    fit: BoxFit.contain,
                    image: new AssetImage(Assets.app_logo,)),


                SizedBox(height: AppSize.mediumLarge,),
                Text(
                  Constants.appDialog,
                  textAlign: TextAlign.center,
                  style: AppTheme.textStyle.heading1),
              ],)
            ),





         SizedBox(height: AppSize.xxL,),

            Container(
              width:  SizeConfig.widthMultiplier*70.0,
              child: RoundBorderButtonWidget(
                buttonWidth: SizeConfig.widthMultiplier*100.0,
                title: Constants.signUp,
                callback: (){
                  AppRoutes.goto(context, SignUpScreen());
                },
              ),
            ),
              SizedBox(height: AppSize.large,),
            Container(
              width:  SizeConfig.widthMultiplier*70.0,
              child: RoundWhiteBorderButtonWidget(
                buttonWidth: SizeConfig.widthMultiplier*100.0,
                title: Constants.logIn,
                callback: (){
                  AppRoutes.goto(context, LoginScreen());
                },
              ),
            ),


            SizedBox(height: AppSize.medium,),

          ],),
        ),
      ),
    );
  }


}


