import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/booking_request_wiget.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/post_trips_wiget.dart';
import 'package:vamos/model/post_list_model.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class PostedTripsScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _PostedTripsScreen();
}

class _PostedTripsScreen extends State<PostedTripsScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
String userIdMain="";
List<PostListModel> listTrip = new List<PostListModel>();
bool isLoading=false;
bool isDataFound=true;

  getTrip() async {

    final uri = API.gettrip;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

   progressLoad();
    if (statusCode == 200) {
      if (data["status"] == "true") {

        if(data["data"]["data"]=="null")
          {
            isDataFound=false;
            showDisplayAllert(context:this.context,isSucces: false,message:data["message"]);
          }

        else{

          List list = data["data"]["data"]["trip"];

          for(int i=0; i<list.length;i++){

            String id = list[i]["id"].toString();
            String trackId = list[i]["trackId"].toString();
            String user_id = list[i]["user_id"].toString();
            String title = list[i]["title"].toString();
            String description = list[i]["description"].toString();
            String start_time = list[i]["start_time"].toString();
            String end_time = list[i]["end_time"].toString();
            String starting_location = list[i]["starting_location"].toString();
            String end_location = list[i]["end_location"].toString();
            String total_distance = list[i]["total_distance"].toString();
            String increase_parcent = list[i]["increase_parcent"].toString();
            String total_cost = list[i]["total_cost"].toString();
            String total_cost_old = list[i]["total_cost_old"].toString();
            String total_seat = list[i]["total_seat"].toString();
            String seat_available = list[i]["seat_available"].toString();
            String flexible = list[i]["flexible"].toString();
            String interval_time = list[i]["interval_time"].toString();
            String booking_process = list[i]["booking_process"].toString();
            String status = list[i]["status"].toString();
            String added_date = list[i]["added_date"].toString();
            String updated_date = list[i]["updated_date"].toString();

            listTrip.add(new PostListModel(id, trackId, user_id, title, description, start_time, end_time, starting_location, end_location, total_distance, increase_parcent, total_cost, total_cost_old, total_seat, seat_available, flexible, interval_time, booking_process, status, added_date, updated_date));


          }
          setState(() {


            listTrip;
          });
        }



      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

    setState(() {

    });

  }
  deleteTrip(String id,int index) async {

    final uri = API.deleteTrip;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    print(id);
    Map<String, dynamic> body = {
      "post_id": id,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    progressLoad();
    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:this.context,isSucces: true,message:data["message"]);
        listTrip.removeAt(index);
        setState(() {

        });


      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }


  @override
  void initState() {
    progressLoad();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      getTrip();

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.postTrips,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: screenSize.width,
        height: screenSize.height,
        child: Stack(children: <Widget>[

         ListView.builder(
            itemCount: listTrip.length,
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index) {
              return PostTripsWidget(
                  id: listTrip[index].id,
                  locationFrom: listTrip[index].starting_location,
                  locationTo:listTrip[index].end_location ,
                  totalSeats: listTrip[index].total_seat,
                  dateTime1: listTrip[index].start_time,
                  dateTime2: listTrip[index].end_time,
                  pricePerSeat: listTrip[index].total_cost,
              onTap: (){
                     progressLoad();
                    deleteTrip( listTrip[index].id,index);

              },);
            },
          ),

          isLoading? Container(
           // color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),
          !isDataFound? Container(
            color: Colors.white,
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child:Text(Constants.noDataAvailable,style: AppTheme.textStyle.alertText.copyWith(color: Colors.black),)),

          ):SizedBox(height: 0.0,),
        ],),
      ),
    );
  }

  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }
}
