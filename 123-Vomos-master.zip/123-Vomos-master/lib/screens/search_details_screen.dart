import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/seat_widget.dart';
import 'package:vamos/model/trip_detail_location_model.dart';
import 'package:vamos/screens/booking_payment_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class SearchTripDetailsScreen extends StatefulWidget {
  String postId,locationAName,locationBName,dateTime,price;


  SearchTripDetailsScreen({this.postId, this.locationAName, this.locationBName,this.dateTime,this.price});

  @override
  State<StatefulWidget> createState() => new _SearchTripDetailsScreen();
}

class _SearchTripDetailsScreen extends State<SearchTripDetailsScreen> {
  bool isDataAvalable=false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  bool termAndConditionValue = false;
  CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng( 4.624335, -74.063644),
    zoom: 20.0,
  );

  List rattingList = new List();
  String userIdMain="";
  String totalstop="", driverAge="",driverImage="",driverName="",vehicalModel="",vehicalColor="",startLocation="",endLocation="",timeAdded="",startTime="",endTime="",
      totalCost="", totalDuration="",tripDetails="",totalSeat="0",seat_available="0",identity_document_verified="0",email_varified="0";
  double ratting = 0.0;
  bool isLoading=false;
  String  kGoogleApiKey = API.googleMapApiKey;
  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: API.googleMapApiKey);
  Set<Polyline> _polylines = {};
  List<LatLng> polylineCoordinates = [];
  PolylinePoints polylinePoints = PolylinePoints();
  List<TripDetailLocationModel>listLocation= new List();
  Set<Marker> markers = Set();
  Completer<GoogleMapController> _controller = Completer();
  TextEditingController seatController = new TextEditingController();


  @override
  void initState() {
    progressLoad();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      getTrip();

    });
  }

  checktrip() async {

    final uri = API.checktrip;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,
      "location_a_name": widget.locationAName,
      "location_b_name": widget.locationBName,
      "trip_master_id": widget.postId,
      "departure_datetime": widget.dateTime,
      "requested_seat": seatController.text,
      "price": widget.price,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    print(body.toString());
    int statusCode = response.statusCode;
    print(response.body);
    final data = json.decode(response.body);


    print(response.body);

    progressLoad();
    if (statusCode == 200) {
      if (data["status"] == "true") {
      //  AppRoutes.replace(context, BookingPaymentScreen());
        if(data["data"]["data"]=="null")
        {
          showDisplayAllert(context:this.context,isSucces: false,message:data["message"]);
        }

        else{
          final list =data["data"]["data"];

          String final_price,price,total_seat,redirectUrl,msg,booking_process,referenceCode,signature,referencia,flag,uuid,prueba;

          final_price= list[0]["final_price"].toString();
          price= list[0]["price"].toString();
          total_seat= list[0]["total_seat"].toString();
          redirectUrl= list[0]["redirectUrl"].toString();
          msg= list[0]["msg"].toString();
          booking_process= list[0]["booking_process"].toString();
          signature= list[0]["signature"].toString();
          referencia= list[0]["referencia"].toString();
          flag= list[0]["flag"].toString();
          referenceCode= list[0]["referenceCode"].toString();
          uuid=list[0]["pagoagil_uuid"]["value"].toString();
         prueba=list[0]["pagoagil_mode"]["value"].toString();

          AppRoutes.replace(context, BookingPaymentScreen(final_price,price,total_seat,redirectUrl,msg,booking_process,referenceCode,signature,referencia,flag,uuid,prueba));
        }



      } else {

        String dataString = data["message"].toString();
      //  dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  getTrip() async {

    final uri = API.getAllTripDetails;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,
      "post_id": widget.postId,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    progressLoad();
    if (statusCode == 200) {
      if (data["status"] == "true") {

        if(data["data"]["data"]=="null")
        {
          showDisplayAllert(context:this.context,isSucces: false,message:data["message"]);
        }

        else{
          final tripData = data["data"]["data"]["trip"];
          setState(() {

            final tripData = data["data"]["data"]["trip"];
            final userData = data["data"]["data"]["userdetail"];
            driverName = userData["first_name"].toString() + " "+userData["last_name"].toString() ;
            driverAge = userData["birth_year"].toString();
            driverImage = userData["image"].toString();
            email_varified = userData["email_varified"].toString();
            identity_document_verified = userData["identity_document_verified"].toString();

            seat_available = tripData["seat_available"].toString();
            vehicalColor = data["data"]["data"]["color"].toString();
            vehicalModel = data["data"]["data"]["model_no"].toString();
            totalstop = data["data"]["data"]["stop"].toString();

            tripDetails = tripData["description"].toString();
            startTime = tripData["start_time"].toString();
            endTime  = tripData["end_time"].toString();
            startLocation = tripData["starting_location"].toString();
            endLocation = tripData["end_location"].toString();
            totalCost = tripData["total_cost"].toString();
            totalSeat = tripData["total_seat"].toString();
            timeAdded = tripData["added_date"].toString();

            String rattingString = data["data"]["data"]["rating"]["avg_rating"];

            String avg_rating="0.0";
            if(rattingString!=null && rattingString!="")
            {
              avg_rating=rattingString;
            }
            else{
              avg_rating="0.0";
            }

            ratting=double.parse(avg_rating);


             rattingList = data["data"]["data"]["rating_master"];


            final date1 = DateTime.parse(startTime);
            final date2 = DateTime.parse(endTime);
            final hour = date2.difference(date1).inHours;
            final days = date2.difference(date1).inDays;
            final minutes = date2.difference(date1).inMinutes;




            if(days!=0)
            {
              totalDuration = totalDuration+ days.toString()+" day ";
            }

            if(hour!=0)
            {
              totalDuration = totalDuration+hour.toString()+" hours ";
            }

            if(minutes!=0)
            {
              if(hour!=0){
                int m = minutes%60;

                if(m!=0)
                {
                  totalDuration = totalDuration+m.toString()+" minute";
                }

              }
              else{
                totalDuration = totalDuration+minutes.toString()+" minute";
              }

            }





          });




          List list =  data["data"]["data"]["location"];

          for(int i =0; i<list.length;i++){
            String id = list[i]["id"].toString();
            String trackId = list[i]["trackId "].toString();
            String trip_id = list[i]["trip_id"].toString();
            String location_a_name = list[i]["location_a_name"].toString();
            String location_a_lat = list[i]["location_a_lat"].toString();
            String location_a_long = list[i]["location_a_long"].toString();
            String location_b_name = list[i]["location_b_name"].toString();
            String location_b_lat = list[i]["location_b_lat"].toString();
            String location_b_long = list[i]["location_b_long"].toString();
            String departure_datetime = list[i]["departure_datetime"].toString();
            String arrival_datetime = list[i]["arrival_datetime"].toString();
            String halt_time = list[i]["halt_time"].toString();
            String total_distance = list[i]["total_distance"].toString();
            String actual_price = list[i]["actual_price"].toString();
            String total_price = list[i]["total_price"].toString();
            String total_booked = list[i]["total_booked"].toString();
            String duration = list[i]["duration"].toString();


            listLocation.add(new TripDetailLocationModel(id, trackId, trip_id, location_a_name, location_a_lat, location_a_long, location_b_name, location_b_lat, location_b_long, departure_datetime, arrival_datetime, halt_time, total_distance, actual_price, total_price, total_booked, duration));

          }
          setState(() {
            isDataAvalable=true;
          });
          createMarkerForMap();
          setPolylines();

        }



      } else {

        String dataString = data["message"].toString();
         showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  setPolylines() async {

    for(int i=0;i<listLocation.length;i++)
    {

      List<PointLatLng> result = await
      polylinePoints?.getRouteBetweenCoordinates(
        API.googleMapApiKey,
        double.parse(listLocation[i].location_a_lat),
        double.parse(listLocation[i].location_a_long),
        double.parse(listLocation[i].location_b_lat),
        double.parse(listLocation[i].location_b_long),);
      if(result.isNotEmpty){
        // loop through all PointLatLng points and convert them
        // to a list of LatLng, required by the Polyline
        result.forEach((PointLatLng point){
          polylineCoordinates.add(
              LatLng(point.latitude, point.longitude));
        });
      }
    }


    setState(() {
      // create a Polyline instance
      // with an id, an RGB color and the list of LatLng pairs
      Polyline polyline = Polyline(width: 2, visible: true,
          polylineId: PolylineId("dfarafa"),
          color: Colors.blue,
          points: polylineCoordinates
      );

      // add the constructed polyline as a set of points
      // to the polyline set, which will eventually
      // end up showing up on the map
      _polylines.add(polyline);
    });


  }


  createMarkerForMap(){



    setState(() {

      for(int i=0;i<listLocation.length;i++)
      {
        markers.add(  Marker(
            markerId: MarkerId(i.toString()),
            position: LatLng( double.parse(listLocation[i].location_a_lat), double.parse(listLocation[i].location_a_long)))) ;

        if(i==listLocation.length-1)
        {

          markers.add(  Marker(
              markerId: MarkerId("last point"),
              position: LatLng( double.parse(listLocation[i].location_b_lat), double.parse(listLocation[i].location_b_long)))) ;

        }
      }

    });

  }

  void onMapCreated(GoogleMapController controller) {


    Future.delayed(Duration(seconds: 1), () {

      double southwestLat=double.parse(listLocation[listLocation.length-1].location_b_lat);
      double southwestLong=double.parse(listLocation[listLocation.length-1].location_b_long);
      double northetLat=double.parse(listLocation[0].location_a_lat);
      double northetLong=double.parse(listLocation[0].location_a_long);


      if(southwestLat<=northetLat)
      {
        controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( southwest : LatLng(southwestLat,southwestLong), northeast:   LatLng(northetLat, northetLong) ), 30));

      }
      else{
        controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( northeast : LatLng(southwestLat,southwestLong), southwest: LatLng(northetLat, northetLong) ), 30));

      }


     // controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( southwest : LatLng(southwestLat,southwestLong), northeast:   LatLng(northetLat, northetLong) ), 30));
    //  controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( southwest:LatLng(-4.2316872,-82.1243666), northeast:  LatLng(16.0571269,-66.8511907), ), 20));



      // Future.delayed(Duration(seconds: 6));
      _controller.complete(controller);
      setState(() {

      });
    });



  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.tripDetail,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        alignment: Alignment.center,
        color: Colors.white,
        width: double.maxFinite,
        height: double.maxFinite,
        child:Stack(children: <Widget>[
          SingleChildScrollView(
            child: Container(
              margin: EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: AppSize.medium,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        width: SizeConfig.widthMultiplier * 45,
                        child: Row(children: <Widget>[
                          Icon(Icons.location_on,color: AppTheme.primaryColor,),
                          Text(Constants.location,
                              textAlign: TextAlign.start,
                              style: AppTheme.textStyle.heading1.copyWith(
                                  color: AppTheme.primaryColor, fontSize: AppFontSize.s16))
                        ],),
                      ),
                      Container(
                          width: SizeConfig.widthMultiplier * 45,
                          child: Row(children: <Widget>[
                            Icon(Icons.calendar_today,color: AppTheme.primaryColor,),
                            Text(Constants.dateAndTime,
                                textAlign: TextAlign.start,
                                style: AppTheme.textStyle.heading1.copyWith(
                                    color: AppTheme.primaryColor, fontSize: AppFontSize.s16)),
                          ],)
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(left: 10.0),
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(widget.locationAName,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 10.0),
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(timeAdded,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                          width: SizeConfig.widthMultiplier*45,
                          child:  Icon(Icons.arrow_downward,color: Colors.grey,size: AppSize.smallMedium,)
                      ),

                    ],
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(left: 10.0),
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(widget.locationBName,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                      Container(
                        height: AppSize.medium,
                        width: SizeConfig.widthMultiplier * 23,
                        child:  ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: int.parse(seat_available),
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            return  SeatWidget();
                          },
                        ),),

                      Container(
                        width: SizeConfig.widthMultiplier * 22,
                        child: Text(totalstop + Constants.stop,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                    ],
                  ),


                  SizedBox(
                    height: AppSize.small,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                          width: SizeConfig.widthMultiplier * 45,
                          child:Row(children: <Widget>[
                            Icon(Icons.directions_run,color: AppTheme.primaryColor,),
                            Text(Constants.start,
                                textAlign: TextAlign.start,
                                style: AppTheme.textStyle.heading1.copyWith(
                                    color:AppTheme.primaryColor, fontSize: AppFontSize.s16)),
                          ],)
                      ),
                      Container(
                        width: SizeConfig.widthMultiplier * 45,
                        child: Row(children: <Widget>[
                          Icon(Icons.directions_walk,color: AppTheme.primaryColor,),
                          Text(Constants.end,
                              textAlign: TextAlign.start,
                              style: AppTheme.textStyle.heading1.copyWith(
                                  color:AppTheme.primaryColor, fontSize: AppFontSize.s16))
                        ],),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(left: 10.0),
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(startTime,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 10.0),
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(endTime,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Container(
                    width: SizeConfig.widthMultiplier * 90,
                    child: Text("( "+totalDuration+" )",
                        textAlign: TextAlign.start,
                        style: AppTheme.textStyle.lightText.copyWith(
                            color: Colors.grey, fontSize: AppFontSize.s14)),
                  ),
                  SizedBox(
                    height: AppSize.smallMedium,
                  ),
                  Container(
                    width: SizeConfig.widthMultiplier * 90,
                    height: SizeConfig.heightMultiplier*30,
                    child:isDataAvalable?  GoogleMap(
                      gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>[
                        new Factory<OneSequenceGestureRecognizer>(() => new EagerGestureRecognizer(),),
                      ].toSet(),
                      scrollGesturesEnabled: true,
                      myLocationButtonEnabled: true,
                      myLocationEnabled: true,
                      compassEnabled: true,
                      polylines: _polylines,
                      mapToolbarEnabled: true,
                      rotateGesturesEnabled: true,
                      zoomGesturesEnabled:true,
                      mapType: MapType.normal,
                      markers: markers,
                      initialCameraPosition: _kGooglePlex,
                      onMapCreated:(GoogleMapController controller){

                        onMapCreated(controller);
                      },
                    ):SizedBox(height: 0.0,),),

                  SizedBox(
                    height: AppSize.smallMedium,
                  ),
                  Container(
                    width: double.maxFinite,
                    margin: EdgeInsets.only(
                        left:4.0*SizeConfig.widthMultiplier,
                        right:4.0*SizeConfig.widthMultiplier),
                    padding: EdgeInsets.only(
                        left:2.0*SizeConfig.widthMultiplier,
                        right:2.0*SizeConfig.widthMultiplier),
                    decoration:  BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(width: 1.0,color: Colors.grey[200])
                    ),

                    child: TextFormField(
                      controller: seatController,
                      validator: (String value) {
                        return FieldValidator.validateEmptyCheck(value);
                      },
                      keyboardType: TextInputType.number,
                      textCapitalization: TextCapitalization.words,
                      style: TextStyle(
                          fontFamily: "WorkSansSemiBold",
                          fontSize: 16.0,
                          color: Colors.black),
                      decoration: InputDecoration(
                        labelText: Constants.howManySeatesDo,
                        labelStyle: TextStyle(
                            color: Colors.grey,fontSize: AppFontSize.textHint),
                        border: InputBorder.none,
                        icon: Icon(
                          Icons.event_seat,
                          color: AppTheme.primaryColor,
                          size:AppFontSize.textIcon,
                        ),
                      ),
                    ),
                  ),

                  SizedBox(
                    height: AppSize.medium,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Checkbox(
                        value: termAndConditionValue,
                        activeColor: AppTheme.accentColor,
                        onChanged: (bool value) {
                          setState(() {
                            termAndConditionValue = value;
                          });
                        },
                      ),
                      Expanded(
                        child: Text(
                          Constants.acceptTheGeneralCondition,
                          style: TextStyle(
                            fontFamily: "WorkSansSemiBold",color: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: AppSize.smallMedium,
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[

                      Container(
                        width: SizeConfig.widthMultiplier * 35,
                        child: CustomRoundButtonWidget(
                          isButtonColorReverse: true,
                          buttonWidth:  SizeConfig.widthMultiplier * 35,
                          title: Constants.reserve,
                          callback: () {

                            if(seatController.text=="")
                              {
                                showDisplayAllert(context: context,isSucces: false,message: Constants.enterSeat);

                              }
                            else{
                              if(int.parse(seat_available)>=int.parse(seatController.text.toString()))
                              {
                                if(termAndConditionValue)
                                {
                                  progressLoad();
                                  checktrip();
                                  //    AppRoutes.replace(context, BookingPaymentScreen());
                                }
                                else{
                                  showDisplayAllert(context: context,isSucces: false,message: Constants.acceptReserverCondition);
                                }

                              }
                              else{
                                showDisplayAllert(context: context,isSucces: false,message: Constants.onlyFreeSeat+seat_available);

                              }
                            }




                          },
                        ),
                      ),

                      Container(
                        padding: EdgeInsets.only(right: 10.0),
                        width: SizeConfig.widthMultiplier * 55,
                        child: Text(Constants.currancy + widget.price+"/Seat",
                            textAlign: TextAlign.end,
                            style: AppTheme.textStyle.heading1.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                    ],),

                  SizedBox(
                    height: AppSize.smallMedium,
                  ),
                  Container(
                    width: double.maxFinite,
                    child: Text(Constants.driverDetails,
                        textAlign: TextAlign.start,
                        style: AppTheme.textStyle.heading1.copyWith(
                            color: AppTheme.primaryColor, fontSize: AppFontSize.s16)),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                          width: SizeConfig.widthMultiplier * 60,
                          child: Row(
                            children: <Widget>[
                              Card(
                                shape: CircleBorder(side: BorderSide(
                                    color: Colors.grey, width: 0.5
                                )),
                                elevation: 12.0,
                                child:   Material(
                                  elevation: 4.0,
                                  shape: CircleBorder(),
                                  clipBehavior: Clip.hardEdge,
                                  color: Colors.transparent,
                                  child:Container(
                                    child: FadeInImage.assetNetwork(placeholder: Assets.avtar,image: API.baseProfileImageUrl+driverImage,fit: BoxFit.cover,),
                                    // fit: BoxFit.cover,
                                    width: SizeConfig.widthMultiplier*15,
                                    height: SizeConfig.widthMultiplier*15,

                                  ),
                                ),
                              ),

                              SizedBox(width: AppSize.medium,),
                              Container(
                                width: SizeConfig.widthMultiplier * 35,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    //  SizedBox(height: AppSize.large,),
                                    Text(
                                      driverName,
                                      style: AppTheme.textStyle.heading1
                                          .copyWith(
                                          color: Colors.grey,
                                          fontSize: AppFontSize.s14),
                                    ),
                                    Row(children: <Widget>[
                                      RatingBar(
                                          itemSize: 20.0,
                                          initialRating: ratting,
                                          minRating: 1,
                                          direction: Axis.horizontal,
                                          allowHalfRating: true,
                                          itemCount: 5,
                                          itemBuilder: (context, _) => Icon(
                                            Icons.star,
                                            color: AppTheme.accentColor,
                                          )),


                                      Text("(${rattingList.length})",
                                        style: AppTheme.textStyle.lightText
                                            .copyWith(
                                            color: Colors.grey,
                                            fontSize: AppFontSize.s14),),
                                    ],),
                                    SizedBox(
                                      height: AppSize.extraSmall,
                                    ),


                                    // SizedBox(height: AppSize.small,),
                                  ],
                                ),
                              )
                            ],
                          )),
                      Container(
                        width: SizeConfig.widthMultiplier * 30,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                            Container(
                              child: Text(
                                Constants.idVerified,
                                style: AppTheme.textStyle.lightHeading.copyWith(
                                    color: AppTheme.primaryColor,
                                    fontSize: AppFontSize.s16),
                              ),
                            ),
                            SizedBox(
                              height: AppSize.extraSmall,
                            ),
                            SizedBox(
                              height: AppSize.extraSmall,
                            ),
                            Container(
                              width: SizeConfig.widthMultiplier * 30,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.end,

                                children: <Widget>[
                                  Icon(
                                    Icons.description,
                                    color: identity_document_verified=="1"?AppTheme.primaryColor:Colors.grey,
                                    size: AppSize.medium,
                                  ),
                                  Icon(
                                    identity_document_verified=="1"?Icons.check:Icons.clear,
                                    color: identity_document_verified=="1"? AppTheme.primaryColor:Colors.grey,
                                    size: AppSize.medium,
                                  ),
                                  SizedBox(
                                    width: AppSize.extraSmall,
                                  ),
                                  Icon(
                                    Icons.email,
                                    color: email_varified=="1"?AppTheme.primaryColor:Colors.grey,
                                    size: AppSize.medium,
                                  ),
                                  Icon(
                                    email_varified=="1"? Icons.check:Icons.clear,
                                    color: email_varified=="1"?AppTheme.primaryColor:Colors.grey,
                                    size: AppSize.medium,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: AppSize.smallMedium,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                          width: SizeConfig.widthMultiplier * 45,
                          child: Row(children: <Widget>[
                            Icon(Icons.directions_car,color:AppTheme.primaryColor ,),
                            Text(Constants.vehical,
                                textAlign: TextAlign.start,
                                style: AppTheme.textStyle.heading1.copyWith(
                                    color:AppTheme.primaryColor, fontSize: AppFontSize.s16)),
                          ],)
                      ),
                      Container(
                          width: SizeConfig.widthMultiplier * 45,
                          child:Row(children: <Widget>[
                            Icon(Icons.color_lens,color: AppTheme.primaryColor,),
                            Text(Constants.color,
                                textAlign: TextAlign.start,
                                style: AppTheme.textStyle.heading1.copyWith(
                                    color: AppTheme.primaryColor, fontSize: AppFontSize.s16)),
                          ],)
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(left: 10.0),
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(vehicalModel,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                      Container(
                        width: SizeConfig.widthMultiplier * 45,
                        child: Text(vehicalColor,
                            textAlign: TextAlign.start,
                            style: AppTheme.textStyle.lightText.copyWith(
                                color: Colors.grey, fontSize: AppFontSize.s14)),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppSize.medium,
                  ),
                  Container(
                    width: double.maxFinite,
                    child: Text(Constants.detailsOfTheTrips,
                        textAlign: TextAlign.start,
                        style: AppTheme.textStyle.heading1.copyWith(
                            color: AppTheme.primaryColor, fontSize: AppFontSize.s16)),
                  ),
                  SizedBox(
                    height: AppSize.extraSmall,
                  ),
                  Container(
                    width: double.maxFinite,
                    child: Text(tripDetails,
                        textAlign: TextAlign.start,
                        style: AppTheme.textStyle.lightText.copyWith(
                            color: Colors.grey, fontSize: AppFontSize.s14)),
                  ),
                  SizedBox(
                    height: AppSize.medium,
                  ),
                ],
              ),
            ),
          ),
          isLoading? Container(
            color: Colors.white,
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),
        ],),

      ),
    );
  }

  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }
}
