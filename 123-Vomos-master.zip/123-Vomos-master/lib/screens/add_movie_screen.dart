import 'dart:convert';
import 'dart:io';

import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geocoder/geocoder.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/model/add_stop_model.dart';
import 'package:vamos/screens/post_a_trips_next_map_screen.dart';
import 'package:vamos/screens/post_a_trips_submit_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

import 'package:google_maps_webservice/places.dart';

class AddMoviesScreen extends StatefulWidget{
  @override
  _AddMoviesScreenState createState() => new _AddMoviesScreenState();
}

class _AddMoviesScreenState extends State<AddMoviesScreen> {
  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey();
 // var _loginFormKey = GlobalKey<FormState>();
  int currStep = 0;
  List<AddStopModel>listAddStop = new List<AddStopModel>();
  TextEditingController fromController = new TextEditingController();
  TextEditingController toController = new TextEditingController();
  TextEditingController startController = new TextEditingController();
  TextEditingController signupPasswordController = new TextEditingController();
  TextEditingController signupConfirmPasswordController = new TextEditingController();
  TextEditingController _infoDobController = new TextEditingController();

  TextEditingController noOfSeateController = new TextEditingController();
  TextEditingController interavalTimeController = new TextEditingController();

  bool termCondition=false;

  String  _radioReservationProcess =Constants.immediateBookingTrip;
  String  _radioFlexiable =Constants.yes;

  bool _isSearch=false;

  bool _obscureTextLogin = true;

  String  kGoogleApiKey = "AIzaSyDa9QSWtCvYdSfUPfSxAYcs-Pt4dKkJJEY";

  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: "AIzaSyDa9QSWtCvYdSfUPfSxAYcs-Pt4dKkJJEY");
  static var _focusNode = new FocusNode();
  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        key: _scaffoldKey,
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(AppSize.xxL),
            child: CustomAppBarWidget(
              title: Constants.postATrip,
            ),
          ),
        body: Container(
          color: Colors.white,
    child: new Form(
    key: _formKey,
    child: new ListView(children: <Widget>[
    ConstrainedBox(
    constraints: BoxConstraints.tightFor(height: SizeConfig.heightMultiplier*85),
        child:Theme(
            data: ThemeData(canvasColor:  Colors.white,
              accentColor: AppTheme.accentColor,primaryColor:AppTheme.accentColor,),
            child:Stepper(

          steps: [
            new Step(
            title: const Text(''),
            //subtitle: const Text('Enter your name'),
            isActive: currStep==0?true:false,
            //state: StepState.error,
            state: StepState.indexed,
            content:  _searchScreen(),
          ),
            new Step(
              title: const Text(''),
              //subtitle: const Text('Subtitle'),
              isActive: currStep==1?true:false,
              //state: StepState.editing,
              state: StepState.indexed,
              content:  _postTripMapScrenn(),

            ),
            new Step(
              title: const Text(''),
              //subtitle: const Text('Subtitle'),
              isActive: currStep==2?true:false,
              //state: StepState.editing,
              state: StepState.indexed,
              content:  _post_submitScreen(),


            ),],
          type: StepperType.horizontal,
          currentStep: this.currStep,
          onStepContinue: () {
            setState(() {

              if(currStep==2){
                if(_formKey.currentState.validate())
                  {
                    print("valid");
                  }
                currStep=0;
              }
              else{
                currStep = currStep + 1;
              }
            });
          },
          onStepCancel: () {
            setState(() {
              if (currStep > 0) {
                currStep = currStep - 1;
              } else {
                currStep = 0;
              }
            });
          },
          onStepTapped: (step) {
            setState(() {
              currStep = step;
            });
          },
        ))),


    ]),
    ))

      ),
    );
  }

  Widget _searchScreen(){
    return  Container(
      color: Colors.white,
      width: double.maxFinite,
      child: Column(children: <Widget>[
        SizedBox(height: AppSize.small,),
        Form(
        //  key: _loginFormKey,
          child: Container(
            //width: screenSize.width,
            child: Column(children: <Widget>[

              Container(
                margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*2,right: SizeConfig.widthMultiplier*2),
                width: double.maxFinite,
                padding: EdgeInsets.only(
                    left:6.0*SizeConfig.widthMultiplier,
                    right:6.0*SizeConfig.widthMultiplier),
                decoration:  BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(width: 1.0,color: Colors.grey[200])
                ),

                child: TextFormField(
                  minLines: 1,
                  maxLines: 3,
                  onTap:  () async {
                    // show input autocomplete with selected mode
                    // then get the Prediction selected
                    Prediction p = await PlacesAutocomplete.show(
                        hint:Constants.fromWhichCityWillItLeave ,
                        context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                    displayPrediction(p,true);
                  },
                  readOnly: true,
                  validator: (String value) {
                    return FieldValidator.validateEmptyCheck(value);
                  },
                  controller: fromController,
                  keyboardType: TextInputType.text,
                  textCapitalization:
                  TextCapitalization.words,
                  style: TextStyle(
                      fontFamily: "WorkSansSemiBold",
                      fontSize: 16.0,
                      color: Colors.black),
                  decoration: InputDecoration(
                    labelText: Constants.fromWhichCityWillItLeave,
                    labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                    border: InputBorder.none,
                    icon: Icon(
                      Icons.directions_run,
                      color: Colors.black,
                      size:AppFontSize.textIcon,
                    ),

                  ),
                ),
              ),

              SizedBox(height: AppSize.medium,),

              Container(
                margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*2,right: SizeConfig.widthMultiplier*2),

                width: double.maxFinite,
                padding: EdgeInsets.only(
                    left:6.0*SizeConfig.widthMultiplier,
                    right:6.0*SizeConfig.widthMultiplier),
                decoration:  BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(width: 1.0,color: Colors.grey[200])
                ),

                child:    DateTimeField(
                  controller: startController,
                  resetIcon: Icon(Icons.phone,color: Colors.grey[200],),
                  decoration:InputDecoration(
                    labelText: Constants.startTime,
                    labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.s16),
                    border: InputBorder.none,
                    icon: Icon(
                      FontAwesomeIcons.calendar,
                      color: Colors.black,
                      size:AppFontSize.textIcon,
                    ),

                  ) ,
                  format: DateFormat("yyyy-MM-dd HH:mm").add_jm(),
                  onShowPicker: (context, currentValue) async {
                    final date = await showDatePicker(
                        context: context,
                        firstDate: DateTime(1900),
                        initialDate: currentValue ?? DateTime.now(),
                        lastDate: DateTime(2100));
                    if (date != null) {
                      final time = await showTimePicker(
                        context: context,
                        initialTime:
                        TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
                      );
                      return DateTimeField.combine(date, time);
                    } else {
                      return currentValue;
                    }
                  },
                ),
              ),




              SizedBox(height: AppSize.medium,),



              Container(
                width: double.maxFinite,
                margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*2,right: SizeConfig.widthMultiplier*2),

                padding: EdgeInsets.only(
                    left:6.0*SizeConfig.widthMultiplier,
                    right:6.0*SizeConfig.widthMultiplier),
                decoration:  BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(width: 1.0,color: Colors.grey[200])

                ),


                child: TextFormField(
                  minLines: 1,
                  maxLines: 3,
                  onTap:  () async {
                    // show input autocomplete with selected mode
                    // then get the Prediction selected
                    Prediction p = await PlacesAutocomplete.show(
                        hint: Constants.whichCityWillYouTravelTo,
                        context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                    displayPrediction(p,false);
                  },
                  readOnly: true,
                  validator: (String value) {
                    return FieldValidator.validateEmptyCheck(value);
                  },
                  controller: toController,
                  keyboardType: TextInputType.text,
                  textCapitalization:
                  TextCapitalization.words,
                  style: TextStyle(
                      fontFamily: "WorkSansSemiBold",
                      fontSize: 16.0,
                      color: Colors.black),
                  decoration: InputDecoration(
                    labelText: Constants.whichCityWillYouTravelTo,
                    labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                    border: InputBorder.none,
                    icon: Icon(
                      Icons.directions_walk,
                      color: Colors.black,
                      size:AppFontSize.textIcon,
                    ),

                  ),
                ),
              ),





              SizedBox(height: AppSize.large,),

              Container(
                width: SizeConfig.widthMultiplier*90,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      width: SizeConfig.widthMultiplier*85,
                      child:  CustomRoundButtonWidget(
                        title: Constants.addNewStop,
                        callback: () {

                          setState(() {
                            listAddStop.add(AddStopModel(TextEditingController(),0.0,0.0));

                          });
                          // AppRoutes.goto(context, SearchTripsResultScreen());
                        },
                      ),),
//
//                    Container(
//                      width: SizeConfig.widthMultiplier*30,
//                      child:  CustomRoundButtonWidget(
//                        title: Constants.next,
//                        callback: () {
//                          AppRoutes.goto(context, PostATripNextMapScreen());
//                        },
//                      ),)

                  ],),
              ),




              SizedBox(height: AppSize.large,),

              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                itemCount: listAddStop.length,
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemBuilder: (BuildContext context, int index) {
                  return Column(children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
                    //  width: SizeConfig.widthMultiplier*95,
                      padding: EdgeInsets.only(
                          left:1.0*SizeConfig.widthMultiplier,
                          right:1.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])
                      ),

                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Container(
                            width: SizeConfig.widthMultiplier*62,
                            child: TextFormField(
                              minLines: 1,
                              maxLines: 3,
                              onTap:  () async {
                                // show input autocomplete with selected mode
                                // then get the Prediction selected
                                Prediction p = await PlacesAutocomplete.show(
                                    hint:Constants.inWhichCitiesWillItStop ,
                                    context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                                displayPredictionForAddStop(p,index);
                              },
                              readOnly: true,
                              validator: (String value) {
                                return FieldValidator.validateEmptyCheck(value);
                              },
                              controller: listAddStop[index].editingController,
                              keyboardType: TextInputType.text,
                              textCapitalization:
                              TextCapitalization.words,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                labelText: Constants.inWhichCitiesWillItStop,
                                labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.assistant_photo,
                                  color: Colors.black,
                                  size:AppFontSize.textIcon,
                                ),

                              ),
                            ),
                          ),
                          Container(
                            height: AppSize.xxL,
                            alignment: Alignment.topRight,
                            width: SizeConfig.widthMultiplier*10,
                            child: GestureDetector(
                              onTap: (){
                                setState(() {
                                  listAddStop.removeAt(index);

                                });
                              },
                              child: Icon(Icons.cancel,color: Colors.red,size: AppSize.medium,),),)
                        ],),
                    ),
                    SizedBox(height: AppSize.medium,),




                  ],);


                },
              ),




            ],),
          ),
        ),


      ],),
    );
  }

  Widget _postTripMapScrenn(){
    return  Container(
      color: Colors.white,
      width: double.maxFinite,
      child: SingleChildScrollView(
        child:    Column(children: <Widget>[
          SizedBox(height: AppSize.medium,),
          Form(
           // key: _loginFormKey,
            child:Column(children: <Widget>[
              Container(
                margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                decoration:  BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: new Border.all(width: 1,color: Colors.grey[400])
                  // border: Border.all(width: 1.0,color: Colors.grey[200])
                ),
                child: Column(children: <Widget>[

                  Container(
                    height: SizeConfig.heightMultiplier*2,
                  ),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Row(children: <Widget>[
                            Icon(Icons.location_on,color: AppTheme.primaryColor,),
                            Text(Constants.from)
                          ],),
                        ),

                        Container(
                          child: Row(

                            children: <Widget>[
                              Icon(Icons.update,color: AppTheme.primaryColor,),
                              Text("2020-02-13 15:50")
                            ],),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: AppSize.small,),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*1),
                    margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
                    decoration:  BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(15),
                        border: new Border.all(width: 1,color: Colors.grey[200])

                    ),
                    child:Container(
                      width: SizeConfig.widthMultiplier*90,
                      padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3,vertical: SizeConfig.widthMultiplier*3),
                      child: Text("Portal 80, Bogota, Colombia",style:AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14),),),
                  ),



                  SizedBox(height: AppSize.medium,),


                  Container(
                    padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Row(children: <Widget>[
                            Icon(Icons.transfer_within_a_station,color: AppTheme.primaryColor,),
                            Text(Constants.nextStop)
                          ],),
                        ),

                        Container(
                          child: Row(

                            children: <Widget>[
                              Icon(Icons.update,color: AppTheme.primaryColor,),
                              Text("2020-02-13 16:10")
                            ],),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: AppSize.small,),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*1),
                    margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                    decoration:  BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(15),
                        border: new Border.all(width: 1,color: Colors.grey[200])

                    ),
                    child:Container(
                      padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3,vertical: SizeConfig.widthMultiplier*3),

                      width: SizeConfig.widthMultiplier*90,
                      child: Text("Bogota, Colombia",style:AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14),),),
                  ),
                  SizedBox(height: AppSize.small,),

                  Container(
                    margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                    padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                    child: Row(

                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text("76.6 km"),

                        Text("20 min"),

                        Text(Constants.currancy+"3820"),
                      ],
                    ),
                  ),




                  SizedBox(height: AppSize.medium,),


                  Container(
                    padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Row(children: <Widget>[
                            Icon(Icons.location_on,color: AppTheme.primaryColor,),
                            Text(Constants.to)
                          ],),
                        ),

                        Container(
                          child: Row(

                            children: <Widget>[
                              Icon(Icons.update,color: AppTheme.primaryColor,),
                              Text("2020-02-13 16:40")
                            ],),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: AppSize.small,),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*1),
                    margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
                    decoration:  BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(15),
                        border: new Border.all(width: 1,color: Colors.grey[200])

                    ),
                    child:Container(
                      width: SizeConfig.widthMultiplier*90,
                      padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3,vertical: SizeConfig.widthMultiplier*3),
                      child: Text("Portal 80, Bogota, Colombia",style:AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14),),),
                  ),
                  SizedBox(height: AppSize.small,),

                  Container(
                    margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                    padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                    child: Row(

                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text("20 km"),

                        Text("30 min"),

                        Text(Constants.currancy+"1000"),
                      ],
                    ),
                  ),
//
                  SizedBox(height: AppSize.medium,),


                ],),
              )
            ],),
          ),

          SizedBox(height: AppSize.large,),

          Container(
            margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

            padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),

            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: <Widget>[
                Container(
                    width: SizeConfig.widthMultiplier*45,
                    child: Row(children: <Widget>[
                      Text(Constants.currancy,style: TextStyle(color: AppTheme.primaryColor),),

                      Text(Constants.recommendedPrice,),
                    ],)),
                Container(
                    alignment: Alignment.centerRight,
                    width: SizeConfig.widthMultiplier*30,
                    child: Text(Constants.currancy+"23215",)),

              ],),),

          SizedBox(height: AppSize.small,),

          Container(
            padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*2),
            margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
            decoration:  BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: new Border.all(width: 1,color: Colors.grey[200])
              // border: Border.all(width: 1.0,color: Colors.grey[200])
            ),

            child:TextFormField(
              validator: (String value) {
                return FieldValidator.validateEmptyCheck(value);
              },
              keyboardType: TextInputType.number,
              // maxLength: 9,
              style: TextStyle(
                  fontFamily: "WorkSansSemiBold",
                  fontSize: 16.0,
                  color: Colors.black),
              decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: Constants.putYourPriceHere,
                  hintStyle:
                  TextStyle(fontSize: AppFontSize.textHint)),
            ),
          ),

//          Container(
//            width: SizeConfig.widthMultiplier*90,
//            child: Row(
//              mainAxisAlignment: MainAxisAlignment.spaceBetween,
//              children: <Widget>[
//
//                Container(
//                  width: SizeConfig.widthMultiplier*40,
//                  child:  CustomRoundButtonWidget(
//                    title: Constants.back,
//                    callback: () {
//                      AppRoutes.dismiss(context);
//                    },
//                  ),),
//
//                Container(
//                  width: SizeConfig.widthMultiplier*40,
//                  child:  CustomRoundButtonWidget(
//                    title: Constants.next,
//                    callback: () {
//                      AppRoutes.goto(context, PostATripSubmitScreen());
//                    },
//                  ),)
//
//              ],),
//          ),



        ],),
      ),
    );
  }



  Widget _post_submitScreen(){
    return Container(
      color: Colors.white,
      width: double.maxFinite,
      child: SingleChildScrollView(
        child:    Column(children: <Widget>[
          SizedBox(height: AppSize.medium,),
          Form(
           // key: _loginFormKey,
            child: Container(
              //width: screenSize.width,
              child: Column(children: <Widget>[

                Container(
                  height: SizeConfig.heightMultiplier*2,
                ),
                Container(
                  margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Container(
                        width: SizeConfig.widthMultiplier*40,
                        padding: EdgeInsets.only(
                            left:1.0*SizeConfig.widthMultiplier,
                            right:1.0*SizeConfig.widthMultiplier),
                        decoration:  BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            border: new Border.all(width: 1,color: Colors.grey[200])
                          // border: Border.all(width: 1.0,color: Colors.grey[200])
                        ),

                        child: TextFormField(
                          minLines: 1,
                          maxLines: 3,
                          onTap:  ()  {

                          },
                          readOnly: true,
                          validator: (String value) {
                            return FieldValidator.validateEmptyCheck(value);
                          },
                          controller: noOfSeateController,
                          keyboardType: TextInputType.text,
                          textCapitalization:
                          TextCapitalization.words,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: AppFontSize.textHint,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.numberOfSeats,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              Icons.event_seat,
                              color: Colors.black,
                              size:AppFontSize.textIcon,
                            ),

                          ),
                        ),
                      ),

                      Container(

                        width:SizeConfig.widthMultiplier*40,
                        padding: EdgeInsets.only(
                            left:1.0*SizeConfig.widthMultiplier,
                            right:1.0*SizeConfig.widthMultiplier),
                        decoration:  BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(width: 1.0,color: Colors.grey[200])
                        ),

                        child: TextFormField(
                          minLines: 1,
                          maxLines: 3,
                          onTap:  ()  {

                          },
                          readOnly: true,
                          validator: (String value) {
                            return FieldValidator.validateEmptyCheck(value);
                          },
                          controller: interavalTimeController,
                          keyboardType: TextInputType.text,
                          textCapitalization:
                          TextCapitalization.words,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: AppFontSize.textHint,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.intervalTime,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              Icons.timer,
                              color: Colors.black,
                              size:AppFontSize.textIcon,
                            ),

                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: AppSize.medium,),



                Container(
                  width: double.maxFinite,
                  margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                  padding: EdgeInsets.only(
                      left:1.0*SizeConfig.widthMultiplier,
                      right:1.0*SizeConfig.widthMultiplier),
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(width: 1.0,color: Colors.grey[200])

                  ),


                  child:  Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(top: 5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Icon(Icons.airline_seat_recline_extra),
                            SizedBox(width: AppSize.small,),
                            Text(
                              Constants.reservationProcess,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: AppFontSize.textHint,
                                  color: Colors.grey),
                            ),
                          ],),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[


                          Container(
                            //width: SizeConfig.widthMultiplier * 40,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Radio(
                                    onChanged: (newValue) =>
                                        setState(() => _radioReservationProcess = newValue),
                                    value: "1",
                                    activeColor: AppTheme.accentColor,
                                    groupValue: _radioReservationProcess,
                                  ),
                                  Text(
                                    Constants.immediateBookingTrip,
                                    style: TextStyle(
                                        fontFamily: "WorkSansSemiBold",
                                        fontSize: AppFontSize.s12,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                          Container(
                            // width: SizeConfig.widthMultiplier * 40,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Radio(
                                    activeColor: AppTheme.accentColor,
                                    onChanged: (newValue) =>
                                        setState(() => _radioReservationProcess = newValue),
                                    value: "2",
                                    groupValue: _radioReservationProcess,
                                  ),
                                  Text(
                                    Constants.confirmReservation,
                                    style: TextStyle(
                                        fontFamily: "WorkSansSemiBold",
                                        fontSize: AppFontSize.s12,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                        ],
                      )
                    ],
                  ),
                ),


                SizedBox(height: AppSize.medium,),


                Container(
                  width: double.maxFinite,
                  margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                  padding: EdgeInsets.only(
                      left:1.0*SizeConfig.widthMultiplier,
                      right:1.0*SizeConfig.widthMultiplier),
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(width: 1.0,color: Colors.grey[200])

                  ),


                  child:  Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(top: 5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Icon(Icons.timeline),
                            SizedBox(width: AppSize.small,),
                            Text(
                              Constants.areYouFlexiableWithTime,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: AppFontSize.textHint,
                                  color: Colors.grey),
                            ),
                          ],),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[


                          Container(
                            //width: SizeConfig.widthMultiplier * 40,
                              child: Row(
                                children: <Widget>[
                                  Radio(
                                    onChanged: (newValue) =>
                                        setState(() => _radioFlexiable = newValue),
                                    value: "1",
                                    activeColor: AppTheme.accentColor,
                                    groupValue: _radioFlexiable,
                                  ),
                                  Text(
                                    Constants.yes,
                                    style: TextStyle(
                                        fontFamily: "WorkSansSemiBold",
                                        fontSize: AppFontSize.s12,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                          Container(
                            // width: SizeConfig.widthMultiplier * 40,
                              child: Row(
                                children: <Widget>[
                                  Radio(
                                    activeColor: AppTheme.accentColor,
                                    onChanged: (newValue) =>
                                        setState(() => _radioFlexiable = newValue),
                                    value: "2",
                                    groupValue: _radioFlexiable,
                                  ),
                                  Text(
                                    Constants.doNot,
                                    style: TextStyle(
                                        fontFamily: "WorkSansSemiBold",
                                        fontSize: AppFontSize.s12,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                        ],
                      )
                    ],
                  ),
                ),


                SizedBox(height: AppSize.medium,),



                Container(
                  width: double.maxFinite,
                  margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                  padding: EdgeInsets.only(
                      left:1.0*SizeConfig.widthMultiplier,
                      right:1.0*SizeConfig.widthMultiplier),
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(width: 1.0,color: Colors.grey[200])

                  ),


                  child:Column(children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(top: 5.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Icon(Icons.speaker_notes),
                          SizedBox(width: AppSize.small,),
                          Text(
                            Constants.detailsOfTheTrip,
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: AppFontSize.textHint,
                                color: Colors.grey),
                          ),
                        ],),
                    ),
                    TextFormField(
                      minLines: 2,
                      maxLines: 6,
                      onTap:  ()  {

                      },
                      validator: (String value) {
                        return FieldValidator.validateEmptyCheck(value);
                      },
                      // controller: toController,
                      keyboardType: TextInputType.text,
                      textCapitalization:
                      TextCapitalization.words,
                      style: TextStyle(
                          fontFamily: "WorkSansSemiBold",
                          fontSize: 16.0,
                          color: Colors.black),
                      decoration: InputDecoration(
                        // hintText: Constants.detailsOfTheTripHint,
                        hintStyle:  TextStyle(color: Colors.grey[300],fontSize: AppFontSize.textHint),
                        border: InputBorder.none,

                      ),
                    )
                  ],),
                ),



                SizedBox(height: AppSize.medium,),

                Container(
                  child: Row(children: <Widget>[

                    Checkbox(
                      value: termCondition,
                      onChanged: (bool value) {
                        setState(() {
                          termCondition = value;
                        });
                      },
                    ),

                    Expanded(
                      child: RichText(
                        text: new TextSpan(
                          children: [
                            new TextSpan(
                              text: Constants.acceptGeneralCondition1,
                              style: new TextStyle(color: Colors.black),
                            ),
                            new TextSpan(
                              text:Constants.acceptGeneralCondition2,
                              style: new TextStyle(color: Colors.blue),
                              recognizer: new TapGestureRecognizer()
                                ..onTap = () { launch(API.condition);
                                },
                            ),

                            new TextSpan(
                              text: Constants.acceptGeneralCondition3,
                              style: new TextStyle(color: Colors.black),
                            ),

                            new TextSpan(
                              text: Constants.acceptGeneralCondition4,
                              style: new TextStyle(color: Colors.blue),
                              recognizer: new TapGestureRecognizer()
                                ..onTap = () { launch(API.policy);
                                },
                            ),

                            new TextSpan(
                              text: Constants.acceptGeneralCondition5,
                              style: new TextStyle(color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                    )],),
                ),

                SizedBox(height: AppSize.large,),

//                Container(
//                  width: SizeConfig.widthMultiplier*90,
//                  child: Row(
//                    mainAxisAlignment: MainAxisAlignment.center,
//                    children: <Widget>[
//
//                      Container(
//                        width: SizeConfig.widthMultiplier*40,
//                        child:  CustomRoundButtonWidget(
//                          title: Constants.back,
//                          callback: () {
//                            AppRoutes.dismiss(context);
//                          },
//                        ),),
//
//
//                      Container(
//                        //  width: SizeConfig.widthMultiplier*0,
//                        child:  CustomRoundButtonWidget(
//                          title: Constants.submit,
//                          callback: () {
//                            // AppRoutes.goto(context, SearchTripsResultScreen());
//                          },
//                        ),)
//
//                    ],),
//                ),




              //  SizedBox(height: AppSize.large,),






              ],),
            ),
          ),


        ],),
      ),
    );
  }

  Future<Null> displayPrediction(Prediction p,bool clickType) async {
    if (p != null) {
      PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(p.placeId);

      var placeId = p.placeId;
      double lat = detail.result.geometry.location.lat;
      double lng = detail.result.geometry.location.lng;

      var address = await Geocoder.local.findAddressesFromQuery(p.description);


      if(clickType)
      {
        fromController.text=address.first.addressLine.toString();
      }
      else{
        toController.text=address.first.addressLine.toString();
      }

      print(address.first.addressLine);
      print(placeId);
    }
  }




  Future<Null> displayPredictionForAddStop(Prediction p,int index) async {
    if (p != null) {
      PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(p.placeId);

      var placeId = p.placeId;
      double lat = detail.result.geometry.location.lat;
      double lng = detail.result.geometry.location.lng;

      var address = await Geocoder.local.findAddressesFromQuery(p.description);


      listAddStop[index].editingController.text=address.first.addressLine;
      listAddStop[index].lat=lat;
      listAddStop[index].long=lng;

      print(address.first.addressLine);
      print(placeId);
    }
  }

}