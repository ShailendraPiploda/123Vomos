import 'dart:convert';
import 'dart:io';

import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/search_trip_widget.dart';
import 'package:vamos/model/add_stop_model.dart';
import 'package:vamos/screens/posted_trips.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geocoder/geocoder.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:google_maps_webservice/places.dart';

class UpdatePostATripSubmitScreen extends StatefulWidget {
  String id;
  var tripData;

  UpdatePostATripSubmitScreen(this.id,this.tripData);

  @override
  State<StatefulWidget> createState() => new _UpdatePostATripSubmitScreen();
}

class _UpdatePostATripSubmitScreen extends State<UpdatePostATripSubmitScreen> {
  Item noOfSeate;
  Item interavalTime;
  int intervalPosition=0;
  int seatPosition=0;
  List<AddStopModel> listAddStop = new List<AddStopModel>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController noOfSeateController = new TextEditingController();
  TextEditingController interavalTimeController = new TextEditingController();
  TextEditingController tripDetailController = new TextEditingController();

  List<String> listSeat = new List<String>();
  List<String> listIntervalTime = new List<String>();
  String _radioReservationProcess = "1";
  String _radioFlexiable = "1";

bool isLoding=false;
  var _loginFormKey = GlobalKey<FormState>();

  bool termCondition = false;

  List<Item> seatList = <Item>[
    const Item(
        '1',
        Icon(
          Icons.event_seat,
          color: AppTheme.primaryColor,
        )),
    const Item(
        '2',
        Icon(
          Icons.event_seat,
          color: AppTheme.primaryColor,
        )),
    const Item(
        '3',
        Icon(
          Icons.event_seat,
          color: AppTheme.primaryColor,
        )),
    const Item(
        '4',
        Icon(
          Icons.event_seat,
          color: AppTheme.primaryColor,
        )),
  ];

  List<Item> intervalTimeList = <Item>[
    const Item(
        '15 minutes',
        Icon(
          Icons.timer,
          color: AppTheme.primaryColor,
        )),
    const Item(
        '30 minutes',
        Icon(
          Icons.timer,
          color: AppTheme.primaryColor,
        )),
    const Item(
        '45 minutes',
        Icon(
          Icons.timer,
          color: AppTheme.primaryColor,
        )),
    const Item(
        '60 minutes',
        Icon(
          Icons.timer,
          color: AppTheme.primaryColor,
        )),
  ];

  submitTask() async {

    String interval = interavalTime.name.toString().substring(0,2);
    final uri = API.addTrip2;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "post_id": widget.id,
      "isflexible": _radioFlexiable,
      "interval_time": interval,
      "description": tripDetailController.text,
      "total_seat": noOfSeate.name,
      "booking_process": _radioReservationProcess,
      "flexible": _radioFlexiable,
      "process": _radioReservationProcess,

    };
   final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    loadProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:context,isSucces: true,message: (data["message"]));


        Future.delayed(Duration(seconds: 1), () {
          AppRoutes.dismissTillFirst(context);
          AppRoutes.goto(context, PostedTripsScreen());

        });


      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.updateTrip,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(
        isGoBack: false,
      ),
      body: Container(
        color: Colors.white,
        height: double.maxFinite,
        width: double.maxFinite,
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
          SingleChildScrollView(
            child: Column(
                children: <Widget>[
                SizedBox(
                  height: AppSize.medium,
                ),
                Form(
                  key: _loginFormKey,
                  child: Container(
                    //width: screenSize.width,
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: SizeConfig.heightMultiplier * 2,
                        ),
                        Container(
                          margin: EdgeInsets.only(
                              left: SizeConfig.widthMultiplier * 3,
                              right: SizeConfig.widthMultiplier * 3),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.bottomLeft,
                                width: SizeConfig.widthMultiplier * 45,
                                padding: EdgeInsets.only(
                                    left: 1.0 * SizeConfig.widthMultiplier,
                                    right: 1.0 * SizeConfig.widthMultiplier),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(15),
                                    border: new Border.all(
                                        width: 1, color: Colors.grey[200])
                                  // border: Border.all(width: 1.0,color: Colors.grey[200])
                                ),
                                child: DropdownButton<Item>(
                                  hint: Text(Constants.noOfSeatBook,style: TextStyle(fontSize: AppFontSize.s14)),
                                  value: seatList[seatPosition],
                                  onChanged: (Item Value) {
                                    setState(() {
                                      noOfSeate = Value;
                                      seatPosition =int.parse(Value.name)-1;

                                    });
                                  },
                                  underline: SizedBox(
                                    width: 1.0,
                                  ),
                                  items: seatList.map((Item user) {
                                    return DropdownMenuItem<Item>(
                                      value: user,
                                      child: Row(
                                        children: <Widget>[
                                          user.icon,
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            width: 100.0,
                                            child: Text(
                                              user.name,
                                              textAlign: TextAlign.left,
                                              style: TextStyle(color: Colors.grey,fontSize: AppFontSize.s14),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                              Container(
                                width: SizeConfig.widthMultiplier * 45,
                                padding: EdgeInsets.only(
                                    left: 1.0 * SizeConfig.widthMultiplier,
                                    right: 1.0 * SizeConfig.widthMultiplier),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(15),
                                    border: Border.all(
                                        width: 1.0, color: Colors.grey[200])),
                                child: DropdownButton<Item>(

                                  hint: Text(Constants.intervalTime,style: TextStyle(fontSize: AppFontSize.s14)),
                                  value: intervalTimeList[intervalPosition],
                                  onChanged: (Item Value) {
                                    setState(() {
                                      interavalTime = Value;
                                      int interval = int.parse(interavalTime.name.toString().substring(0,2));

                                      switch(interval){
                                        case 0: intervalPosition=0;
                                        break;
                                        case 15: intervalPosition=0;
                                        break;
                                        case 30: intervalPosition=1;
                                        break;
                                        case 45: intervalPosition=2;
                                        break;
                                        case 60: intervalPosition=3;
                                        break;
                                      }

                                    });
                                  },
                                  underline: SizedBox(
                                    width: 1.0,
                                  ),
                                  items: intervalTimeList.map((Item user) {
                                    return DropdownMenuItem<Item>(
                                      value: user,
                                      child: Row(
                                        children: <Widget>[
                                          user.icon,
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            width: 100.0,
                                            child: Text(
                                              user.name,
                                              textAlign: TextAlign.left,
                                              style: TextStyle(color: Colors.grey,fontSize: AppFontSize.s14),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: AppSize.medium,
                        ),
                        Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.only(
                              left: SizeConfig.widthMultiplier * 3,
                              right: SizeConfig.widthMultiplier * 3),
                          padding: EdgeInsets.only(
                              left: 1.0 * SizeConfig.widthMultiplier,
                              right: 1.0 * SizeConfig.widthMultiplier),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                  width: 1.0, color: Colors.grey[200])),
                          child: Column(
                            children: <Widget>[
                              Container(
                                margin: EdgeInsets.only(top: 5.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(
                                      Icons.airline_seat_recline_extra,
                                      color: AppTheme.primaryColor,
                                    ),
                                    SizedBox(
                                      width: AppSize.small,
                                    ),
                                    Text(
                                      Constants.reservationProcess,
                                      style: TextStyle(
                                          fontFamily: "WorkSansSemiBold",
                                          fontSize: AppFontSize.textHint,
                                          color: AppTheme.primaryColor),
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    //width: SizeConfig.widthMultiplier * 40,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          Radio(
                                            onChanged: (newValue) => setState(() =>
                                            _radioReservationProcess = newValue),
                                            value: "1",
                                            activeColor: AppTheme.accentColor,
                                            groupValue: _radioReservationProcess,
                                          ),
                                          Text(
                                            Constants.immediateBookingTrip,
                                            style: TextStyle(
                                               // fontFamily: "WorkSansSemiBold",
                                                fontSize: AppFontSize.s12,
                                                color: Colors.grey),
                                          ),
                                        ],
                                      )),
                                  Container(
                                    // width: SizeConfig.widthMultiplier * 40,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          Radio(
                                            activeColor: AppTheme.accentColor,
                                            onChanged: (newValue) => setState(() =>
                                            _radioReservationProcess = newValue),
                                            value: "2",
                                            groupValue: _radioReservationProcess,
                                          ),
                                          Text(
                                            Constants.confirmReservation,
                                            style: TextStyle(
                                              //  fontFamily: "WorkSansSemiBold",
                                                fontSize: AppFontSize.s12,
                                                color: Colors.grey),
                                          ),
                                        ],
                                      )),
                                ],
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: AppSize.medium,
                        ),
                        Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.only(
                              left: SizeConfig.widthMultiplier * 3,
                              right: SizeConfig.widthMultiplier * 3),
                          padding: EdgeInsets.only(
                              left: 1.0 * SizeConfig.widthMultiplier,
                              right: 1.0 * SizeConfig.widthMultiplier),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                  width: 1.0, color: Colors.grey[200])),
                          child: Column(
                            children: <Widget>[
                              Container(
                                margin: EdgeInsets.only(top: 5.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(
                                      Icons.timeline,
                                      color: AppTheme.primaryColor,
                                    ),
                                    SizedBox(
                                      width: AppSize.small,
                                    ),
                                    Text(
                                      Constants.areYouFlexiableWithTime,
                                      style: TextStyle(
                                         // fontFamily: "WorkSansSemiBold",
                                          fontSize: AppFontSize.textHint,
                                          color: AppTheme.primaryColor),
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    //width: SizeConfig.widthMultiplier * 40,
                                      child: Row(
                                        children: <Widget>[
                                          Radio(
                                            onChanged: (newValue) => setState(
                                                    () => _radioFlexiable = newValue),
                                            value: "1",
                                            activeColor: AppTheme.accentColor,
                                            groupValue: _radioFlexiable,
                                          ),
                                          Text(
                                            Constants.yes,
                                            style: TextStyle(
                                              //  fontFamily: "WorkSansSemiBold",
                                                fontSize: AppFontSize.s12,
                                                color: Colors.grey),
                                          ),
                                        ],
                                      )),
                                  Container(
                                    // width: SizeConfig.widthMultiplier * 40,
                                      child: Row(
                                        children: <Widget>[
                                          Radio(
                                            activeColor: AppTheme.accentColor,
                                            onChanged: (newValue) => setState(
                                                    () => _radioFlexiable = newValue),
                                            value: "2",
                                            groupValue: _radioFlexiable,
                                          ),
                                          Text(
                                            Constants.doNot,
                                            style: TextStyle(
                                              //  fontFamily: "WorkSansSemiBold",
                                                fontSize: AppFontSize.s12,
                                                color: Colors.grey),
                                          ),
                                        ],
                                      )),
                                ],
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: AppSize.medium,
                        ),
                        Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.only(
                              left: SizeConfig.widthMultiplier * 3,
                              right: SizeConfig.widthMultiplier * 3),
                          padding: EdgeInsets.only(
                              left: 1.0 * SizeConfig.widthMultiplier,
                              right: 1.0 * SizeConfig.widthMultiplier),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                  width: 1.0, color: Colors.grey[200])),
                          child: Column(
                            children: <Widget>[
                              Container(
                                margin: EdgeInsets.only(top: 5.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(Icons.speaker_notes,
                                        color: AppTheme.primaryColor),
                                    SizedBox(
                                      width: AppSize.small,
                                    ),
                                    Text(
                                      Constants.detailsOfTheTrip,
                                      style: TextStyle(
                                         // fontFamily: "WorkSansSemiBold",
                                          fontSize: AppFontSize.textHint,
                                          color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ),
                              TextFormField(
                                controller: tripDetailController,
                                minLines: 2,
                                maxLines: 6,
                                onTap: () {},
                                validator: (String value) {
                                  return FieldValidator.validateEmptyCheck(value);
                                },
                                // controller: toController,
                                keyboardType: TextInputType.text,
                                textCapitalization: TextCapitalization.words,
                                style: TextStyle(
                                   // fontFamily: "WorkSansSemiBold",
                                    fontSize: 14.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  // hintText: Constants.detailsOfTheTripHint,
                                  hintStyle: TextStyle(
                                      color: Colors.grey[300],
                                      fontSize: AppFontSize.textHint),
                                  border: InputBorder.none,
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: AppSize.medium,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Checkbox(
                                value: termCondition,
                                onChanged: (bool value) {
                                  setState(() {
                                    termCondition = value;
                                  });
                                },
                              ),
                              Expanded(
                                child: RichText(
                                  text: new TextSpan(
                                    children: [
                                      new TextSpan(
                                        text: Constants.acceptGeneralCondition1,
                                        style: new TextStyle(color: Colors.grey),
                                      ),
                                      new TextSpan(
                                        text: Constants.acceptGeneralCondition2,
                                        style: new TextStyle(color: AppTheme.primaryColor),
                                        recognizer: new TapGestureRecognizer()
                                          ..onTap = () {
                                            launch(API.condition);
                                          },
                                      ),
                                      new TextSpan(
                                        text: Constants.acceptGeneralCondition3,
                                        style: new TextStyle(color: Colors.grey),
                                      ),
                                      new TextSpan(
                                        text: Constants.acceptGeneralCondition4,
                                        style: new TextStyle(color: AppTheme.primaryColor),
                                        recognizer: new TapGestureRecognizer()
                                          ..onTap = () {
                                            launch(API.policy);
                                          },
                                      ),
                                      new TextSpan(
                                        text: Constants.acceptGeneralCondition5,
                                        style: new TextStyle(color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: AppSize.large,
                        ),
                        Container(
                          width: SizeConfig.widthMultiplier * 90,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Container(
                                width: SizeConfig.widthMultiplier * 40,
                                child: CustomRoundButtonWidget(
                                  title: Constants.back,
                                  callback: () {
                                    AppRoutes.dismiss(context);
                                  },
                                ),
                              ),
                              Container(
                                width: SizeConfig.widthMultiplier * 40,
                                child: CustomRoundButtonWidget(
                                  title: Constants.submit,
                                  callback: () {

                                    if(_loginFormKey.currentState.validate())
                                    {
                                      if(termCondition)
                                      {
                                      loadProgress();
                                      submitTask();
                                      }else
                                      {
                                      showDisplayAllert(context: context,isSucces: false,message: Constants.acceptTheGeneralCondition);
                                      }
                                    }


                                  },
                                ),
                              )
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          isLoding? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center(child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,)
        ],),
      ),
    );
  }

  @override
  void initState() {


    _radioFlexiable =widget.tripData["flexible"].toString();
   intervalPosition =int.parse(widget.tripData["interval_time"].toString()) ;
    tripDetailController.text =widget.tripData["description"].toString();
    seatPosition = int.parse(widget.tripData["total_seat"].toString());
    _radioReservationProcess =widget.tripData["booking_process"].toString();




    if(seatPosition!=0)
      {
        seatPosition-seatPosition-1;
      }



    switch(intervalPosition){
      case 0: intervalPosition=0;
      break;
      case 15: intervalPosition=0;
      break;
      case 30: intervalPosition=1;
      break;
      case 45: intervalPosition=2;
      break;
      case 60: intervalPosition=3;
      break;
    }

   interavalTime= intervalTimeList[intervalPosition];
    noOfSeate=seatList[seatPosition];
  }



  void showSeatPopup() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: listSeat.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        setState(() {
                          noOfSeateController.text = listSeat[index];
                        });

                        print(index);
                        Navigator.pop(context);
                      },
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(listSeat[index],
                                      style: TextStyle(fontSize: 18.0)),
                                )
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Container(
                                  height: 1.0,
                                  color: Colors.grey[400],
                                )),
                          ],
                        ),
                      ));
                },
              ),
            ),
          );
        });
  }

  void showIntervalTime() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: listIntervalTime.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        setState(() {
                          interavalTimeController.text =
                              listIntervalTime[index].toString();
                        });

                        print(index);
                        Navigator.pop(context);
                      },
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(listIntervalTime[index],
                                      style: TextStyle(fontSize: 18.0)),
                                )
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Container(
                                  height: 1.0,
                                  color: Colors.grey[400],
                                )),
                          ],
                        ),
                      ));
                },
              ),
            ),
          );
        });
  }

  Widget SeatDropDown() {
    DropdownButton<Item>(
      hint: Text("Select item"),
      value: noOfSeate,
      onChanged: (Item Value) {
        setState(() {
          noOfSeate = Value;
        });
      },
      items: seatList.map((Item user) {
        return DropdownMenuItem<Item>(
          value: user,
          child: Row(
            children: <Widget>[
              user.icon,
              SizedBox(
                width: 10,
              ),
              Text(
                user.name,
                style: TextStyle(color: Colors.black),
              ),
            ],
          ),
        );
      }).toList(),
    );


  }

  void loadProgress() {
    setState(() {
      isLoding = !isLoding;
    });
  }

  }



class Item {
  const Item(this.name, this.icon);

  final String name;
  final Icon icon;
}
