import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/search_trip_widget.dart';
import 'package:vamos/model/search_model.dart';
import 'package:vamos/screens/post_trip_details.dart';
import 'package:vamos/screens/search_details_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class SearchTripsResultScreen extends StatefulWidget{
  double startLat=0.0, startLong=0.0, endLat=0.0,endLong=0.0;
  String locationAName,locationBName,date;


  SearchTripsResultScreen({this.startLat, this.startLong, this.endLat,
      this.endLong, this.locationAName, this.locationBName, this.date});

  @override
  State<StatefulWidget> createState()=>new _SearchTripsResultScreen();

}
class _SearchTripsResultScreen extends State<SearchTripsResultScreen>{

  final GlobalKey<ScaffoldState> _scaffoldKey =new GlobalKey<ScaffoldState>();
  TextEditingController signupEmailController = new TextEditingController();
  TextEditingController signupFirstNameController = new TextEditingController();
  TextEditingController signupLastNameController = new TextEditingController();
  TextEditingController signupPasswordController = new TextEditingController();
  TextEditingController signupConfirmPasswordController = new TextEditingController();
  TextEditingController _infoDobController = new TextEditingController();
  List<SearchModel>listSearchResult = new List();
  String userIdMain="";
  bool _isSearch=false;
  bool isLoading=false;
  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();
  String _groupValue = "Male";
  String locationA="",locationB="";

  getSearch() async {

    final uri = API.searchTrip;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,
      "location_a_lat": widget.startLat.toString(),
      "location_a_long": widget.startLong.toString(),
      "location_b_lat": widget.endLat.toString(),
      "location_b_long": widget.endLong.toString(),
      "location_a_name": widget.locationAName,
      "location_b_name": widget.locationBName,
      "departure_datetime": widget.date,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    progressLoad();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        final list = data["data"];

        print(list.length);

        if(list.isEmpty)
        {
          showDisplayAllert(context:this.context,isSucces: false,message:data["message"]);
        }

        else{



          for(int i=0; i<list.length;i++){

            String trip_id = list[i]["trip_id"].toString();
            String user_id = list[i]["user_id"].toString();
            String seat_available = list[i]["seat_available"].toString();
            String start_time = list[i]["start_time"].toString();
            String interval_time = list[i]["interval_time"].toString();
            String booking_process = list[i]["booking_process"].toString();
            String first_name = list[i]["first_name"].toString();
            String last_name = list[i]["last_name"].toString();
            String birth_year = list[i]["birth_year"].toString();
            String from = list[i]["from"].toString();
            String to = list[i]["to"].toString();
            String total_price = list[i]["total_price"].toString();
            String departure_datetime = list[i]["departure_datetime"].toString();
            String seat_booked = list[i]["seat_booked"].toString();
            String location_a_lat = list[i]["location_a_lat"].toString();
            String location_a_long = list[i]["location_a_long"].toString();
            String location_b_lat = list[i]["location_b_lat"].toString();
            String location_b_long = list[i]["location_b_long"].toString();
            String image = list[i]["image"].toString();
            String google_image = list[i]["google_image"].toString();
            String facebook_image = list[i]["facebook_image"].toString();
            String email_varified = list[i]["email_varified"].toString();
            String identity_document_verified = list[i]["identity_document_verified"].toString();

            String rattingString = list[i]["avg_rating"]["avg_rating"];
            String avg_rating="0.0";
            if(rattingString!=null && rattingString!="")
            {
              avg_rating=rattingString;
            }
            else{
              avg_rating="0.0";
            }

//
//            List<Placemark> placemarkA= await Geolocator().placemarkFromCoordinates(double.parse(location_a_lat), double.parse(location_a_long));
//
//           String locationFrom=placemarkA[0].locality==""?placemarkA[0].subAdministrativeArea:placemarkA[0].locality;
//
//            List<Placemark> placemarkB= await Geolocator().placemarkFromCoordinates(double.parse(location_b_lat), double.parse(location_b_long));
//
//            String locationTo=placemarkB[0].locality==""?placemarkB[0].subAdministrativeArea:placemarkB[0].locality;

            listSearchResult.add(new SearchModel(trip_id, user_id, seat_available, start_time, interval_time, booking_process, first_name, last_name, birth_year, from, to, total_price, departure_datetime, seat_booked, location_a_lat, location_a_long, location_b_lat, location_b_long, google_image, facebook_image, image, email_varified, identity_document_verified,avg_rating));

            setState(() {

            });

          }



        }



      } else {


        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {

      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }


  getHeaderData()async{

    List<Placemark> placemarkA= await Geolocator().placemarkFromCoordinates(widget.startLat, widget.startLong);

     locationA=placemarkA[0].locality==""?placemarkA[0].subAdministrativeArea:placemarkA[0].locality;

    List<Placemark> placemarkB= await Geolocator().placemarkFromCoordinates(widget.endLat,widget.endLong);

    locationB=placemarkB[0].locality==""?placemarkB[0].subAdministrativeArea:placemarkB[0].locality;;
    setState(() {

    });

  }

  @override
  void initState() {

   progressLoad();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
    //  getHeaderData();
      getSearch();

    });





  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      key: _scaffoldKey,

     //   bottomNavigationBar: BottomDrawerWidgget(),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          width: double.maxFinite,
          child: !isLoading ?SingleChildScrollView(
            child:    Column(children: <Widget>[
              SizedBox(height: AppSize.medium,),
              Form(
                  key: _loginFormKey,
                  child: Container(
                   //width: screenSize.width,
                    child: Column(children: <Widget>[

                      InkWell(
                        onTap: (){
                          AppRoutes.dismiss(context);
                        },
                        child: Container(
                         // alignment: Alignment.centerLeft,
                          margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              left:2.0*SizeConfig.widthMultiplier,
                              top:1.0*SizeConfig.heightMultiplier,
                              bottom:0.0*SizeConfig.heightMultiplier,
                              right:2.0*SizeConfig.widthMultiplier),
                          decoration:  BoxDecoration(
                            color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(width: 1.0,color: Colors.grey[200])
                          ),

                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Icon(Icons.arrow_back_ios,color: Colors.grey,size: AppSize.medium,),
                                Container(
                                    width: SizeConfig.widthMultiplier*37,
                                    child: Text(widget.locationAName, softWrap: false,overflow: TextOverflow.ellipsis,style: TextStyle(color: Colors.blueGrey,fontSize: 2.0*SizeConfig.textMultiplier),)),

                                Icon(Icons.arrow_forward,color: Colors.grey,size: AppSize.smallMedium),

                                Container(
                                    width: SizeConfig.widthMultiplier*37,
                                    child: Text(widget.locationBName, softWrap: false,overflow: TextOverflow.ellipsis,style: TextStyle(color: Colors.blueGrey,fontSize: 2.0*SizeConfig.textMultiplier),))

                              ],),
                            Container(
                                padding: EdgeInsets.only(
                                    left:7.0*SizeConfig.widthMultiplier,
                                    top:1.0*SizeConfig.heightMultiplier,
                                    bottom:1.0*SizeConfig.heightMultiplier,
                                    right:2.0*SizeConfig.widthMultiplier),
                                child: Text(widget.date,style: TextStyle(color: Colors.grey,fontSize: 1.5*SizeConfig.textMultiplier),))

                          ],)
                        ),
                      ),


                      SizedBox(height: AppSize.large,),

                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: listSearchResult.length,
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          String img = listSearchResult[index].image;
                          print(img);
                          return SearcgTripsWidget(
                            document: listSearchResult[index].identity_document_verified,
                              email: listSearchResult[index].email_varified,
                              rating: listSearchResult[index].ratting,
                              years: listSearchResult[index].birth_year,
                              imageUrl:img=="null"?listSearchResult[index].facebook_image:API.baseProfileImageUrl+listSearchResult[index].image,
                              customerName: listSearchResult[index].first_name+" "+listSearchResult[index].last_name,
                              locationFrom:listSearchResult[index].from,
                              locationTo:listSearchResult[index].to,
                              dateTime: listSearchResult[index].departure_datetime,
                              noOfSeatToBook: listSearchResult[index].seat_available,
                              paidAmount: listSearchResult[index].total_price,
                          onTap: (){
                              String driverId=listSearchResult[index].user_id;
                              if(driverId==userIdMain)
                                {
                                  AppRoutes.goto(context,PostTripDetailsScreen(listSearchResult[index].trip_id));
                                }
                              else{
                                AppRoutes.goto(context,SearchTripDetailsScreen( postId: listSearchResult[index].trip_id,locationAName: widget.locationAName,
                                  locationBName: widget.locationBName,dateTime: widget.date,price: listSearchResult[index].total_price ,));

                              }
                             },);
                        },
                      ),



                    ],),
                  ),
                ),


            ],),
          ):
          Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),
        ),
      ),
    );
  }


  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }
}
