import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pin_entry_text_field/pin_entry_text_field.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:path/path.dart';
import 'package:async/async.dart';

class VerificationScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _VerificationScreen();
}

class _VerificationScreen extends State<VerificationScreen> {
  File documentImage = null;
  bool _isVerifiyPhoneClick = false;
  bool isLoding = false;
  String documentStatus = "";
  String documentImageUrl = "";
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String _groupValue = "1";
  TextEditingController emailController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();

  String first_name = "",
      last_name = "",
      email = "",
      phoneCode = "",
      id = "",
      user_type = "",
      reg_type = "",
      google_id = "",
      facebook_id = "",
      user_name = "",
      gender = "",
      google_email = "",
      facebook_email = "",
      email_varified = "",
      image = "",
      google_image = "",
      facebook_image = "",
      driving_id = "",
      drive_frontimage = "",
      drive_backimage = "",
      drive_image_verification = "",
      driving_cancle_cause = "",
      driving_exp = "",
      phone_code = "",
      phone = "",
      phone_verification = "",
      birth_year = "",
      bio = "",
      identity_document_verified = "",
      profile_image_status = "",
      status = "",
      device_type = "",
      device_token = "",
      added_date = "",
      update_date;

  SendOtp() async {
    final uri = API.sendOtp;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": id,
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');

    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
          ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(jsonBody);
    print(response.body);
    phoneVerifiyClickToggle();
    if (statusCode == 200) {
      if (data["status"] == "true") {
        showDisplayAllert(
            context: this.context, isSucces: true, message: (data["message"]));

        _showOtpAlert(this.context);
      } else {
        String dataString = data["message"].toString();
//        dataString = dataString
//            .substring(dataString.indexOf(":"), dataString.length)
//            .replaceAll(":", "")
//            .replaceAll("{", "")
//            .replaceAll("}", "")
//            .replaceAll("[", "")
//            .replaceAll("]", "");

        showDisplayAllert(
            context: this.context, isSucces: false, message: dataString);
      }
    } else {
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }

  VerifyOtp(String otp) async {
    final uri = API.verifyOtp;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": id,
      "verifyCode": otp,
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');

    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
          ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(jsonBody);
    print(response.body);
    phoneVerifiyClickToggle();


    if (statusCode == 200) {
      if (data["status"] == "true") {
        ShareMananer.UpdatePhoneVerificationStatus("1");
        setState(() {
          phone_verification = "1";
        });

        showDisplayAllert(
            context: this.context, isSucces: true, message: (data["message"]));
      } else {
        String dataString = data["message"].toString();
        dataString = dataString
            .substring(dataString.indexOf(":"), dataString.length)
            .replaceAll(":", "")
            .replaceAll("{", "")
            .replaceAll("}", "")
            .replaceAll("[", "")
            .replaceAll("]", "");

        showDisplayAllert(
            context: this.context, isSucces: false, message: dataString);
      }
    } else {
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }

  getUserDitails() async {
    final uri = API.getUserDetails;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": id,
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');

    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
          ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(jsonBody);
    print(response.body);
    loadProgress();
    if (statusCode == 200) {
      if (data["status"] == true) {
        id = data["data"]["id"].toString();
        user_type = data["data"]["user_type"].toString();
        reg_type = data["data"]["reg_type"].toString();
        google_id = data["data"]["google_id"].toString();
        facebook_id = data["data"]["facebook_id"].toString();
        user_name = data["data"]["user_name"].toString();
        first_name = data["data"]["first_name"].toString();
        last_name = data["data"]["last_name"].toString();
        gender = data["data"]["gender"].toString();
        email = data["data"]["email"].toString();
        google_email = data["data"]["google_email"].toString();
        facebook_email = data["data"]["facebook_email"].toString();
        email_varified = data["data"]["email_varified"].toString();
        image = data["data"]["image"].toString();
        google_image = data["data"]["google_image"].toString();
        facebook_image = data["data"]["facebook_image"].toString();
        driving_id = data["data"]["driving_id"].toString();
        drive_frontimage = data["data"]["drive_frontimage"].toString();
        drive_backimage = data["data"]["drive_backimage"].toString();
        drive_image_verification =
            data["data"]["drive_image_verification"].toString();
        driving_cancle_cause = data["data"]["driving_cancle_cause"].toString();

        driving_exp = data["data"]["driving_exp"].toString();
        phone_code = data["data"]["phone_code"].toString();
        phone = data["data"]["phone"].toString();
        phone_verification = data["data"]["phone_verification"].toString();
        birth_year = data["data"]["birth_year"].toString();
        bio = data["data"]["bio"].toString();
        identity_document_verified =
            data["data"]["identity_document_verified"].toString();
        profile_image_status = data["data"]["profile_image_status"].toString();
        status = data["data"]["status"].toString();
        device_type = data["data"]["device_type"].toString();
        device_token = data["data"]["device_token"].toString();
        added_date = data["data"]["added_date"].toString();
        update_date = data["data"]["update_date"].toString();
        String  rating = data["rating"]["avg_rating"]["avg_rating"].toString();
        List list = data["rating"]["rating_master"];

        ShareMananer.setLoginDetails(id, user_type, reg_type, google_id, facebook_id, user_name, first_name,last_name, gender,
            email, google_email, facebook_email, email_varified, image, google_image, facebook_image, driving_id,
            drive_frontimage, drive_backimage, drive_image_verification, driving_cancle_cause, driving_exp,
            phone_code, phone, phone_verification, birth_year, bio, identity_document_verified, profile_image_status,
            status, device_type, device_token, added_date, update_date, rating,list.length.toString(),true);


        List documentList = data["identity_image"]["img_data"];
        if (identity_document_verified != "0") {

          setState(() {
            documentImageUrl = documentList[documentList.length - 1]["file_name"];

          });


          if(identity_document_verified=="0")
            {

              documentStatus=Constants.notApplied;

            }else if(identity_document_verified=="1"){

            documentStatus=Constants.verified;

          }else if(identity_document_verified=="2"){
            documentStatus=Constants.appliedNotApprovedYet;
          }
          else if(identity_document_verified=="3"){
            documentStatus=Constants.yourIDRejected;
          }



          print(documentImageUrl);
        }
      } else {
        loadProgress();
        String dataString = data["message"].toString();
        dataString = dataString
            .substring(dataString.indexOf(":"), dataString.length)
            .replaceAll(":", "")
            .replaceAll("{", "")
            .replaceAll("}", "")
            .replaceAll("[", "")
            .replaceAll("]", "");

        showDisplayAllert(
            context: this.context, isSucces: false, message: dataString);
      }
    } else {
      loadProgress();
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }

  UploadDocument() async {
    var uri = Uri.parse(API.uploadDocument);
    var stream =
        new http.ByteStream(DelegatingStream.typed(documentImage.openRead()));
    var length = await documentImage.length();

    MultipartFile multipartFile = new MultipartFile('document', stream, length,
        filename: basename(documentImage.path));

    var request = new MultipartRequest("POST", uri);
    request.files.add(multipartFile);
    request.fields["user_id"] = id;
    request.fields["type"] = _groupValue;

    request.headers[HttpHeaders.contentTypeHeader] =
        'multipart/form-data;charset=utf-8';
    request.send().then((response) async {
      loadProgress();
      if (response.statusCode == 200) {
        print("Uploaded!");

        final data = json.decode(await response.stream.bytesToString());
        print(data.toString());


        showDisplayAllert(
            context: this.context, isSucces: true, message: (data["message"]));
      } else {

        showDisplayAllert(
            context: this.context,
            isSucces: false,
            message: response.reasonPhrase);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.verification,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: screenSize.width,
        height: screenSize.height,
        child: Stack(children: <Widget>[
          SingleChildScrollView(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: AppSize.medium,
                ),
                Container(
                  width: screenSize.width * .95,
                  child: Column(
                    children: <Widget>[
                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left: 3.0 * SizeConfig.widthMultiplier,
                            right: 3.0 * SizeConfig.widthMultiplier),
                        decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(15),
                            border:
                            Border.all(width: 1.0, color: Colors.grey[200])),
                        child: Row(
                          children: <Widget>[
                            Container(
                              width: SizeConfig.widthMultiplier * 70,
                              child: TextFormField(
                                validator: (String value) {
                                  return FieldValidator.validateEmptyCheck(value);
                                },
                                controller: emailController,
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: 16.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  labelText: Constants.enterEmail,
                                  labelStyle: TextStyle(
                                      color: Colors.grey,
                                      fontSize: AppFontSize.s16),
                                  border: InputBorder.none,
                                  icon: email_varified == "0"
                                      ? Icon(
                                    Icons.email,
                                    color: Colors.grey,
                                    size: AppFontSize.textIcon,
                                  )
                                      : Icon(
                                    Icons.email,
                                    color: AppTheme.primaryColor,
                                    size: AppFontSize.textIcon,
                                  ),
                                ),
                                readOnly: true,
                              ),
                            ),
                            Container(
                              // width: SizeConfig.widthMultiplier*15,
                                child: Text(
                                  email_varified == "0"? Constants.verify:Constants.verified,
                                  style: AppTheme.textStyle.heading1.copyWith(
                                      color: AppTheme.primaryColor,
                                      fontSize: AppFontSize.s18),
                                  textAlign: TextAlign.right,
                                )),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: AppSize.medium,
                      ),
                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left: 3.0 * SizeConfig.widthMultiplier,
                            right: 3.0 * SizeConfig.widthMultiplier),
                        decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(15),
                            border:
                            Border.all(width: 1.0, color: Colors.grey[200])),
                        child: Row(
                          children: <Widget>[
                            Container(
                              width: SizeConfig.widthMultiplier * 70,
                              child: TextFormField(
                                controller: phoneController,
                                validator: (String value) {
                                  return FieldValidator.validateEmptyCheck(value);
                                },
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: 16.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  labelText: Constants.yourPhoneNumber,
                                  labelStyle: TextStyle(
                                      color: Colors.grey,
                                      fontSize: AppFontSize.s16),
                                  border: InputBorder.none,
                                  icon: phone_verification == "0"
                                      ? Icon(
                                    Icons.phone_android,
                                    color: Colors.grey,
                                    size: AppFontSize.textIcon,
                                  )
                                      : Icon(
                                    Icons.phone_android,
                                    color: AppTheme.primaryColor,
                                    size: AppFontSize.textIcon,
                                  ),
                                ),
                                readOnly: true,
                              ),
                            ),
                            Container(
                              // width: SizeConfig.widthMultiplier*15,
                              child: GestureDetector(
                                  onTap: () {
                                    if (phone_verification == "0") {
                                      phoneVerifiyClickToggle();
                                      SendOtp();
                                    }
                                  },
                                  child: !_isVerifiyPhoneClick
                                      ? Text(
                                    phone_verification == "0"? Constants.verify:Constants.verified,
                                    style: AppTheme.textStyle.heading1
                                        .copyWith(
                                        color: AppTheme.primaryColor,
                                        fontSize: AppFontSize.s18),
                                    textAlign: TextAlign.justify,
                                  )
                                      : CircularProgressIndicator(
                                    backgroundColor: AppTheme.accentColor,
                                    valueColor:
                                    new AlwaysStoppedAnimation<Color>(
                                        AppTheme.primaryColor),
                                  )),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: AppSize.medium,
                      ),
                      Container(
                        margin: EdgeInsets.all(10.0),
                        child: Text(
                          Constants.verificationDocumentText,
                          style: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.s16),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                      SizedBox(
                        height: AppSize.medium,
                      ),
                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left: 3.0 * SizeConfig.widthMultiplier,
                            right: 3.0 * SizeConfig.widthMultiplier),
                        decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(15),
                            border:
                            Border.all(width: 1.0, color: Colors.grey[200])),
                        child: Column(
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                    width: SizeConfig.widthMultiplier * 10,
                                    child: Icon(
                                      Icons.file_upload,
                                      color: Colors.grey,
                                      size: AppFontSize.textIcon,
                                    )),
                                Container(
                                    alignment: Alignment.centerLeft,
                                    height: AppSize.xxL,
                                    width: SizeConfig.widthMultiplier * 62,
                                    child: Text(
                                      Constants.uploadDocument,
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: AppFontSize.s16),
                                      textAlign: TextAlign.justify,
                                    )),
                                Container(
                                  //  width: SizeConfig.widthMultiplier*15,
                                    child: Text(
                                      Constants.verify,
                                      style: AppTheme.textStyle.heading1.copyWith(
                                          color: AppTheme.primaryColor,
                                          fontSize: AppFontSize.s18),
                                      textAlign: TextAlign.right,
                                    )),
                              ],
                            ),
                            Container(
                              child: GestureDetector(
                                onTap: () {

                                  if(identity_document_verified=="0" ||identity_document_verified=="3")
                                  {

                                    showDocumentUploadPopup();
                                  }
                                  else{
                                    showDisplayAllert(context: context,isSucces: false,message: documentStatus);
                                  }

                                },
                                child: documentImageUrl==""?Icon(
                                  Icons.note_add,
                                  size: AppSize.xxL,
                                  color: Colors.grey,
                                ):documentImage!=null?Image.file(documentImage):Image.network(API.baseDocumentImageUrl+documentImageUrl),),
                            ),

                            SizedBox(
                              height: AppSize.extraSmall,
                            ),

                            Container(
                              child:Row(

                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text("* ",style: TextStyle(color: Colors.red[700]),),
                                  Text(documentStatus,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s10)),
                                ],),
                            ),
                            SizedBox(
                              height: AppSize.medium,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: AppSize.medium,
                      ),
                      Container(
                        margin: EdgeInsets.all(10.0),
                        child: Text(
                          Constants.verificationTermsAndCondition,
                          style: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.s16),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                      SizedBox(
                        height: AppSize.large,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: AppSize.medium,
                ),
              ],
            ),
          ),
          isLoding? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),
        ],)
      ),
    );
  }

  @override
  void initState() {
    ShareMananer.getUserDetails().then((data) {
      id = data["id"];
      user_type = data["nuser_typeame"];
      reg_type = data["reg_type"];
      google_id = data["google_id"];
      facebook_id = data["facebook_id"];
      user_name = data["user_name"];
      first_name = data["first_name"];
      last_name = data["last_name"];
      gender = data["gender"];
      email = data["email"];
      google_email = data["google_email"];
      facebook_email = data["facebook_email"];
      email_varified = data["email_varified"];
      image = data["image"];
      google_image = data["google_image"];
      facebook_image = data["facebook_image"];
      driving_id = data["driving_id"];
      drive_frontimage = data["drive_frontimage"];
      drive_backimage = data["drive_backimage"];
      drive_image_verification = data["drive_image_verification"];
      driving_cancle_cause = data["driving_cancle_cause"];
      driving_exp = data["driving_exp"];
      phone_code = data["phone_code"];
      phone = data["phone"];
      phone_verification = data["phone_verification"];
      birth_year = data["birth_year"];
      bio = data["bio"];
      identity_document_verified = data["identity_document_verified"];
      profile_image_status = data["profile_image_status"];
      status = data["status"];
      device_type = data["device_type"];
      device_token = data["device_token"];
      added_date = data["navme"];
      update_date = data["update_date"];
      phoneCode = data["phone_code"];

      emailController.text = email;
      phoneController.text = phoneCode + phone;
      loadProgress();
      getUserDitails();
    });
  }

  Future<bool> _showOtpAlert(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Verify Your OTP"),
            content: SingleChildScrollView(
              child: PinEntryTextField(
                showFieldAsBox: true,
                onSubmit: (String pin) {
                  phoneVerifiyClickToggle();
                  VerifyOtp(pin);
                  Navigator.pop(context);
                },
                // end onSubmit
              ),
            ),
          );
        });
  }

  void phoneVerifiyClickToggle() {
    setState(() {
      _isVerifiyPhoneClick = !_isVerifiyPhoneClick;
    });
  }

  void showDocumentUploadPopup() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              _openGallery(BuildContext context) async {
                var picture =
                    await ImagePicker.pickImage(source: ImageSource.gallery,imageQuality: 20);

                setState(() {
                  documentImage = picture;
                  // base64Image=base64Encode(picture.readAsBytesSync());
                });
                Navigator.of(context).pop();
              }

              _openCamera(BuildContext context) async {
                var picture =
                    await ImagePicker.pickImage(source: ImageSource.camera,imageQuality: 20);

                setState(() {
                  documentImage = picture;
                  identity_document_verified="2";
                });
                Navigator.of(context).pop();
              }

              Future<bool> _showImagePicker(BuildContext context) {
                return showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text("Make Your Choice"),
                        content: SingleChildScrollView(
                          child: ListBody(
                            children: <Widget>[
                              GestureDetector(
                                onTap: () {
                                  _openGallery(context);
                                },
                                child: Text("Gallery"),
                              ),
                              SizedBox(
                                height: AppSize.medium,
                              ),
                              GestureDetector(
                                onTap: () {
                                  _openCamera(context);
                                },
                                child: Text("Camera"),
                              ),
                            ],
                          ),
                        ),
                      );
                    });
              }

              return AlertDialog(
                content: Container(
                  width: double.maxFinite,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      SizedBox(
                        height: AppSize.extraSmall,
                      ),
                      Container(
                        child: Text(
                          Constants.whatIsYourIdentityDocument,
                          style: AppTheme.textStyle.heading1.copyWith(
                              color: Colors.black, fontSize: AppFontSize.s16),
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Container(
                              //width: SizeConfig.widthMultiplier * 40,
                              child: Row(
                            children: <Widget>[
                              Radio(
                                onChanged: (newValue) {
                                  setState(() {
                                    _groupValue = newValue;
                                    //  radioVal=newValue;
                                  });
                                },
                                value: "1",
                                activeColor: AppTheme.accentColor,
                                groupValue: _groupValue,
                              ),
                              Text(
                                Constants.IdCard,
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: AppFontSize.textHint,
                                    color: Colors.black),
                              ),
                            ],
                          )),
                          Container(
                              //  width: SizeConfig.widthMultiplier * 40,
                              child: Row(
                            children: <Widget>[
                              Radio(
                                activeColor: AppTheme.accentColor,
                                onChanged: (newValue) {
                                  setState(() {
                                    _groupValue = newValue;
                                    //radioVal=newValue;
                                  });
                                },
                                value: "2",
                                groupValue: _groupValue,
                              ),
                              Text(
                                Constants.passport,
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: AppFontSize.textHint,
                                    color: Colors.black),
                              ),
                            ],
                          )),
                        ],
                      ),
                      SizedBox(
                        height: AppSize.small,
                      ),
                      Container(
                          width: SizeConfig.widthMultiplier * 80,
                          height: SizeConfig.heightMultiplier * 20,
                          decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: new BorderRadius.circular(20.0)),
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                _showImagePicker(context);
                              });
                            },
                            child: documentImage != null
                                ? Container(
                                    decoration: BoxDecoration(
                                    image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: FileImage(documentImage)),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.0)),
                                    // color: Colors.redAccent,
                                  ))
                                : Container(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Icon(
                                          Icons.camera_alt,
                                          size: AppSize.xxL,
                                          color: Colors.grey,
                                        ),
                                        Text(
                                          Constants.addPhoto,
                                          style: AppTheme.textStyle.lightHeading
                                              .copyWith(
                                                  color: Colors.grey,
                                                  fontSize: AppFontSize.s14),
                                        )
                                      ],
                                    ),
                                  ),
                          )),
                      SizedBox(
                        height: AppSize.medium,
                      ),
                      !isLoding
                          ? CustomRoundButtonWidget(
                              title: Constants.uploadDocument,
                              callback: () {
                                loadProgress();
                                UploadDocument();
                                AppRoutes.dismiss(context);
                              },
                            )
                          : CircularProgressIndicator(
                              backgroundColor: AppTheme.accentColor,
                              valueColor: new AlwaysStoppedAnimation<Color>(
                                  AppTheme.primaryColor),
                            ),
                      SizedBox(
                        height: AppSize.medium,
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        });
  }

  void loadProgress() {
    setState(() {
      isLoding = !isLoding;
    });
  }
}
