import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/reservation_cancel_wiget.dart';
import 'package:vamos/components/reservation_history_wiget.dart';
import 'package:vamos/model/booking_model.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class ReservationCancelScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _ReservationCancelScreen();
}

class _ReservationCancelScreen extends State<ReservationCancelScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String userIdMain="";
  bool isLoding=false;
  bool hasData =true;
  List<BookingModel>listBooking= new List();

  getBooking() async {

    final uri = API.getReservationCancel;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,

    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    loadProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {
        List list =data["data"]["data"];

        if(list.isEmpty)
        {
          hasData=false;
          showDisplayAllert(context:context,isSucces: true,message: "No se han encontrado resultados");
        }
        else{

          for(int i =0;i<list.length;i++){
            String id = list[i]["id"].toString();
            String trackId = list[i]["trackId"].toString();
            String transaction_id = list[i]["transaction_id"].toString();
            String transaction_details = list[i]["transaction_details"].toString();
            String user_id = list[i]["user_id"].toString();
            String driver_id = list[i]["driver_id"].toString();
            String trip_id = list[i]["trip_id"].toString();
            String booking_type = list[i]["booking_type"].toString();
            String driver_accept = list[i]["driver_accept"].toString();
            String request_time = list[i]["request_time"].toString();
            String booking_status = list[i]["booking_status"].toString();
            String reminder_email_status = list[i]["reminder_email_status"].toString();
            String refund_status = list[i]["refund_status"].toString();
            String refunded_amount = list[i]["refunded_amount"].toString();
            String cancel_reason = list[i]["cancel_reason"].toString();
            String reason_category = list[i]["reason_category"].toString();
            String booking_location_start_id = list[i]["booking_location_start_id"].toString();
            String booking_location_end_id = list[i]["booking_location_end_id"].toString();
            String total_distance = list[i]["total_distance"].toString();
            String total_price = list[i]["total_price"].toString();
            String no_of_seat = list[i]["no_of_seat"].toString();
            String trip_completed_mail_sent = list[i]["trip_completed_mail_sent"].toString();
            String trip_completed_mail_sent_five_days_after = list[i]["trip_completed_mail_sent_five_days_after"].toString();
            String added_date = list[i]["added_date"].toString();
            String updated_date = list[i]["updated_date"].toString();
            String location_a_name = list[i]["location_a_name"].toString();
            String location_b_name = list[i]["location_b_name"].toString();
            String first_name = list[i]["user"]["first_name"].toString();
            String last_name = list[i]["user"]["last_name"].toString();
            String image = list[i]["user"]["image"].toString();
            String facebook_image = list[i]["user"]["facebook_image"].toString();

            String rattingString = list[i]["user"]["avg_rating"]["avg_rating"];
            String avg_rating="0.0";
            if(rattingString!=null && rattingString!="")
            {
              avg_rating=rattingString;
            }
            else{
              avg_rating="0.0";
            }


            print(avg_rating);

            listBooking.add(new BookingModel(id, trackId, transaction_id, transaction_details, user_id, driver_id,
                trip_id, booking_type, driver_accept, request_time, booking_status, reminder_email_status,
                refund_status, refunded_amount, cancel_reason, reason_category, booking_location_start_id,
                booking_location_end_id, total_distance, total_price, no_of_seat, trip_completed_mail_sent,
                trip_completed_mail_sent_five_days_after, added_date,
                updated_date, location_a_name, location_b_name, first_name, last_name, image, facebook_image,avg_rating));
          }



        }

      } else {

        String dataString = data["message"].toString();
       // dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }
    setState(() {
    });

  }

  @override
  void initState() {
    loadProgress();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      getBooking();

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.reservationCancel,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: screenSize.width,
        height: screenSize.height,
        child: Stack(children: <Widget>[
          ListView.builder(
            itemCount: listBooking.length,
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index) {
              String img = listBooking[index].image;
              return ReservationCancelWidget(
                onTap: (){
                  reasonPopup(context,index);
                },
                  imageUrl: img==""?listBooking[index].facebook_image:API.baseProfileImageUrl+listBooking[index].image,
                  customerName: listBooking[index].first_name+" "+listBooking[index].last_name,
                  locationFrom: listBooking[index].location_a_name,
                  locationTo:listBooking[index].location_b_name,
                  rating: listBooking[index].avg_rating,
                  dateTime: listBooking[index].request_time,
                  noOfSeatToBook: listBooking[index].no_of_seat,
                  paidAmount: listBooking[index].total_price);
            },
          ),
          isLoding? Container(
            // color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),

          !hasData? Container(
            color: Colors.white,
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child:Text(Constants.noDataAvailable,style: AppTheme.textStyle.alertText.copyWith(color: Colors.black),)),

          ):SizedBox(height: 0.0,),
        ],),
      ),
    );
  }


  void loadProgress(){
    setState(() {
      isLoding =!isLoding;
    });

  }


  Future<bool>reasonPopup(BuildContext context,int index)
  {
    return showDialog(context: context,
        builder: (BuildContext context){
          return StatefulBuilder(
            builder: (context,setState){{
              return AlertDialog(
                title: Text(Constants.cancel_reason),
                content: Column(
                  mainAxisSize:MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Container(child: Text(Constants.reasonCategory+":",style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s16),),),
                    Container(child: Text(listBooking[index].reason_category),),
                    SizedBox(height: 10.0,),
                    Container(child: Text(Constants.cancel_reason+":",style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s16),),),
                    Container(child: Text(listBooking[index].cancel_reason),),


                    SizedBox(height: 20.0,),
                    Container(
                      width: SizeConfig.widthMultiplier * 30,
                      child: CustomRoundButtonWidget(
                        buttonWidth:SizeConfig.widthMultiplier * 30 ,
                        title: Constants.close,
                        callback: () {
                          Navigator.pop(context);

                        },
                      ),
                    ),
                  ],),
              );
            }
            },
          );
        });
  }
}
