import 'dart:convert';

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/booking_request_wiget.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/model/booking_model.dart';
import 'package:vamos/screens/post_trip_details.dart';
import 'package:vamos/screens/search_details_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

import 'chatting_screen.dart';

class BookingRequestScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _BookingRequestScreen();
}

class _BookingRequestScreen extends State<BookingRequestScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
String userIdMain="", mainUserName="";
bool isLoding=false;
bool isAction=false;
bool hasData=true;
List<BookingModel>listBooking= new List();
List<Item> reasonList = List();
Item reason;
String mainUserImage="";
TextEditingController reasonController= new TextEditingController();

  getBooking() async {

    final uri = API.bookingRequest;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,

    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    loadProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {
        List list =data["data"]["data"][0]["req_models"];

        if(list.isEmpty)
          {
            hasData=false;
            showDisplayAllert(context:context,isSucces: true,message: "No se han encontrado resultados");
          }
        else{

          for(int i =0;i<list.length;i++){
            String id = list[i]["id"].toString();
            String trackId = list[i]["trackId"].toString();
            String transaction_id = list[i]["transaction_id"].toString();
            String transaction_details = list[i]["transaction_details"].toString();
            String user_id = list[i]["user_id"].toString();
            String driver_id = list[i]["driver_id"].toString();
            String trip_id = list[i]["trip_id"].toString();
            String booking_type = list[i]["booking_type"].toString();
            String driver_accept = list[i]["driver_accept"].toString();
            String request_time = list[i]["request_time"].toString();
            String booking_status = list[i]["booking_status"].toString();
            String reminder_email_status = list[i]["reminder_email_status"].toString();
            String refund_status = list[i]["refund_status"].toString();
            String refunded_amount = list[i]["refunded_amount"].toString();
            String cancel_reason = list[i]["cancel_reason"].toString();
            String reason_category = list[i]["reason_category"].toString();
            String booking_location_start_id = list[i]["booking_location_start_id"].toString();
            String booking_location_end_id = list[i]["booking_location_end_id"].toString();
            String total_distance = list[i]["total_distance"].toString();
            String total_price = list[i]["total_price"].toString();
            String no_of_seat = list[i]["no_of_seat"].toString();
            String trip_completed_mail_sent = list[i]["trip_completed_mail_sent"].toString();
            String trip_completed_mail_sent_five_days_after = list[i]["trip_completed_mail_sent_five_days_after"].toString();
            String added_date = list[i]["added_date"].toString();
            String updated_date = list[i]["updated_date"].toString();
            String location_a_name = list[i]["location_a_name"].toString();
            String location_b_name = list[i]["location_b_name"].toString();
            String first_name = list[i]["user"]["first_name"].toString();
            String last_name = list[i]["user"]["last_name"].toString();
            String image = list[i]["user"]["image"].toString();
            String facebook_image = list[i]["user"]["facebook_image"].toString();
            String rattingString = list[i]["user"]["avg_rating"]["avg_rating"];
            String avg_rating="0.0";
            if(rattingString!=null && rattingString!="")
            {
              avg_rating=rattingString;
            }
            else{
              avg_rating="0.0";
            }

            listBooking.add(new BookingModel(id, trackId, transaction_id, transaction_details, user_id, driver_id,
                trip_id, booking_type, driver_accept, request_time, booking_status, reminder_email_status,
                refund_status, refunded_amount, cancel_reason, reason_category, booking_location_start_id,
                booking_location_end_id, total_distance, total_price, no_of_seat, trip_completed_mail_sent,
                trip_completed_mail_sent_five_days_after, added_date,
                updated_date, location_a_name, location_b_name, first_name, last_name, image, facebook_image,avg_rating));
          }



        }

      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }

      setState(() {
      });
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }



  }
  getReason() async {

    final uri = API.getReasonCategory;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
//      "user_id": userIdMain,
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    if (statusCode == 200) {
      if (data["status"] == "true") {
        List list =data["data"]["data"];

        for(int i =0;i<list.length;i++)
          {
            reasonList.add(new Item(list[i]));
          }
        setState(() {
        print(reasonList.length);
        });



      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  acceptBookingRequest(String bookingId,int index) async {

    final uri = API.acceptRequestFromDriver;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "booking_id": bookingId,

    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    actionProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {
        showDisplayAllert(context:context,isSucces: false,message: data["message"].toString());
        listBooking.removeAt(index);
        setState(() {

        });

      } else {

        String dataString = data["message"].toString();
       // dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }
  rejectBookingRequest(String bookingId,int index) async {

    final uri = API.rejectRequestFromDriver;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "booking_id": bookingId,
      "reason_category": reason.name,
      "reason": reasonController.text.toString(),

    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    actionProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {
        showDisplayAllert(context:context,isSucces: false,message: data["message"].toString());
        listBooking.removeAt(index);
        setState(() {

        });

      } else {

        String dataString = data["message"].toString();
      //  dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  @override
  void initState() {
    loadProgress();
    getReason();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      mainUserName = data["first_name"]+" "+ data["last_name"];
      String img =data["image"];
      String fb =data["facebook_image"];

      if(img=="" || img=="null")
      {
        mainUserImage=API.baseProfileImageUrl+img;
      }
      else{
        mainUserImage=fb;
      }
      print(userIdMain);
      getBooking();

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.bookingRequest,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: screenSize.width,
        height: screenSize.height,
        child:Stack(children: <Widget>[
          ListView.builder(
            itemCount: listBooking.length,
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index) {
              String img = listBooking[index].image;
              return BookingWidget(
                onTabDetails: (){
                  AppRoutes.goto(context, PostTripDetailsScreen(listBooking[index].trip_id));
                },
                onAcceptTap: (){
                  actionProgress();
                  acceptBookingRequest(listBooking[index].id,index);
                },
                  onRejectTab: (){
                    rejectPopup(context,index,listBooking[index].id);
                  },

                  onTabChat: (){
                    AppRoutes.goto(
                        context,
                        ChattingScreen(
                          mainUserProfile: mainUserImage,
                          chatUserId: listBooking[index].user_id,
                          fcmToken:" widget.fcmToken",
                          mainUserID: userIdMain,
                          mainUserName: mainUserName,
                          chatUserName:listBooking[index].first_name+" "+listBooking[index].last_name,
                        ));
                  },

                  imageUrl:img==""?listBooking[index].facebook_image:API.baseProfileImageUrl+listBooking[index].image,
                  customerName: listBooking[index].first_name+" "+listBooking[index].last_name,
                  locationFrom: listBooking[index].location_a_name,
                  locationTo:listBooking[index].location_b_name ,
                  dateTime1: listBooking[index].request_time,
                  dateTime2: listBooking[index].added_date,
                  email: "",
                rating: listBooking[index].avg_rating,);
            },
          ),
          isLoding? Container(
            // color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),
          isAction? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),



          !hasData? Container(
            color: Colors.white,
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child:Text(Constants.noDataAvailable,style: AppTheme.textStyle.alertText.copyWith(color: Colors.black),)),

          ):SizedBox(height: 0.0,),

        ],),
      ),
    );
  }


  void loadProgress(){
    setState(() {
      isLoding =!isLoding;
    });

  }

  void actionProgress(){
    setState(() {
      isAction =!isAction;
    });

  }

  Future<bool>rejectPopup(BuildContext context,int index,String bookingId)
  {
    return showDialog(context: context,
        builder: (BuildContext context){
          return StatefulBuilder(
            builder: (context,setState){{
            return AlertDialog(
              title: Text("Make Your Choice"),
              content: Column(
                mainAxisSize:MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Container(child: Text(Constants.whyDoYouWantToCancel),),
                  SizedBox(height: 10.0,),
                  Container(
                    padding: EdgeInsets.only(left: 10.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                            width: 1.0, color: Colors.grey[200])),
                    child: DropdownButton<Item>(
                      isExpanded:true,
                      hint: Text(Constants.selectReason),
                      value: reason,
                      onChanged: (Item Value) {
                        setState(() {
                          reason = Value;
                          print(Value.name);
                        });
                      },
                      underline: SizedBox(
                        width: 1.0,
                      ),
                      items: reasonList.map((Item user) {
                        return DropdownMenuItem<Item>(
                          value: user,
                          child: Row(
                            children: <Widget>[
                              Container(
                                child: Expanded(
                                  child: Text(
                                    user.name,
                                    style: TextStyle(color: Colors.black,fontSize: AppFontSize.s14,),
                                    maxLines: 2,

                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  SizedBox(height: 10.0,),
                  Container(
                    width: double.maxFinite,

                    padding: EdgeInsets.only(
                        left: 1.0 * SizeConfig.widthMultiplier,
                        right: 1.0 * SizeConfig.widthMultiplier),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                            width: 1.0, color: Colors.grey[200])),
                    child: Column(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(top: 5.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Icon(Icons.speaker_notes,
                                  color: AppTheme.primaryColor),
                              SizedBox(
                                width: AppSize.small,
                              ),
                              Text(
                                Constants.details,
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: AppFontSize.textHint,
                                    color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                        TextFormField(

                          minLines: 2,
                          maxLines: 6,
                          onTap: () {},
                          validator: (String value) {
                            return FieldValidator.validateEmptyCheck(value);
                          },
                           controller: reasonController,
                          keyboardType: TextInputType.text,
                          textCapitalization: TextCapitalization.words,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black),
                          decoration: InputDecoration(
                            // hintText: Constants.detailsOfTheTripHint,
                            hintStyle: TextStyle(
                                color: Colors.grey[300],
                                fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 20.0,),
                  Container(
                    width: SizeConfig.widthMultiplier * 30,
                    child: CustomRoundButtonWidget(
                      buttonWidth:SizeConfig.widthMultiplier * 30 ,
                      title: Constants.reject,
                      callback: () {

                        if(reasonController.text=="")
                          {
                            showDisplayAllert(context: context,isSucces: false,message: Constants.emptyMessage);
                          }
                        else{
                          actionProgress();
                          rejectBookingRequest(bookingId, index);
                          Navigator.pop(context);
                        }

                      },
                    ),
                  ),
                ],),
            );
            }
            },
          );
        });
  }


}
class Item {
  const Item(this.name);

  final String name;

}