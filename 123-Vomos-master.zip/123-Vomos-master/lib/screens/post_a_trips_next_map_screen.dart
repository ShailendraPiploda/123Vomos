import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_map_polyline/google_map_polyline.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/trip_stop_widget.dart';
import 'package:vamos/model/trip_route_details.dart';
import 'package:vamos/screens/post_a_trips_submit_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:google_maps_webservice/places.dart';

class PostATripNextMapScreen extends StatefulWidget{
  List<TripRouteDetails>listRouteDetails = new List<TripRouteDetails>();
  List<LatLng> latlngSegment1 = List();
  String totalPrice="0";
  String date="";

  PostATripNextMapScreen({this.listRouteDetails,this.latlngSegment1,this.totalPrice,this.date});




  @override
  State<StatefulWidget> createState()=>new PostATripNextMapScreenState();

}
class PostATripNextMapScreenState extends State<PostATripNextMapScreen>{
  TextEditingController oldTotalPriceControler = new TextEditingController();
  Set<Marker> markers = Set();
  List<Marker>listMarker=new List();
  String userIdMain="";
  bool haveNewPrice=false;
  bool isLoading=false;
  Completer<GoogleMapController> _controller = Completer();
  static final CameraPosition _kGooglePlex = CameraPosition(
    target:LatLng( 4.624335, -74.063644),
    zoom: 20,
  );

  Set<Polyline> _polylines = {};
  List<LatLng> polylineCoordinates = [];
  PolylinePoints polylinePoints = PolylinePoints();

  GoogleMapPolyline googleMapPolyline = new  GoogleMapPolyline(apiKey:  API.googleMapApiKey);

  final GlobalKey<ScaffoldState> _scaffoldKey =new GlobalKey<ScaffoldState>();
  TextEditingController noOfSeateController = new TextEditingController();
  TextEditingController toController = new TextEditingController();
  TextEditingController interavalTimeController = new TextEditingController();

  var listArrayStartLat = new List();
  var listArrayStartLong = new List();
  var listArrayStopLat = new List();
  var listArrayStopLong = new List();
  var listArrayStart = new List();
  var listArrayStops = new List();
  var listArrayDuration = new List();
  var listArrayNewDateTime = new List();
  var listArrayDistance = new List();
  var listArrayPrice = new List();
  var listArrayHalt = new List();
  var listArrayNewPrice = new List();

  var percentage;
  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();

  String  kGoogleApiKey = API.googleMapApiKey;

  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: API.googleMapApiKey);





  submitAddTripDetailsDetails() async {
    listArrayStartLat.clear();
    listArrayStartLong.clear();
    listArrayStart.clear();
    listArrayStops.clear();
    listArrayNewDateTime.clear();
    listArrayDuration.clear();
    listArrayDistance.clear();
    listArrayHalt.clear();
    listArrayStopLat.clear();


    if(!haveNewPrice)
    {

      listArrayNewPrice.clear();

    }


    listArrayNewDateTime.add(widget.date.toString());

    for(int i =0;i<widget.latlngSegment1.length;i++)
    {
      listArrayStartLat.add(widget.latlngSegment1[i].latitude.toString());
      listArrayStartLong.add(widget.latlngSegment1[i].longitude.toString());


      if(i>0 && i<widget.listRouteDetails.length )
      {
        listArrayStopLat.add(widget.latlngSegment1[i].latitude.toString());
        listArrayStopLong.add(widget.latlngSegment1[i].longitude.toString());

      }
    }


    for(int i =0;i<widget.listRouteDetails.length;i++)
    {


      listArrayNewDateTime.add(widget.listRouteDetails[i].date);
      listArrayDuration.add(widget.listRouteDetails[i].duration.toString());
      listArrayDistance.add(widget.listRouteDetails[i].distance.toString().substring(0,widget.listRouteDetails[i].distance.indexOf(" ")));
      listArrayPrice.add(widget.listRouteDetails[i].price.toString());

      if(!haveNewPrice)
        {

          listArrayNewPrice.add(widget.listRouteDetails[i].price.toString());

        }


      if(i!=widget.listRouteDetails.length-1)
      {
        listArrayStops.add(widget.listRouteDetails[i].destination_addresses.toString());
        listArrayHalt.add(widget.listRouteDetails[i].stopController.text);
      }

   //   listArrayStart.add(widget.listRouteDetails[i].origin_addresses.toString());


      if(i==widget.listRouteDetails.length-1)

      {
        // listArrayStart.add(new DataJson(widget.listRouteDetails[widget.listRouteDetails.length-1].destination_addresses));
        //listArrayStart.add(new DataJson(widget.listRouteDetails[i].origin_addresses));


        listArrayStart.add(widget.listRouteDetails[i].origin_addresses);

        listArrayStart.add(widget.listRouteDetails[widget.listRouteDetails.length-1].destination_addresses);



      }else
      {

        // listArrayStart.add(new DataJson(widget.listRouteDetails[i].origin_addresses));

        listArrayStart.add(widget.listRouteDetails[i].origin_addresses.toString());

      }


      // listArrayStart.add(widget.latlngSegment1[i].longitude.toString());
    }

     print(jsonEncode(listArrayStart));



    Map<String, dynamic> body = {
      "user_id":userIdMain,
      "start": jsonEncode(listArrayStart),
      "stop": jsonEncode(listArrayStops),
      "new_start_lat": jsonEncode(listArrayStartLat),
      "new_start_long": jsonEncode(listArrayStartLong),
      "new_stop_lat": jsonEncode(listArrayStopLat),
      "new_stop_long":jsonEncode(listArrayStopLong),
      "new_datetime": jsonEncode(listArrayNewDateTime),
      "duration": jsonEncode(listArrayDuration),
      "distance": jsonEncode(listArrayDistance),
      "old_final_price": jsonEncode(listArrayPrice),
      "new_final_price": jsonEncode(listArrayNewPrice),
      "halt":jsonEncode( listArrayHalt),
      "percentage": !haveNewPrice?"0": percentage.toString(),
      "total_cost_old":widget.totalPrice.toString()=="null"?"0": widget.totalPrice.toString(),


    };



    final uri = API.addtrip;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };

      String jsonBody = json.encode(body);
     final encoding = Encoding.getByName('utf-8');
//
     print(body);

  //    print(jsonBody);

    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    // print(body.toString());
    print(response.body);

    progressLoad();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:context,isSucces: true,message: (data["message"]));
        String id = data["data"]["data"].toString();

        AppRoutes.goto(context, PostATripSubmitScreen(id));

      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }



  setPolylines() async {

    for(int i=0;i<widget.latlngSegment1.length-1;i++)
    {

      List<PointLatLng> result = await
      polylinePoints?.getRouteBetweenCoordinates(
          API.googleMapApiKey,
          widget.latlngSegment1[i].latitude,
          widget.latlngSegment1[i].longitude,
          widget.latlngSegment1[i+1].latitude,
          widget.latlngSegment1[i+1].longitude);
      if(result.isNotEmpty){
        // loop through all PointLatLng points and convert them
        // to a list of LatLng, required by the Polyline
        result.forEach((PointLatLng point){
          polylineCoordinates.add(
              LatLng(point.latitude, point.longitude));
        });
      }
    }


    setState(() {
      // create a Polyline instance
      // with an id, an RGB color and the list of LatLng pairs
      Polyline polyline = Polyline(width: 2, visible: true,
          polylineId: PolylineId("dfarafa"),
          color: Colors.blue,
          points: polylineCoordinates
      );

      // add the constructed polyline as a set of points
      // to the polyline set, which will eventually
      // end up showing up on the map
      _polylines.add(polyline);
    });


  }

  createMarkerForMap(){

    setState(() {
      for(int i=0;i<widget.latlngSegment1.length;i++)
      {
        markers.add(  Marker(
            markerId: MarkerId(i.toString()),
            position: LatLng(widget.latlngSegment1[i].latitude,widget.latlngSegment1[i].longitude))) ;

        listMarker.add(Marker(
            markerId: MarkerId(i.toString()),
            position: LatLng(widget.latlngSegment1[i].latitude,widget.latlngSegment1[i].longitude))) ;
      }

    });




  }



  void onMapCreated(GoogleMapController controller) {


    Future.delayed(Duration(seconds: 1), () {
//
      double southwestLat=widget.latlngSegment1[widget.latlngSegment1.length-1].latitude;
      double southwestLong=widget.latlngSegment1[widget.latlngSegment1.length-1].longitude;
      double northetLat=widget.latlngSegment1[0].latitude;
      double northetLong=widget.latlngSegment1[0].longitude;


   //   southwest.latitude <= northeast.latitude


      if(southwestLat<=northetLat)
        {
          controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( southwest : LatLng(southwestLat,southwestLong), northeast:   LatLng(northetLat, northetLong) ), 30));

        }
      else{
        controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( northeast : LatLng(southwestLat,southwestLong), southwest: LatLng(northetLat, northetLong) ), 30));

      }



      // controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( southwest : LatLng(southwestLat,southwestLong), northeast:   LatLng(northetLat, northetLong) ), 30));
     // controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds( southwest:LatLng(-4.2316872,-82.1243666), northeast:  LatLng(16.0571269,-66.8511907), ), 20));
      _controller.complete(controller);
      setState(() {

      });

    });




  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.postATrip,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(isGoBack: false,),
      body: Container(
        color: Colors.white,
        height: double.maxFinite,
        width: double.maxFinite,
        child:Stack(children: <Widget>[
          SingleChildScrollView(
            child:    Column(children: <Widget>[
              SizedBox(height: AppSize.medium,),
              Form(
                key: _loginFormKey,
                child:Column(children: <Widget>[


                  Container(
                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),


                      width: double.maxFinite,
                      height: SizeConfig.heightMultiplier*20,
                      child: GoogleMap(
                        gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>[
                          new Factory<OneSequenceGestureRecognizer>(() => new EagerGestureRecognizer(),),
                        ].toSet(),
                        scrollGesturesEnabled: true,
                        myLocationButtonEnabled: false,
                        myLocationEnabled: true,
                        compassEnabled: true,
                        polylines: _polylines,
                        mapToolbarEnabled: true,
                        rotateGesturesEnabled: true,
                        zoomGesturesEnabled:true,
                        mapType: MapType.normal,
                        markers: markers,
                        initialCameraPosition: _kGooglePlex,
                        onMapCreated:onMapCreated,
                      )
                  ),

                  SizedBox(height: AppSize.large,),
                  Container(
                    margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                    decoration:  BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        border: new Border.all(width: 1,color: Colors.grey[400])
                      // border: Border.all(width: 1.0,color: Colors.grey[200])
                    ),
                    child: Column(children: <Widget>[

                      Container(
                        height: SizeConfig.heightMultiplier*2,
                      ),

                      Container(
                        padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              child: Row(children: <Widget>[
                                Icon(Icons.location_on,color: AppTheme.primaryColor,),
                                Text(Constants.from,style:TextStyle(color: AppTheme.primaryColor),)
                              ],),
                            ),

                            Container(
                              child: Row(

                                children: <Widget>[
                                  Icon(Icons.update,color: AppTheme.primaryColor,),
                                  Text(widget.date)
                                ],),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: AppSize.small,),

                      Container(
                        padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*1),
                        margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
                        decoration:  BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(15),
                            border: new Border.all(width: 1,color: Colors.grey[200])

                        ),
                        child:Container(
                          width: SizeConfig.widthMultiplier*90,
                          padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3,vertical: SizeConfig.widthMultiplier*3),
                          child: Text(widget.listRouteDetails[0].origin_addresses,  style: TextStyle(
                            //  fontFamily: "WorkSansSemiBold",
                              fontSize: 14.0,
                              color: Colors.black),)),
                      ),



                      SizedBox(height: AppSize.medium,),


                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        itemCount:  widget.listRouteDetails.length-1,
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {

                          return TripStopWidget(
                            controller: widget.listRouteDetails[index].stopController,
                            index: index,
                            address: widget.listRouteDetails[index].destination_addresses,
                            date:  widget.listRouteDetails[index].date,
                            distance:  widget.listRouteDetails[index].distance,
                            duration:  widget.listRouteDetails[index].duration,
                            price:  widget.listRouteDetails[index].price,
                            onTap: () {updateNewDate(index);},);
                        },
                      ),




                      SizedBox(height: AppSize.medium,),


                      Container(
                        padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              child: Row(children: <Widget>[
                                Icon(Icons.location_on,color: AppTheme.primaryColor,),
                                Text(Constants.to,style: TextStyle(color: AppTheme.primaryColor),)
                              ],),
                            ),

                            Container(
                              child: Row(

                                children: <Widget>[
                                  Icon(Icons.update,color: AppTheme.primaryColor,),
                                  Text(widget.listRouteDetails[widget.listRouteDetails.length-1].date)
                                ],),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: AppSize.small,),

                      Container(
                        padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*1),
                        margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
                        decoration:  BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(15),
                            border: new Border.all(width: 1,color: Colors.grey[200])

                        ),
                        child:Container(
                          width: SizeConfig.widthMultiplier*90,
                          padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3,vertical: SizeConfig.widthMultiplier*3),
                          child: Text(widget.listRouteDetails[widget.listRouteDetails.length-1].destination_addresses,  style: TextStyle(
                            //  fontFamily: "WorkSansSemiBold",
                              fontSize: 14.0,
                              color: Colors.black),),),
                      ),
                      SizedBox(height: AppSize.small,),

                      Container(
                        margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                        padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
                        child: Row(

                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(widget.listRouteDetails[widget.listRouteDetails.length-1].distance),

                            Text(widget.listRouteDetails[widget.listRouteDetails.length-1].duration),

                            Text(Constants.currancy+widget.listRouteDetails[widget.listRouteDetails.length-1].price),
                          ],
                        ),
                      ),
//
                      SizedBox(height: AppSize.medium,),


                    ],),
                  )
                ],),
              ),

              SizedBox(height: AppSize.large,),

              Container(
                margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

                padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),

                child:  Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[
                    Container(
                        width: SizeConfig.widthMultiplier*50,
                        child: Row(children: <Widget>[
                          Icon(Icons.attach_money,color: AppTheme.primaryColor),

                          Text(Constants.recommendedPrice,style: TextStyle(color: AppTheme.primaryColor),),
                        ],)),
                    Container(
                        alignment: Alignment.centerRight,
                        width: SizeConfig.widthMultiplier*30,
                        child: Text(Constants.currancy+widget.totalPrice.toString(),)),

                  ],),),

              SizedBox(height: AppSize.small,),

              Container(
                padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*2),
                margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),
                decoration:  BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: new Border.all(width: 1,color: Colors.grey[200])
                  // border: Border.all(width: 1.0,color: Colors.grey[200])
                ),

                child:TextFormField(
                  controller: oldTotalPriceControler,
                  validator: (String value) {
                    return FieldValidator.validateEmptyCheck(value);
                  },
                  keyboardType: TextInputType.number,
                  // maxLength: 9,
                  style: TextStyle(
                      fontFamily: "WorkSansSemiBold",
                      fontSize: 16.0,
                      color: Colors.black),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Constants.putYourPriceHere,
                      hintStyle:
                      TextStyle(fontSize: AppFontSize.textHint)),
                ),
              ),


              SizedBox(height: AppSize.large,),

              Container(
                width: SizeConfig.widthMultiplier*90,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      width: SizeConfig.widthMultiplier*40,
                      child:  CustomRoundButtonWidget(
                        title: Constants.back,
                        callback: () {
                          AppRoutes.dismiss(context);
                        },
                      ),),

                    Container(
                      width: SizeConfig.widthMultiplier*40,
                      child:  CustomRoundButtonWidget(
                        title: Constants.next,
                        callback: () {

                         recalculatePrice(context);

                        },
                      ),)

                  ],),
              ),




              SizedBox(height: AppSize.large,),
            ],),
          ),
          isLoading? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center(child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,)
        ],),

      ),
    );
  }

  @override
  void initState() {
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);

    });
    createMarkerForMap();
    setPolylines();

  }





  updateNewDate(int index)async{

    setState(() {

      int miniute = 0;

      if(widget.listRouteDetails[index].stopController.text!=""){
        miniute= int.parse(widget.listRouteDetails[index].stopController.text);
      }

      DateTime myDatetime = DateTime.parse(widget.listRouteDetails[index+1].mainDate);

      myDatetime =myDatetime.add(Duration(minutes:miniute ));


      widget.listRouteDetails[index+1].date=myDatetime.toString().substring(0,myDatetime.toString().length-4);
    });



  }


  recalculatePrice(BuildContext context){

    int original_value =int.parse(widget.totalPrice);
    int newPrice = 0;

    if(oldTotalPriceControler.text!="")
    {
      newPrice = int.parse(oldTotalPriceControler.text);
    }

    print(original_value);



    if(newPrice==0)
    {
      haveNewPrice=false;
      progressLoad();

      submitAddTripDetailsDetails();
    }else{
      haveNewPrice=true;
      listArrayNewPrice.clear();
      if(original_value > newPrice)
      {

        showDisplayAllert(isSucces: false,context: context,message: Constants.newPriceError);

        for(int i =0;i<widget.listRouteDetails.length;i++) {
          int old = int.parse(widget.listRouteDetails[i].mainPrice.toString());



          setState(() {
            widget.listRouteDetails[i].price = old.toString();
          });
        }

      }else{

        percentage=(((newPrice-original_value)/original_value)*100);

        if(percentage>30)
        {
          print(percentage);
          showDisplayAllert(isSucces: false,context: context,message: "El valor máximo debe ser 30");
        }else{

          for(int i =0;i<widget.listRouteDetails.length;i++) {
            int old = int.parse(widget.listRouteDetails[i].mainPrice.toString());
            var newP = old + ((old * percentage) / 100);

            listArrayNewPrice.add(newP);


          }
          progressLoad();

          submitAddTripDetailsDetails();

        }

      }

    }




  }


  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }


}
