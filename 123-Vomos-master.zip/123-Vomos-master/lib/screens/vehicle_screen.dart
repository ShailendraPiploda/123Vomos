import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart'  as http;
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/model/vehicle_brand_model.dart';
import 'package:vamos/model/vehicle_color_model.dart';
import 'package:vamos/model/vehicle_model.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:path/path.dart';
import 'package:async/async.dart';

class VehicleScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState()=>new _VehicleScreen();

}
class _VehicleScreen extends State<VehicleScreen> {
  bool isLoading=false;
bool isVehiceAdeed=false;
  int totalIndex=0;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  bool isLoding = false;
  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();
  String _groupValue = "Male";
  String brand_id = "",
      model_id = "",
      color_id = "",
      userIdMain = "",
      userName = "",
      carImage = "",
      status="",
      statustMessage="";
  List<Widget> normalList = [];

  File _profileImage = null;
  List<VechileBrandModel> listVehicleBrand = new List();
  List<VechileModel> listVehicleModel = new List();
  List<VechileColorModel> listVehicleColor = new List();
  List<String>list = new List();
  TextEditingController vehicleBrandController = new TextEditingController();
  TextEditingController vehicleModelController = new TextEditingController();
  TextEditingController vehicleColorController = new TextEditingController();
  TextEditingController vehicleplatNumberController = new TextEditingController();

  TextEditingController vehicleDriverExpController = new TextEditingController();

  TextEditingController vehicleDriverLicenseController = new TextEditingController();

  TextEditingController vehicleDriverNameController = new TextEditingController();

  TextEditingController searchController = TextEditingController();

  getVehicleDetails() async {
    final uri = API.getVehicle;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };

    Map<String, dynamic> body = {
      "user_id": userIdMain,

    };

    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    http.Response response = await ioClient.post(
        uri,
        headers: headers,
        body: body
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    // print(response.body);
    progressLoad();

    if (statusCode == 200) {
      if (data["status"] == "true") {
        //  showDisplayAllert(context:context,isSucces: true,message: (data["message"]));

        List brandlist = data["data"]["vehicleBrand"];
        List colorList = data["data"]["vehicleColor"];



        final vehicalData = data["data"]["findVehicle"];
        final userData = data["data"]["user"];
        String driverInfoUpdate =userData["drive_image_verification"].toString();
        ShareMananer.updateDriverData(driverInfoUpdate);
        print(driverInfoUpdate);


        if (vehicalData != null) {
          vehicleDriverLicenseController.text = userData["driving_id"];
          vehicleDriverExpController.text = userData["driving_exp"].toString();


          setState(() {
            brand_id = vehicalData["car_brand"].toString();
            model_id = vehicalData["car_model"].toString();
            color_id = vehicalData["color"].toString();
            carImage = vehicalData["car_img"].toString();
            status = vehicalData["status"].toString();

            isVehiceAdeed=true;
            if(status=="0")
              {
                statustMessage=Constants.vehicleApprovalForWaitMessage.toString();
              }else if(status=="1")
            {
              statustMessage=Constants.vehicleApprovalApprovedMessage.toString();
            }else if(status=="2")
            {
              statustMessage=Constants.vehicleApprovalDecliendMessage.toString();
            }

            print(API.basevehiclemageUrl+carImage);
          });
          vehicleplatNumberController.text =
              vehicalData["plate_number"].toString();


          getVehicleModel();
        }


        for (int i = 0; i < brandlist.length; i++) {
          String id = brandlist[i]["id"].toString();
          String brand = brandlist[i]["brand"].toString();
          String status = brandlist[i]["status"].toString();
          String created_at = brandlist[i]["created_at"].toString();
          String updated_at = brandlist[i]["updated_at"].toString();



          if (id == brand_id && brand_id != "") {
            vehicleBrandController.text = brand;
          }

          listVehicleBrand.add(
              new VechileBrandModel(id, brand, status, created_at, updated_at));
        }


        for (int i = 0; i < colorList.length; i++) {
          String id = colorList[i]["id"].toString();
          String color_name_es = colorList[i]["color_name_es"].toString();
          String color_name_en = colorList[i]["color_name_en"].toString();
          String color_code = colorList[i]["color_code"].toString();
          String status = colorList[i]["status"].toString();
          String created_at = colorList[i]["created_at"].toString();
          String updated_at = colorList[i]["staupdated_attus"].toString();


          if (id == color_id && color_id != "") {
            vehicleColorController.text = color_name_en;
          }


          listVehicleColor.add(new VechileColorModel(
              id,
              status,
              created_at,
              updated_at,
              color_code,
              color_name_en,
              color_name_es));


          filterList();
        }
      } else {
        String dataString = data["message"].toString();
        dataString =
            dataString.substring(dataString.indexOf(":"), dataString.length)
                .replaceAll(":", "").replaceAll("{", "").replaceAll("}", "")
                .replaceAll("[", "")
                .replaceAll("]", "");

        showDisplayAllert(
            context: this.context, isSucces: false, message: dataString);
      }
    } else {
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }


  getVehicleModel() async {
    final uri = API.getVehicleModel;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };

    Map<String, dynamic> body = {
      "brand_id": brand_id,

    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    http.Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(response.body);


    if (statusCode == 200) {
      if (data["status"] == "true") {
        // showDisplayAllert(context:context,isSucces: true,message: (data["message"]));

        List list = data["data"]["data"];


        if (listVehicleModel.isNotEmpty) {
          listVehicleModel.clear();
        }

        // print(list.toString());


        for (int i = 0; i < list.length; i++) {
          String id = list[i]["id"].toString();
          String brand_id = list[i]["brand_id"].toString();
          String status = list[i]["status"].toString();
          String createAt = list[i]["created_at"].toString();
          String updateAt = list[i]["updated_at"].toString();
          String model_no = list[i]["model_no"].toString();


          if (model_id != "" && id == model_id) {
            vehicleModelController.text = model_no;
          }

          listVehicleModel.add(new VechileModel(
              id, brand_id, model_no, status, createAt, updateAt));
        }
      } else {
        String dataString = data["message"].toString();
        dataString =
            dataString.substring(dataString.indexOf(":"), dataString.length)
                .replaceAll(":", "").replaceAll("{", "").replaceAll("}", "")
                .replaceAll("[", "")
                .replaceAll("]", "");

        showDisplayAllert(
            context: this.context, isSucces: false, message: dataString);
      }
    } else {
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }

  addVehicle() async {
    var uri = Uri.parse(API.addVehicle);
    var stream = new http.ByteStream(
        DelegatingStream.typed(_profileImage.openRead()));
    var length = await _profileImage.length();

    MultipartFile multipartFile = new MultipartFile(
        'vehicleImg', stream, length, filename: basename(_profileImage.path));

    var request = new MultipartRequest("POST", uri);
    request.files.add(multipartFile);
    request.fields["user_id"] = userIdMain;
    request.fields["car_brand"] = brand_id;
    request.fields["car_model"] = model_id;
    request.fields["color"] = color_id;
    request.fields["plate_number"] =
        vehicleplatNumberController.text.toString();
    request.fields["driving_id"] =
        vehicleDriverLicenseController.text.toString();
    request.fields["driving_exp"] = vehicleDriverExpController.text.toString();


    request.headers[HttpHeaders.contentTypeHeader] =
    'multipart/form-data;charset=utf-8';
    request.send().then((response) async {
      progressLoad();
      if (response.statusCode == 200) {
        print("Uploaded!");

        final data = json.decode(await response.stream.bytesToString());
        print(data.toString());

        if (data["status"] == "true") {

          showDisplayAllert(context: this.context,
              isSucces: true,
              message: (data["message"]));





        } else {

          String dataString = data["message"].toString();
          dataString =
              dataString.substring(dataString.indexOf(":"), dataString.length)
                  .replaceAll(":", "").replaceAll("{", "").replaceAll("}", "")
                  .replaceAll("[", "")
                  .replaceAll("]", "");

          showDisplayAllert(
              context: this.context, isSucces: false, message: dataString);
        }
      } else {

        showDisplayAllert(context: this.context,
            isSucces: false,
            message: response.reasonPhrase);
      }
    });
  }

  @override
  void initState() {
    progressLoad();
    filterList();
    searchController.addListener(() {
      filterList();
    });


    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      vehicleDriverNameController.text =
          data["first_name"] + " " + data["last_name"];
      getVehicleDetails();
      print(userIdMain);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.vehical,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: double.maxFinite,
        child: Stack(children: <Widget>[
          SingleChildScrollView(
            child: Column(children: <Widget>[
              SizedBox(height: AppSize.small,),
              Form(
                key: _loginFormKey,
                child: Container(
                  // width: SizeConfig.widthMultiplier*90,
                  child: Column(children: <Widget>[

                    isVehiceAdeed ? Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.symmetric(vertical: AppSize.small,horizontal: AppSize.small),
                      margin: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      decoration: BoxDecoration(
                        //  border: Border.all(width: 1),
                          borderRadius: BorderRadius.circular(50.0),
                          color: Colors.green[300]

                      ),
                      child: Text(statustMessage,style: AppTheme.textStyle.alertText.copyWith(color: Colors.white),),
                    ): SizedBox(height: AppSize.small,),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: vehicleDriverNameController,
                        readOnly: true,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.driverName,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              FontAwesomeIcons.user,
                              color: Colors.black,
                              size: AppFontSize.textIcon
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: vehicleDriverLicenseController,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.licenseNumber,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              FontAwesomeIcons.sortNumericUpAlt,
                              color: Colors.black,
                              size: AppFontSize.textIcon
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: vehicleBrandController,
                        readOnly: true,
                        onTap: showVehicleBrandPoppup,
                        keyboardType: TextInputType.text,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.vehicleBrand,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              Icons.airport_shuttle,
                              color: Colors.black,
                              size: AppFontSize.textIcon

                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: vehicleModelController,
                        keyboardType: TextInputType.text,
                        readOnly: true,
                        onTap: showVehicleModelPoppup,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.vehicleModel,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              Icons.chrome_reader_mode,
                              color: Colors.black,
                              size: AppFontSize.textIcon
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),


                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        keyboardType: TextInputType.emailAddress,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        readOnly: true,
                        onTap: showVehicleColorPoppup,
                        controller: vehicleColorController,
                        decoration: InputDecoration(
                          labelText: Constants.vehicleColor,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              FontAwesomeIcons.bitbucket,
                              color: Colors.black,
                              size: AppFontSize.textIcon
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: vehicleplatNumberController,
                        keyboardType: TextInputType.text,
                        maxLength: 6,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.vehicleLicensePlateNumber,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              FontAwesomeIcons.flipboard,
                              color: Colors.black,
                              size: AppFontSize.textIcon
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),

                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),


                      child: TextFormField(
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: vehicleDriverExpController,
                        keyboardType: TextInputType.number,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.drivingExperience,
                          labelStyle: TextStyle(
                              color: Colors.grey, fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                              FontAwesomeIcons.buromobelexperte,
                              color: Colors.black,
                              size: AppFontSize.textIcon
                          ),

                        ),
                      ),
                    ),

                    Container(
                      margin: EdgeInsets.only(
                        // top:0.5*SizeConfig.heightMultiplier,
                          left: 6.0 * SizeConfig.widthMultiplier,
                          right: 6.0 * SizeConfig.widthMultiplier),
                      width: double.maxFinite,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),


                    SizedBox(height: AppSize.medium,),
//                    Row(children: <Widget>[
//                      Container(width: SizeConfig.widthMultiplier*50,
//                      child: Row(
//                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                        children: <Widget>[
//                          SizedBox(width: AppSize.mediumLarge,),
//
//                          Icon(Icons.add_circle,color: AppTheme.primaryColor,size: AppSize.mediumLarge,),
//                        SizedBox(width: AppSize.extraSmall,),
//                        Text(Constants.addPhoto,style: TextStyle(color: AppTheme.primaryColor,fontSize: AppFontSize.s18),)
//                      ],),),
//
//                      Container(width: SizeConfig.widthMultiplier*50,
//                      child: Icon(Icons.directions_car,color: Colors.grey,size: AppSize.extraLarge,),)
//                    ],),


                    Container(
                        width: SizeConfig.widthMultiplier * 80,
                        height: SizeConfig.heightMultiplier * 20,
                        decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: new BorderRadius.circular(20.0)
                        ),

                        child: GestureDetector(
                          onTap: () {
                            _showImagePicker(context);
                          },
                          child: carImage.isEmpty && _profileImage==null? Column(
                            mainAxisAlignment: MainAxisAlignment.center,

                            children: <Widget>[
                              SizedBox(height: AppSize.mediumLarge,),

                              Icon(Icons.directions_car, size: AppSize.xxL,
                                color: Colors.grey,),


                              SizedBox(height: AppSize.mediumLarge,),


                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(Constants.addVehicalPhoto,
                                      style: AppTheme.textStyle.heading1.copyWith(
                                        color: Colors.grey,
                                        fontSize: AppFontSize.s16,)),
                                  Icon(
                                    Icons.camera, color: AppTheme.primaryColor,)
                                ],)
                            ],)
                              : Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: _profileImage != null ? FileImage(_profileImage) : NetworkImage(API.basevehiclemageUrl+carImage)
                                ),
                                borderRadius: BorderRadius.all(
                                    Radius.circular(8.0)),
                                // color: Colors.redAccent,
                              )),
                        )

                    ),
                    SizedBox(height: AppSize.medium,),

                    Container(
                      margin: EdgeInsets.all(10.0),
                      child: Text(Constants.photoInfo, style: TextStyle(
                          color: Colors.black, fontSize: AppFontSize.s12),),
                    ),


                    SizedBox(height: AppSize.large,),

                     CustomRoundButtonWidget(
                      title: Constants.update,
                      callback: () {
                        if (_loginFormKey.currentState.validate()) {
                          if(_profileImage!=null)
                            {
                              progressLoad();
                              addVehicle();
                            }
                          else{
                            showDisplayAllert(context: context,isSucces: false,message: Constants.uploadImage);
                          }

                        }
                        //AppRoutes.replace(context, LoginScreen());
                      },
                    )





                  ],),
                ),
              ),


            ],),
          ),

          isLoading?Container(
              color: Colors.black.withOpacity(0.5),
              child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),))):
              SizedBox(width: 0.0,),

        ],) ),
    );
  }

  void showVehicleBrandPoppup() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: listVehicleBrand.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        setState(() {
                          brand_id = listVehicleBrand[index].id.toString();
                        });

                        vehicleBrandController.text =
                            listVehicleBrand[index].brand;
                        vehicleModelController.text = "";

                        getVehicleModel();
                        print(index);
                        Navigator.pop(context);
                      },
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(listVehicleBrand[index].brand,
                                      style: TextStyle(fontSize: 18.0)),
                                )
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Container(
                                  height: 1.0,
                                  color: Colors.grey[400],
                                )),
                          ],
                        ),
                      ));
                },
              ),
            ),
          );
        });
  }

  void showVehicleModelPoppup() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: listVehicleModel.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        setState(() {
                          model_id = listVehicleModel[index].id.toString();
                        });

                        vehicleModelController.text =
                            listVehicleModel[index].model_no;

                        getVehicleModel();
                        print(index);
                        Navigator.pop(context);
                      },
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(listVehicleModel[index].model_no,
                                      style: TextStyle(fontSize: 18.0)),
                                )
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Container(
                                  height: 1.0,
                                  color: Colors.grey[400],
                                )),
                          ],
                        ),
                      ));
                },
              ),
            ),
          );
        });
  }

  void showVehicleColorPoppup() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: listVehicleColor.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        setState(() {
                          color_id = listVehicleColor[index].id.toString();
                        });

                        vehicleColorController.text =
                            listVehicleColor[index].color_name_en;

                        getVehicleModel();
                        print(index);
                        Navigator.pop(context);
                      },
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(
                                      listVehicleColor[index].color_name_en,
                                      style: TextStyle(fontSize: 18.0)),
                                )
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Container(
                                  height: 1.0,
                                  color: Colors.grey[400],
                                )),
                          ],
                        ),
                      ));
                },
              ),
            ),
          );
        });
  }



  _openGallery(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.gallery,imageQuality: 20);

    setState(() {
      _profileImage = picture;
      // base64Image=base64Encode(picture.readAsBytesSync());
    });
    Navigator.of(context).pop();
  }

  _openCamera(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.camera,imageQuality: 20);

    setState(() {
      _profileImage = picture;
    });
    Navigator.of(context).pop();
  }

  Future<bool> _showImagePicker(BuildContext context) {
    return showDialog(context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (context,setState){
            return  AlertDialog(
              title: Text("Make Your Choice"),
              content: SingleChildScrollView(
                child: ListBody(children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      _openGallery(context);
                    },
                    child: Text("Gallery"),
                  ),
                  SizedBox(height: AppSize.medium,)
                  ,

                  GestureDetector(
                    onTap: () {
                      _openCamera(context);
                    },
                    child: Text("Camera"),
                  ),
                ],),
              ),
            );
          });
        });
  }

  void loadProgress() {
    setState(() {
      isLoding = !isLoding;
    });
  }


progressLoad(){
  setState(() {

    isLoading=!isLoading;
  });
}


  filterList() {
    List<VechileBrandModel> users = [];
    users.addAll(listVehicleBrand);
    //favouriteList = [];
    normalList = [];
    list = [];
    if (searchController.text.isNotEmpty) {
      users.retainWhere((user) =>
          user.brand
              .toLowerCase()
              .contains(searchController.text.toLowerCase()));
    }
    users.forEach((user) {

        normalList.add(
          Container(

            child: ListTile(

              title: Text(user.brand),
            ),
          ),
        );
        list.add(user.brand);

    });

}}
