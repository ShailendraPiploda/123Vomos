import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:intl/intl.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/search_trip_widget.dart';
import 'package:vamos/model/search_model.dart';
import 'package:vamos/screens/post_trip_details.dart';
import 'package:vamos/screens/search_details_screen.dart';
import 'package:vamos/screens/search_trips_result_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class SearchTripsScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState()=>new _SearchTripsScreen();

}
class _SearchTripsScreen extends State<SearchTripsScreen>{

  final GlobalKey<ScaffoldState> _scaffoldKey =new GlobalKey<ScaffoldState>();
  TextEditingController fromController = new TextEditingController();
  TextEditingController toController = new TextEditingController();
  TextEditingController _infoDobController = new TextEditingController();
  double startLat=0.0, startLong=0.0, endLat=0.0,endLong=0.0;
  bool isLoading=false;
  List<SearchModel>listSearchResult = new List();
  var _loginFormKey = GlobalKey<FormState>();


  String  kGoogleApiKey = "AIzaSyDa9QSWtCvYdSfUPfSxAYcs-Pt4dKkJJEY";

  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: "AIzaSyDa9QSWtCvYdSfUPfSxAYcs-Pt4dKkJJEY");
String userIdMain="";

  @override
  void initState() {
    progressLoad();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      //  getHeaderData();
      getSearch();

    });

  }

  getSearch() async {

    final uri = API.searchTrip;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": "",
      "location_a_lat":"",
      "location_a_long": "",
      "location_b_lat":"",
      "location_b_long": "",
      "location_a_name": "",
      "location_b_name": "",
      "departure_datetime": "",

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    progressLoad();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        final list = data["data"];

        print(list.length);

        if(list.isEmpty)
        {
          showDisplayAllert(context:this.context,isSucces: false,message:data["message"]);
        }

        else{



          for(int i=0; i<list.length;i++){

            String trip_id = list[i]["trip_id"].toString();
            String user_id = list[i]["user_id"].toString();
            String seat_available = list[i]["seat_available"].toString();
            String start_time = list[i]["start_time"].toString();
            String interval_time = list[i]["interval_time"].toString();
            String booking_process = list[i]["booking_process"].toString();
            String first_name = list[i]["first_name"].toString();
            String last_name = list[i]["last_name"].toString();
            String birth_year = list[i]["birth_year"].toString();
            String from = list[i]["from"].toString();
            String to = list[i]["to"].toString();
            String total_price = list[i]["total_price"].toString();
            String departure_datetime = list[i]["departure_datetime"].toString();
            String seat_booked = list[i]["seat_booked"].toString();
            String location_a_lat = list[i]["location_a_lat"].toString();
            String location_a_long = list[i]["location_a_long"].toString();
            String location_b_lat = list[i]["location_b_lat"].toString();
            String location_b_long = list[i]["location_b_long"].toString();
            String image = list[i]["image"].toString();
            String google_image = list[i]["google_image"].toString();
            String facebook_image = list[i]["facebook_image"].toString();
            String email_varified = list[i]["email_varified"].toString();
            String identity_document_verified = list[i]["identity_document_verified"].toString();

            String rattingString = list[i]["avg_rating"]["avg_rating"];
            String avg_rating="0.0";
            if(rattingString!=null && rattingString!="")
            {
              avg_rating=rattingString;
            }
            else{
              avg_rating="0.0";
            }

//
//            List<Placemark> placemarkA= await Geolocator().placemarkFromCoordinates(double.parse(location_a_lat), double.parse(location_a_long));
//
//           String locationFrom=placemarkA[0].locality==""?placemarkA[0].subAdministrativeArea:placemarkA[0].locality;
//
//            List<Placemark> placemarkB= await Geolocator().placemarkFromCoordinates(double.parse(location_b_lat), double.parse(location_b_long));
//
//            String locationTo=placemarkB[0].locality==""?placemarkB[0].subAdministrativeArea:placemarkB[0].locality;

            listSearchResult.add(new SearchModel(trip_id, user_id, seat_available, start_time, interval_time, booking_process, first_name, last_name, birth_year, from, to, total_price, departure_datetime, seat_booked, location_a_lat, location_a_long, location_b_lat, location_b_long, google_image, facebook_image, image, email_varified, identity_document_verified,avg_rating));

            setState(() {

            });

          }



        }



      } else {


        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {

      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.searchTrip,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(isGoBack: false,),
      body: Container(
        color: Colors.white,
        height: double.maxFinite,
        width: double.maxFinite,
        child:Stack(children: <Widget>[
          SingleChildScrollView(
            child:    Column(
              children: <Widget>[
              SizedBox(height: AppSize.medium,),
              Form(
                key: _loginFormKey,
                child: Container(
                  //width: screenSize.width,
                  child: Column(children: <Widget>[

                    Container(
                      height: SizeConfig.heightMultiplier*5,
                    ),
                    Container(
                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])
                      ),

                      child: TextFormField(
                        onTap:  () async {

                          // show input autocomplete with selected mode
                          // then get the Prediction selected
                          Prediction p = await PlacesAutocomplete.show(
                              components: [new Component(Component.country, "co")],
                              hint:Constants.fromWhichCityWillItLeave ,
                              context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                          displayPrediction(p,true);
                        },
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        readOnly: true,
                        controller: fromController,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.from,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                            FontAwesomeIcons.carAlt,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    SizedBox(height: AppSize.medium,),

                    Container(
                      width: double.maxFinite,
                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),

                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])

                      ),


                      child: TextFormField(
                        onTap:  () async {

                          // show input autocomplete with selected mode
                          // then get the Prediction selected
                          Prediction p = await PlacesAutocomplete.show(
                              components: [new Component(Component.country, "co")],
                              hint:Constants.fromWhichCityWillItLeave ,
                              context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                          displayPrediction(p,false);
                        },
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        readOnly: true,
                        controller: toController,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.to,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                          border: InputBorder.none,
                          icon: Icon(
                            FontAwesomeIcons.car,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    SizedBox(height: AppSize.medium,),


                    Container(

                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])
                      ),

                      child: TextFormField(

                        controller: _infoDobController,
                        validator: (String value) {

                          return FieldValidator.validateEmptyCheck(value);
                        },
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.date,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.s16),
                          border: InputBorder.none,
                          icon: Icon(
                            FontAwesomeIcons.calendar,
                            color: Colors.black,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                        readOnly: true,
                        onTap: ()async{
                          DateTime date = DateTime.now();
                          FocusScope.of(context).requestFocus(new FocusNode());

                          date = await showDatePicker(
                            context: context,
                            initialDate:DateTime.now(),
                            firstDate:DateTime(DateTime.now().year),
                            lastDate: DateTime(3000),
                            builder: (BuildContext context, Widget child) {
                              return Theme(
                                data: ThemeData(primaryColor: AppTheme.colors.loginGradientStart,
                                  accentColor: AppTheme.colors.loginGradientStart,
                                  primaryColorDark: AppTheme.colors.loginGradientStart
                                  ,primarySwatch:Colors.orange, ),
                                child: child,
                              );
                            },
                          );

                          if(date.toString()!="null")
                          {
                            _infoDobController.text = date.toString().substring(0,date.toString().indexOf(" "));

                          }


                          print(_infoDobController.text);
                        },
                      ),
                    ),




                    SizedBox(height: AppSize.large,),

                    CustomRoundButtonWidget(
                      title: Constants.searchATrip,
                      callback: () {

                        if(_loginFormKey.currentState.validate())
                          {
                            DateTime date = DateTime.parse(_infoDobController.text.toString());
                            var formatter = new DateFormat('yyyy-MM-dd');
                            String formatted = formatter.format(date);


                            AppRoutes.goto(context, SearchTripsResultScreen(date: formatted,locationAName: fromController.text,
                              locationBName: toController.text,startLat: startLat,startLong: startLong,endLat: endLat,endLong: endLong,));

                          }
                          },
                    ),


                    SizedBox(height: AppSize.large,),

                  ],),
                ),
              ),
              SizedBox(height: AppSize.large,),


              listSearchResult.length>0?Container(
                margin: EdgeInsets.only(left: 10.0),
                  width: double.maxFinite,
                  child: Text(Constants.lastAddedTrips,
                    style: AppTheme.textStyle.heading1.copyWith(color: Colors.grey,fontSize: AppFontSize.s14,),
                    textAlign: TextAlign.left,)):SizedBox(height:0.0,),

                new Divider(
                  height: 3.0,
                  endIndent: SizeConfig.widthMultiplier*40,
                  indent: 10.0,
                  color: Colors.grey,
                ),

                SizedBox(height: AppSize.extraSmall,),
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                itemCount: listSearchResult.length,
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemBuilder: (BuildContext context, int index) {
                  String img = listSearchResult[index].image;
                  print(img);
                  return SearcgTripsWidget(
                    document: listSearchResult[index].identity_document_verified,
                    email: listSearchResult[index].email_varified,
                    rating: listSearchResult[index].ratting,
                    years: listSearchResult[index].birth_year,
                    imageUrl:img=="null"?listSearchResult[index].facebook_image:API.baseProfileImageUrl+listSearchResult[index].image,
                    customerName: listSearchResult[index].first_name+" "+listSearchResult[index].last_name,
                    locationFrom:listSearchResult[index].from,
                    locationTo:listSearchResult[index].to,
                    dateTime: listSearchResult[index].departure_datetime,
                    noOfSeatToBook: listSearchResult[index].seat_available,
                    paidAmount: listSearchResult[index].total_price,
                    onTap: (){
                      String driverId=listSearchResult[index].user_id;
                      if(driverId==userIdMain)
                      {
                        AppRoutes.goto(context,PostTripDetailsScreen(listSearchResult[index].trip_id));
                      }
                      else{
                        AppRoutes.goto(context,SearchTripDetailsScreen( postId: listSearchResult[index].trip_id,locationAName:listSearchResult[index].from,
                          locationBName: listSearchResult[index].to,dateTime: listSearchResult[index].start_time,price: listSearchResult[index].total_price ,));

                      }
                    },);
                },
              ),


            ],),
          ),
          isLoading? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center(child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,)
        ],)
      ),
    );
  }


  Future<Null> displayPrediction(Prediction p,bool clickType) async {
    if (p != null) {
    // progressLoad();
      PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(p.placeId);

      var placeId = p.placeId;
      double lat = detail.result.geometry.location.lat;
      double lng = detail.result.geometry.location.lng;


      var address = await Geocoder.local.findAddressesFromQuery(p.description);


      if(clickType)
      {
        fromController.text=address.first.addressLine.toString();
        startLat=lat;
        startLong=lng;
      //  progressLoad();

      }
      else{
        //progressLoad();
        endLat=lat;
        endLong=lng;
        toController.text=address.first.addressLine.toString();



      }
      setState(() {

      });

      print(address.first.addressLine);
      print(placeId);
    }
  }
  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }
}
