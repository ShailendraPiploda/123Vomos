import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/booking_request_wiget.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/messages_wiget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class MessagesScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _MessagesScreen();
}

class _MessagesScreen extends State<MessagesScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String mainUserID="";
  String mainUserName="";
  String mainUserImage="";
  FirebaseAuth _auth=FirebaseAuth.instance;


  getUserId()async{
    FirebaseUser user = await _auth.currentUser();
    setState(() {
      mainUserID=user.uid;

      Firestore.instance.collection('message').snapshots().contains("3709").then((onValue){

        print(onValue);

      });
      // print(post);

    });
  }


  @override
  void initState() {
    // getUserId();

    ShareMananer.getUserDetails().then((data) {
      mainUserID = data["id"];
      mainUserName = data["first_name"]+" "+ data["last_name"];
      String img =data["image"];
      String fb =data["facebook_image"];

      if(img=="" || img=="null")
        {
          mainUserImage=API.baseProfileImageUrl+img;
        }
      else{
        mainUserImage=fb;
      }
      print(mainUserID);

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.messages,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(isGoBack: false,),
      body: Container(
        color: Colors.white,
        width: screenSize.width,
        height: screenSize.height,
        child: StreamBuilder(
          stream: Firestore.instance.collection('usersChat').orderBy("timestamp", descending: true).snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(AppTheme.accentColor),
                ),
              );
            } else {
              print(snapshot.data.documents.length);

              return ListView.builder(
                padding: EdgeInsets.all(10.0),
                itemCount: snapshot.data.documents.length,

                // itemBuilder: (context, index) => buildItem(context, snapshot.data.documents[index]),
                itemBuilder: (BuildContext context, int index) {

                  print(snapshot.data.documents.length);
                  // print(snapshot.data.documents[index]["id"]);
                  if( snapshot.data.documents[index]["id"]!=mainUserID)
                  {
                    return SizedBox(height: 0.0);
                  }else {

                    return MessagesWidget(
                      mainUserImage: mainUserImage,
                      mainUserName: mainUserName,
                      mainUserID: mainUserID,
                      fcmToken: snapshot.data.documents[index]["to"],
                      imageUrl:snapshot.data.documents[index]["profileImg"],
                      chatUserName: snapshot.data.documents[index]["name"] ,
                      dateTime: snapshot.data.documents[index]["dateTime"],
                      lastMessage: snapshot.data.documents[index]["lastMessage"],
                      chatUserId:snapshot.data.documents[index]["to"] ,);}


                },

              );
            }
          },
        ),
      ),
    );
  }

}
