import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/io_client.dart';
import 'package:http/http.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:device_info/device_info.dart';
class ChangePassword extends StatefulWidget{

   @override
   _ChangePassword createState() => new _ChangePassword();

}

class _ChangePassword extends State<ChangePassword> {
  bool isLoding=false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController oldPasswordController = new TextEditingController();
  TextEditingController newPasswordController = new TextEditingController();
  TextEditingController conformNewPasswordController = new TextEditingController();
  String userIdMain="";
  bool _obscureTextLogin =true;
  var _formKey = GlobalKey<FormState>();

  void showInSnackBar(String value) {
    FocusScope.of(context).requestFocus(new FocusNode());
    _scaffoldKey.currentState?.removeCurrentSnackBar();
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.white,
            fontSize: 16.0,
            fontFamily: "WorkSansSemiBold"),
      ),
      backgroundColor: Colors.blue,
      duration: Duration(seconds: 3),
    ));
  }



  submitChangePasswordDetails() async {

    final uri = API.changePassword;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,
      "old_password": oldPasswordController.text.toString(),
      "new_password": newPasswordController.text.toString(),
      "retype_password": conformNewPasswordController.text.toString(),
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

      print(body.toString());
    print(response.body);

    loadProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:context,isSucces: true,message: (data["message"]));


        Future.delayed(Duration(seconds: 3), () {
          AppRoutes.dismiss(context);

        });


      } else {

        String dataString = data["message"].toString();
        //dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }


  @override
  void initState() {
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);

    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: false,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.chagePassword,
        ),
      ),
        bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        width: double.maxFinite,
        decoration: new BoxDecoration(
            image: DecorationImage(
                image: ExactAssetImage(Assets.background),
                fit: BoxFit.cover
            )
        ),
        child:Form(
          key: _formKey,
          child:  Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                SizedBox(height: AppSize.mediumLarge),
                Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(10),
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(125),
                  ),
                  child: Image(
                      width: 120.0,
                      height: 120.0,
                      fit: BoxFit.contain,
                      image: new AssetImage(Assets.logoImage)
                  ),
                ),
                SizedBox(height:AppSize.mediumLarge,),
                Center(
                  child: Card(
                    elevation: 2.0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Container(
                      padding: EdgeInsets.only(top: AppSize.small),
                      child: Container(
                        color: Colors.transparent,
                        width: SizeConfig.widthMultiplier*80,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(
                                  top: 0.0, bottom: 10.0, left: 25.0, right: 25.0),
                              child: TextFormField(
                                controller: oldPasswordController,
                                keyboardType: TextInputType.text,
                                validator: (value){
                                  return FieldValidator.validateEmptyCheck(value);
                                },
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: 16.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  icon: Icon(
                                    FontAwesomeIcons.lock,
                                    color: Colors.black,
                                    size:AppFontSize.textIcon,
                                  ),
                                  hintText: "Old Password",
                                  hintStyle: TextStyle(
                                      fontFamily: "WorkSansSemiBold",fontSize: AppFontSize.textHint),
                                ),
                              ),
                            ),
                            Container(
                              width: SizeConfig.widthMultiplier*70,
                              height: 1.0,
                              color: Colors.grey[400],
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: 0.0, bottom: 10.0, left: 25.0, right: 25.0),
                              child: TextFormField(
                                obscureText: _obscureTextLogin,
                                controller: newPasswordController,
                                keyboardType: TextInputType.text,
                                validator: (value){

                                  return FieldValidator.validateEmptyCheck(value);
                                },

                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: 16.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  suffixIcon: GestureDetector(
                                    onTap: _toggleLogin,
                                    child: Icon(
                                      _obscureTextLogin
                                          ? FontAwesomeIcons.eye
                                          : FontAwesomeIcons.eyeSlash,
                                      size:AppFontSize.textIcon,
                                      color: Colors.black,
                                    ),
                                  ),
                                  border: InputBorder.none,
                                  icon: Icon(
                                    FontAwesomeIcons.lock,
                                    color: Colors.black,
                                    size:AppFontSize.textIcon,
                                  ),
                                  hintText: "New Password",
                                  hintStyle: TextStyle(
                                      fontFamily: "WorkSansSemiBold",fontSize: AppFontSize.textHint),
                                ),
                              ),
                            ),
                            Container(
                              width: SizeConfig.widthMultiplier*70,
                              height: 1.0,
                              color: Colors.grey[400],
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: 0.0, bottom: 10.0, left: 25.0, right: 25.0),
                              child: TextFormField(
                                obscureText: _obscureTextLogin,
                                controller: conformNewPasswordController,
                                keyboardType: TextInputType.text,
                                validator: (value){
                                  if(value!=newPasswordController.text.toString())
                                  {
                                    return "password not match";
                                  }
                                  return FieldValidator.validateEmptyCheck(value);
                                },
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: 16.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  suffixIcon: GestureDetector(
                                    onTap: _toggleLogin,
                                    child: Icon(
                                      _obscureTextLogin
                                          ? FontAwesomeIcons.eye
                                          : FontAwesomeIcons.eyeSlash,
                                      size:AppFontSize.textIcon,
                                      color: Colors.black,
                                    ),
                                  ),
                                  border: InputBorder.none,
                                  icon: Icon(
                                    FontAwesomeIcons.lock,
                                    color: Colors.black,
                                    size:AppFontSize.textIcon,
                                  ),
                                  hintText: "Confirm Password",
                                  hintStyle: TextStyle(
                                      fontFamily: "WorkSansSemiBold",fontSize: AppFontSize.textHint),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(bottom: 20.0),
                              width: SizeConfig.widthMultiplier*70,
                              height: 1.0,
                              color: Colors.grey[400],
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height:AppSize.mediumLarge,),
                !isLoding?Container(
                  width: SizeConfig.widthMultiplier*80,
                  child: CustomRoundButtonWidget(
                    title: Constants.chagePassword,
                    callback:() async {
                                if(_formKey.currentState.validate()){
                                  loadProgress();
                                  submitChangePasswordDetails();

                                }

                    } ,
                  )
                ):Container(
                    width: SizeConfig.widthMultiplier*10,
                    child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),),
                    )
              ]
          ),
        ),
      )
    );


  }

  void loadProgress(){
    setState(() {
      isLoding =!isLoding;
    });

  }
  void _toggleLogin() {
    setState(() {
      _obscureTextLogin = !_obscureTextLogin;
    });
  }
}