import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vamos/components/background_widget.dart';
import 'package:vamos/screens/home_screen.dart';
import 'package:vamos/screens/welcome_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class SplashScreen extends StatefulWidget {
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    Future.delayed(Duration(seconds: 3), () {
      callScreen();
    });
    super.initState();
  }

  //Call screen based on conditions
  callScreen() async {
    Future<String> checKLogin = ShareMananer.isLogin();
    bool isLogin = false;

    checKLogin.then((onValue) {
      if (onValue=="null"){
        AppRoutes.makeFirst(context, WelcomeScreeen());
      }
      else {
        AppRoutes.makeFirst(context,HomeScreen());
      }
      print(onValue);
    });
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays(SystemUiOverlay.values);
    appSizeInit(context);
    return Scaffold(
        backgroundColor: Colors.white,
        body: Container(
          padding: EdgeInsets.only(right: SizeConfig.widthMultiplier*10,left: SizeConfig.widthMultiplier*10),
          child: Center(
            child: Image(
                width: screenSize.width * .50,
                fit: BoxFit.contain,
                image:new AssetImage(Assets.logoImage) ),
          ),
        ));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }
}
