import 'dart:convert';
import 'dart:io';

import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/geocoding.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';

import 'package:intl/intl.dart';
import 'package:vamos/api/api.dart';

import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/search_trip_widget.dart';
import 'package:vamos/model/add_stop_model.dart';
import 'package:vamos/model/lat_long_model.dart';
import 'package:vamos/model/trip_detail_location_model.dart';
import 'package:vamos/model/trip_route_details.dart';
import 'package:vamos/screens/post_a_trips_next_map_screen.dart';
import 'package:vamos/screens/post_a_trips_submit_screen.dart';
import 'package:vamos/screens/update_post_a_trips_next_map_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geocoder/geocoder.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:vamos/utils/app_methods.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:google_maps_webservice/places.dart';

class UpdatePostATripScreen extends StatefulWidget{
  String tripID;

  UpdatePostATripScreen(this.tripID);

  @override
  State<StatefulWidget> createState()=>new _UpdatePostATripScreen();

}
class _UpdatePostATripScreen extends State<UpdatePostATripScreen>{
  String tripStartDate="";
  String userIdMain="";
  double totalPrice=0.0;
  DateTime dateTime=null;
  bool isLoading=false;
  var tripData = null;
  double startLat=0.0,startLong=0.0,endLat=0.0,endLong=0.0;
  List<LatLongModel>listLatLong=new List<LatLongModel>();
  List<AddStopModel>listAddStop = new List<AddStopModel>();
  List<TripRouteDetails>listRouteDetails = new List<TripRouteDetails>();
  final GlobalKey<ScaffoldState> _scaffoldKey =new GlobalKey<ScaffoldState>();
  TextEditingController fromController = new TextEditingController();
  TextEditingController toController = new TextEditingController();
  TextEditingController dateController = new TextEditingController();
  TextEditingController signupPasswordController = new TextEditingController();
  TextEditingController signupConfirmPasswordController = new TextEditingController();
  TextEditingController _infoDobController = new TextEditingController();
  List<LatLng> latlngSegment1 = List();
String waypoints="";
  var kmPrice=null;
  var cop1=null;
  var cop2=null;
  var cop3=null;
  String stops="";
  List<TripDetailLocationModel>listLocation= new List();
  bool _isSearch=false;

  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();

    String  kGoogleApiKey = "AIzaSyDa9QSWtCvYdSfUPfSxAYcs-Pt4dKkJJEY";

  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: "AIzaSyDa9QSWtCvYdSfUPfSxAYcs-Pt4dKkJJEY");


  getSetting() async {
    final uri = API.getSetting;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };


    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.get(
      uri,
      headers: headers,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);


    if (statusCode == 200) {


      if (data["status"] == "true") {


     kmPrice=  data["data"]["kmprice"];
     cop1=  data["data"]["cop1"];
     cop2=  data["data"]["cop2"];
     cop3=  data["data"]["cop3"];



      } else {
        String dataString = data["message"].toString();
        dataString =
            dataString.substring(dataString.indexOf(":"), dataString.length)
                .replaceAll(":", "").replaceAll("{", "").replaceAll("}", "")
                .replaceAll("[", "")
                .replaceAll("]", "");

        showDisplayAllert(
            context: this.context, isSucces: false, message: dataString);
      }
    } else {
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }

  getTrip() async {

    final uri = API.getTripDetails;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": userIdMain,
      "post_id": widget.tripID,

    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

    progressLoad();
    if (statusCode == 200) {
      if (data["status"] == "true") {


           tripData = data["data"]["data"]["trip"];

           fromController.text=tripData["starting_location"];
           toController.text=tripData["end_location"];
           dateController.text=tripData["start_time"];
           dateTime=DateTime.parse(tripData["start_time"].toString());



          List list =  data["data"]["data"]["location"];

          for(int i =0; i<list.length;i++){
            String id = list[i]["id"].toString();
            String trackId = list[i]["trackId "].toString();
            String trip_id = list[i]["trip_id"].toString();
            String location_a_name = list[i]["location_a_name"].toString();
            String location_a_lat = list[i]["location_a_lat"].toString();
            String location_a_long = list[i]["location_a_long"].toString();
            String location_b_name = list[i]["location_b_name"].toString();
            String location_b_lat = list[i]["location_b_lat"].toString();
            String location_b_long = list[i]["location_b_long"].toString();
            String departure_datetime = list[i]["departure_datetime"].toString();
            String arrival_datetime = list[i]["arrival_datetime"].toString();
            String halt_time = list[i]["halt_time"].toString();
            String total_distance = list[i]["total_distance"].toString();
            String actual_price = list[i]["actual_price"].toString();
            String total_price = list[i]["total_price"].toString();
            String total_booked = list[i]["total_booked"].toString();
            String duration = list[i]["duration"].toString();


          TextEditingController controller= new TextEditingController();

            if(i==listLocation.length-1)
              {
                controller.text=location_a_name;
                listAddStop.add(AddStopModel(controller,double.parse(location_a_lat),double.parse(location_a_long)));
                controller.text=location_b_name;
                listAddStop.add(AddStopModel(controller,double.parse(location_b_lat),double.parse(location_b_long)));
              }
            else{
              if(i!=0)
                {
                  controller.text=location_a_name;
                  listAddStop.add(AddStopModel(controller,double.parse(location_a_lat),double.parse(location_a_long)));

                }

            }



            listLocation.add(new TripDetailLocationModel(id, trackId, trip_id, location_a_name, location_a_lat, location_a_long, location_b_name, location_b_lat, location_b_long, departure_datetime, arrival_datetime, halt_time, total_distance, actual_price, total_price, total_booked, duration));

          }


           startLat=double.parse(listLocation[0].location_a_lat);
           startLong=double.parse(listLocation[0].location_a_long);;
           endLat=double.parse(listLocation[listLocation.length-1].location_b_lat);;
           endLong=double.parse(listLocation[listLocation.length-1].location_b_long);;




      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }


    setState(() {
    });

  }



  @override
  Widget build(BuildContext context) {

    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.updateTrip,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(isGoBack: false,),
      body: Container(
        color: Colors.white,
        height: double.maxFinite,
        width: double.maxFinite,
        child: Stack(children: <Widget>[
          SingleChildScrollView(
            child:   Column(children: <Widget>[
              SizedBox(height: AppSize.medium,),
              Form(
                key: _loginFormKey,
                child: Container(
                  //width: screenSize.width,
                  child: Column(children: <Widget>[

                    Container(
                      height: SizeConfig.heightMultiplier*5,
                    ),
                    Container(
                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])
                      ),

                      child: TextFormField(
                        minLines: 1,
                        maxLines: 3,
                        onTap:  () async {
                          // show input autocomplete with selected mode
                          // then get the Prediction selected
                          Prediction p = await PlacesAutocomplete.show(
                              hint:Constants.fromWhichCityWillItLeave ,
                              context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                          displayPrediction(p,true);
                        },
                        readOnly: true,
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: fromController,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                           // fontFamily: "WorkSansSemiBold",
                            fontSize: 14.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.fromWhichCityWillItLeave,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.s13),
                          border: InputBorder.none,
                          icon: Icon(
                            Icons.directions_run,
                            color:AppTheme.primaryColor,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),

                    SizedBox(height: AppSize.medium,),
                    Container(
                      width: double.maxFinite,
                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),

                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])

                      ),


                      child: TextFormField(
                        minLines: 1,
                        maxLines: 3,
                        onTap:  () async {
                          // show input autocomplete with selected mode
                          // then get the Prediction selected
                          Prediction p = await PlacesAutocomplete.show(
                              hint: Constants.whichCityWillYouTravelTo,
                              context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                          displayPrediction(p,false);
                        },
                        readOnly: true,
                        validator: (String value) {
                          return FieldValidator.validateEmptyCheck(value);
                        },
                        controller: toController,
                        keyboardType: TextInputType.text,
                        textCapitalization:
                        TextCapitalization.words,
                        style: TextStyle(
                          //  fontFamily: "WorkSansSemiBold",
                            fontSize: 14.0,
                            color: Colors.black),
                        decoration: InputDecoration(
                          labelText: Constants.whichCityWillYouTravelTo,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.s13),
                          border: InputBorder.none,
                          icon: Icon(
                            Icons.directions_walk,
                            color:AppTheme.primaryColor,
                            size:AppFontSize.textIcon,
                          ),

                        ),
                      ),
                    ),






                    SizedBox(height: AppSize.medium,),





                    Container(

                      margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),
                      width: double.maxFinite,
                      padding: EdgeInsets.only(
                          left:6.0*SizeConfig.widthMultiplier,
                          right:6.0*SizeConfig.widthMultiplier),
                      decoration:  BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(width: 1.0,color: Colors.grey[200])
                      ),

                      child:    DateTimeField(
                        controller: dateController,
                        resetIcon: Icon(Icons.phone,color: Colors.grey[200],),
                        decoration:InputDecoration(
                          labelText: Constants.startTime,
                          labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.s13),
                          border: InputBorder.none,
                          icon: Icon(
                            FontAwesomeIcons.calendar,
                            color:AppTheme.primaryColor,
                            size:AppFontSize.textIcon,
                          ),

                        ) ,
                        format: DateFormat("yyyy-MM-dd HH:mm:ss"),
                        onShowPicker: (context, currentValue) async {
                          final date = await showDatePicker(
                              context: context,
                              firstDate: DateTime(2020),
                              initialDate: currentValue ?? DateTime.now(),
                              lastDate: DateTime(2100));
                          if (date != null) {
                            final time = await showTimePicker(
                              context: context,
                              initialTime:
                              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
                            );

                            dateTime=DateTimeField.combine(date, time);
                            dateController.text=dateTime.toString();

                            return DateTimeField.combine(date, time);
                          } else {
                            print(currentValue.toString());
                            return currentValue;
                          }
                        },
                      ),
                    ),



                    SizedBox(height: AppSize.large,),

                    Container(
                      width: SizeConfig.widthMultiplier*90,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[

                          Container(
                            width: SizeConfig.widthMultiplier*55,
                            child:  CustomRoundButtonWidget(
                              title: Constants.addNewStop,
                              callback: () {

                                setState(() {
                                  listAddStop.add(AddStopModel(TextEditingController(),0.0,0.0));

                                });
                                // AppRoutes.goto(context, SearchTripsResultScreen());
                              },
                            ),),

                          Container(
                            width: SizeConfig.widthMultiplier*30,
                            child:  CustomRoundButtonWidget(
                              title: Constants.next,
                              callback: () {

                                if(_loginFormKey.currentState.validate())
                                {

                                  if(dateTime==null){
                                    showDisplayAllert(context: context,isSucces: false,message: Constants.tripDateError);

                                  }
                                  else{
                                    progressLoad();
                                    listLatLong.clear();
                                    listLatLong.add(new LatLongModel(startLat, startLong,fromController.text));
                                    latlngSegment1.clear();

                                    latlngSegment1.add(LatLng(startLat,startLong));


                                    if(listAddStop.length!=0)
                                    {
                                      for(int i =0;i<listAddStop.length;i++)
                                      {
                                        listLatLong.add(new LatLongModel(listAddStop[i].lat, listAddStop[i].long,listAddStop[i].editingController.text));
                                        latlngSegment1.add(LatLng(listAddStop[i].lat, listAddStop[i].long));

                                      }

                                    }

                                    latlngSegment1.add(LatLng(endLat,endLong));
                                    listLatLong.add(new LatLongModel(endLat, endLong,toController.text));

                                    calculate();
                                  }

                                }

                              },
                            ),)

                        ],),
                    ),




                    SizedBox(height: AppSize.large,),

                    ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: listAddStop.length,
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemBuilder: (BuildContext context, int index) {
                        return Column(children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),
                            width: double.maxFinite,
                            padding: EdgeInsets.only(
                                left:6.0*SizeConfig.widthMultiplier,
                                right:1.0*SizeConfig.widthMultiplier),
                            decoration:  BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(width: 1.0,color: Colors.grey[200])
                            ),

                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Container(
                                  width: SizeConfig.widthMultiplier*62,
                                  child: TextFormField(
                                    minLines: 1,
                                    maxLines: 3,
                                    onTap:  () async {
                                      // show input autocomplete with selected mode
                                      // then get the Prediction selected
                                      Prediction p = await PlacesAutocomplete.show(
                                          hint:Constants.inWhichCitiesWillItStop ,
                                          context: context, apiKey: kGoogleApiKey,logo:SizedBox(width: AppSize.extraLarge,));
                                      displayPredictionForAddStop(p,index);
                                    },
                                    readOnly: true,
                                    validator: (String value) {
                                      return FieldValidator.validateEmptyCheck(value);
                                    },
                                    controller: listAddStop[index].editingController,
                                    keyboardType: TextInputType.text,
                                    textCapitalization:
                                    TextCapitalization.words,
                                    style: TextStyle(
                                      // fontFamily: "WorkSansSemiBold",
                                        fontSize: 14.0,
                                        color: Colors.black),
                                    decoration: InputDecoration(
                                      labelText: Constants.inWhichCitiesWillItStop,
                                      labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.s13),
                                      border: InputBorder.none,
                                      icon: Icon(
                                        Icons.assistant_photo,
                                        color: AppTheme.primaryColor,
                                        size:AppFontSize.textIcon,
                                      ),

                                    ),
                                  ),
                                ),
                                Container(
                                  height: AppSize.xxL,
                                  alignment: Alignment.topRight,
                                  width: SizeConfig.widthMultiplier*20,
                                  child: GestureDetector(
                                    onTap: (){
                                      setState(() {
                                        listAddStop.removeAt(index);

                                      });
                                    },
                                    child: Icon(Icons.cancel,color: Colors.red,size: AppSize.medium,),),)
                              ],),
                          ),
                          SizedBox(height: AppSize.medium,),
                        ],);

                      },
                    ),
                  ],),
                ),
              ),


            ],),
          ),
         isLoading? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center(child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,)

        ],),
      ),
    );
  }


  @override
  void initState() {
    progressLoad();
    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);
      getTrip();

    });
    getSetting();
  }

  Future<Null> displayPrediction(Prediction p,bool clickType) async {
    if (p != null) {
      progressLoad();
      PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(p.placeId);

      var placeId = p.placeId;
      double lat = detail.result.geometry.location.lat;
      double lng = detail.result.geometry.location.lng;


      var address = await Geocoder.local.findAddressesFromQuery(p.description);


      if(clickType)
        {
          fromController.text=address.first.addressLine.toString();
          startLat=lat;
          startLong=lng;

        }
      else{
        endLat=lat;
        endLong=lng;
        toController.text=address.first.addressLine.toString();


      }
      progressLoad();
      print(address.first.addressLine);
      print(placeId);
    }
  }




  Future<Null> displayPredictionForAddStop(Prediction p,int index) async {
    if (p != null) {
      progressLoad();
      PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(p.placeId);

      var placeId = p.placeId;
      double lat = detail.result.geometry.location.lat;
      double lng = detail.result.geometry.location.lng;

      var address = await Geocoder.local.findAddressesFromQuery(p.description);


    listAddStop[index].editingController.text=address.first.addressLine;
    listAddStop[index].lat=lat;
    listAddStop[index].long=lng;
      progressLoad();
      print(address.first.addressLine);
      print(placeId);
    }
  }




  calculate()async{
    
    listRouteDetails.clear();
    DateTime subDate=dateTime;
    final geocoding = new GoogleMapsGeocoding(apiKey: API.googleMapApiKey);


    var formatter = new DateFormat('yyyy-MM-dd HH:mm:ss');
    tripStartDate = formatter.format(subDate);



    for(int i=0;i<listLatLong.length-1;i++)
      {


        print("${listLatLong[i].lat} &  ${listLatLong[i].long}");

        print("${listLatLong[i+1].lat} &  ${listLatLong[i+1].long}");


        Response response = await geocoding.doGet("https://maps.googleapis.com/maps/api/distancematrix/json?origins=${listLatLong[i].lat},${listLatLong[i].long}&destinations=${listLatLong[i+1].lat},${listLatLong[i+1].long}&key="+API.googleMapApiKey);


        print(response.body.toString());


       final responseData =jsonDecode(response.body);



   if(responseData["status"]=="OK") {
     String distance = responseData["rows"][0]["elements"][0]["distance"]["text"];
     double distanceValue =double.parse(distance.substring(0, distance.indexOf(" ")));
     String duration = responseData["rows"][0]["elements"][0]["duration"]["text"];
     double priceValue =double.parse( kmPrice["value"]);
     double cop1Value =double.parse( cop1["value"]);
     double cop2Value =double.parse( cop2["value"]);
     double cop3Value =double.parse( cop3["value"]);
      int timeDurationInSeconds =responseData["rows"][0]["elements"][0]["duration"]["value"];
  double price = ((((distanceValue*priceValue)*cop1Value)+cop2Value)*cop3Value);

  totalPrice=totalPrice+price;

    String origin_addresses =responseData["origin_addresses"][0];
    String destination_addresses =responseData["destination_addresses"][0];


   // print(subDate.add(Duration(seconds: timeDurationInSeconds)));
    subDate=subDate.add(Duration(seconds: timeDurationInSeconds));
 //   print(subDate);
    var formatter = new DateFormat('yyyy-MM-dd HH:mm:ss');
    String formatted = formatter.format(subDate);
    print(formatted);

    TextEditingController controller = new TextEditingController();
    controller.text="0";

     listRouteDetails.add(new TripRouteDetails(origin_addresses,destination_addresses, distanceValue.toString(),
         duration, price.round().toString(),formatted,controller,timeDurationInSeconds,formatted,price.round().toString()));


   }

      }

    progressLoad();


    AppRoutes.goto(context, Update_PostATripNextMapScreen(listRouteDetails:listRouteDetails,
      latlngSegment1:latlngSegment1,date:
      tripStartDate,totalPrice: totalPrice.round().toString(),tripId: widget.tripID,tripData: tripData,));



  }


  progressLoad(){
    setState(() {

      isLoading=!isLoading;
    });
  }
}
