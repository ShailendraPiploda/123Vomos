import 'dart:convert';
import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:device_info/device_info.dart';
import 'home_screen.dart';
import 'login_screen.dart';
import 'package:firebase_database/firebase_database.dart';

class SignUpScreen extends StatefulWidget {
  State<SignUpScreen> createState() => _SignUpScreen();
}

class _SignUpScreen extends State<SignUpScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey =
  new GlobalKey<ScaffoldState>();
  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();
  String _groupValue = "1";
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController signupEmailController = new TextEditingController();
  TextEditingController signupFirstNameController = new TextEditingController();
  TextEditingController signupLastNameController = new TextEditingController();
  TextEditingController signupPasswordController = new TextEditingController();
  TextEditingController signupConfirmPasswordController = new TextEditingController();
  bool isLoding=false;
  String fcmToken="";
  final FirebaseMessaging _fcm = FirebaseMessaging();


  submitSignUpDetails() async {
    String device = "",deviceID="";

    if (Platform.isAndroid) {
      var androidInfo = await DeviceInfoPlugin().androidInfo;
      deviceID= androidInfo.androidId.toString();

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";
      var androidInfo = await DeviceInfoPlugin().iosInfo;
      deviceID= androidInfo.identifierForVendor.toString();
    }
    final uri = API.signUp;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "email": signupEmailController.text.toString(),
      "first_name": signupFirstNameController.text.toString(),
      "last_name": signupLastNameController.text.toString(),
      "gender": _groupValue,
      "password": signupPasswordController.text.toString(),
      "cnf_password": signupConfirmPasswordController.text.toString(),
      "device_type": device,
      "device_token": deviceID
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

  //  print(jsonBody);
     print(response.body);

    loadProgress();
    if (statusCode == 200) {
      if (data["status"] == true) {



        showDisplayAllert(context:context,isSucces: true,message: (data["message"]));
        Future.delayed(Duration(seconds: 1), () {
          AppRoutes.makeFirst(context, LoginScreen());
        });


      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }


  @override
  Widget build(BuildContext context) {




    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.signUp,
        ),
      ),
      body: Container(
        alignment: Alignment.center,
        width: double.maxFinite,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: ExactAssetImage(Assets.banner),
            fit: BoxFit.cover
          )
        ),
        child: Stack(children: <Widget>[
          SingleChildScrollView(child:
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[

            SizedBox(height: AppSize.medium,),
            Card(
              elevation: 5.0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0)
              ),
              child: Container(
                width: SizeConfig.widthMultiplier*90,
                child: Column(children: <Widget>[

                  SizedBox(height: AppSize.mediumLarge,),

                  Text(
                    Constants.facebookSignUpSubtitle,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: AppFontSize.s17,color: Colors.black),),

                  SizedBox(height: AppSize.mediumLarge,),



                  Container(
                      width: SizeConfig.widthMultiplier*70,
                      child: SignInButton(
                        Buttons.Facebook,
                        onPressed: () {
                          signupWith();

                        },
                      )


                  ),
                  SizedBox(height: AppSize.mediumLarge,),

                  Row(children: <Widget>[
                    Container(
                      height: 1.0,
                      width: SizeConfig.widthMultiplier*40,
                      color: Colors.grey,),
                    Container(
                      width: SizeConfig.widthMultiplier*10,
                      child:  Text(
                        Constants.or,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: AppFontSize.s18,color: Colors.black),),),
                    Container(
                      height: 1.0,
                      width: SizeConfig.widthMultiplier*40,
                      color: Colors.grey,)

                  ],),

                  Form(
                    key: _loginFormKey,
                    child: Column(children: <Widget>[
                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),

                        child: TextFormField(
                          validator: (String value) {
                            return FieldValidator.validateEmptyCheck(value);
                          },
                          controller: signupFirstNameController,
                          keyboardType: TextInputType.text,
                          textCapitalization:
                          TextCapitalization.words,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 2.0*SizeConfig.textMultiplier,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.firstName,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              FontAwesomeIcons.user,
                              color: Colors.black,
                              size:AppFontSize.textIcon,
                            ),

                          ),
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(
                          // top:0.5*SizeConfig.heightMultiplier,
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),
                        width: double.maxFinite,
                        height: 1.0,
                        color: Colors.grey[400],
                      ),

                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),


                        child: TextFormField(
                          validator: (String value) {
                            return FieldValidator.validateEmptyCheck(value);
                          },
                          controller: signupLastNameController,
                          keyboardType: TextInputType.text,
                          textCapitalization:
                          TextCapitalization.words,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.lastName,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              FontAwesomeIcons.user,
                              color: Colors.black,
                              size: AppFontSize.textIcon,
                            ),

                          ),
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(
                          // top:0.5*SizeConfig.heightMultiplier,
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),
                        width: double.maxFinite,
                        height: 1.0,
                        color: Colors.grey[400],
                      ),

                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),


                        child: TextFormField(
                          validator: (String value) {

                            return FieldValidator.validateEmail(value);
                          },
                          controller: signupEmailController,
                          keyboardType: TextInputType.emailAddress,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.enterEmail,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              FontAwesomeIcons.envelope,
                              color: Colors.black,
                              size:AppFontSize.textIcon,
                            ),

                          ),
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(
                          // top:0.5*SizeConfig.heightMultiplier,
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),
                        width: double.maxFinite,
                        height: 1.0,
                        color: Colors.grey[400],
                      ),

                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),


                        child: TextFormField(
                          validator: (String value) {
                            return FieldValidator.validateEmptyCheck(value);
                          },
                          controller: signupPasswordController,
                          obscureText: _obscureTextLogin,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.password,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              FontAwesomeIcons.lock,
                              color: Colors.black,
                              size: AppFontSize.textIcon,
                            ),

                            suffixIcon: GestureDetector(
                              onTap: _toggleLogin,
                              child: Icon(
                                _obscureTextLogin
                                    ? FontAwesomeIcons.eye
                                    : FontAwesomeIcons.eyeSlash,
                                size: AppFontSize.textIcon,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(
                          // top:0.5*SizeConfig.heightMultiplier,
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),
                        width: double.maxFinite,
                        height: 1.0,
                        color: Colors.grey[400],
                      ),

                      Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.only(
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),


                        child: TextFormField(
                          validator: (String value) {
                            if (value !=
                                signupPasswordController.text
                                    .toString()) {
                              return "Password or Confirm not match";
                            }
                            return FieldValidator.validateEmptyCheck(value);
                          },
                          controller: signupConfirmPasswordController,
                          obscureText: _obscureTextLogin,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black),
                          decoration: InputDecoration(
                            labelText: Constants.confirmPassword,
                            labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                            border: InputBorder.none,
                            icon: Icon(
                              FontAwesomeIcons.lock,
                              color: Colors.black,
                              size:AppFontSize.textIcon,
                            ),

                            suffixIcon: GestureDetector(
                              onTap: _toggleLogin,
                              child: Icon(
                                _obscureTextLogin
                                    ? FontAwesomeIcons.eye
                                    : FontAwesomeIcons.eyeSlash,
                                size: AppFontSize.textIcon,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(
                          // top:0.5*SizeConfig.heightMultiplier,
                            left:6.0*SizeConfig.widthMultiplier,
                            right:6.0*SizeConfig.widthMultiplier),
                        width: double.maxFinite,
                        height: 1.0,
                        color: Colors.grey[400],
                      ),

                      SizedBox(height: AppSize.small,),

                      Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Container(
                              width:SizeConfig.widthMultiplier*45,
                              child: Row(
                                children: <Widget>[
                                  Radio(
                                    onChanged: (newValue) =>
                                        setState(() =>
                                        _groupValue = newValue),
                                    value: "1",
                                    activeColor: AppTheme.accentColor,
                                    groupValue: _groupValue,
                                  ),
                                  Text(
                                    'Male',
                                    style: TextStyle(
                                        fontFamily:
                                        "WorkSansSemiBold",
                                        fontSize: 16.0,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                          Container(
                              width: SizeConfig.widthMultiplier*45,
                              child: Row(
                                children: <Widget>[
                                  Radio(
                                    activeColor: AppTheme.accentColor,
                                    onChanged: (newValue) =>
                                        setState(() =>
                                        _groupValue = newValue),
                                    value: "2",
                                    groupValue: _groupValue,
                                  ),
                                  Text(
                                    'Female',
                                    style: TextStyle(
                                        fontFamily:
                                        "WorkSansSemiBold",
                                        fontSize: 16.0,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                        ],
                      ),


                      Container(
                        alignment: Alignment.center,
                        margin: EdgeInsets.all(10.0),
                        child:  Text(
                          Constants.termsAndConditions,
                          textAlign: TextAlign.justify,
                          style: TextStyle(fontSize: AppFontSize.s12,color: Colors.black),),
                      ),

                      SizedBox(height: AppSize.mediumLarge,),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[

                          CustomRoundButtonWidget(
                            buttonWidth: SizeConfig.widthMultiplier*30,
                            title: Constants.signUp,
                            callback: () {

                              if(_loginFormKey.currentState.validate())
                              {
                                loadProgress();


                                submitSignUpDetails();
                              }

                              // AppRoutes.replace(context, LoginScreen());
                            },
                          ),


                          GestureDetector(
                            child: Text(
                              Constants.logIn,
                              textAlign: TextAlign.end,
                              style: TextStyle(fontSize: AppFontSize.s20,color:AppTheme.primaryColor),),
                            onTap: (){
                              AppRoutes.replace(context, LoginScreen());
                            },
                          )

                        ],),

                      SizedBox(height: AppSize.mediumLarge,),



                    ],),
                  )
                ],),
              ),

            ),
            SizedBox(height: AppSize.medium,),
          ],),),
          isLoding? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),
        ],),
      ),
    );



  }
  @override
  void initState() {
    _fcm.getToken().then((String token) {
      assert(token != null);
      print(token);
      setState(() {
        fcmToken=token;
      });

    });
  }


  void loadProgress(){
    setState(() {
      isLoding =!isLoding;
    });

  }

    Future<FacebookLoginResult> _handleFBSignIn() async {
      FacebookLogin facebookLogin = FacebookLogin();
      facebookLogin.loginBehavior = FacebookLoginBehavior.webViewOnly;
      FacebookLoginResult facebookLoginResult =
      await facebookLogin.logIn(['email']);

      switch (facebookLoginResult.status) {
        case FacebookLoginStatus.cancelledByUser:
          print("Cancelled");
          loadProgress();
          break;
        case FacebookLoginStatus.error:
          print("error");
          loadProgress();
          break;
        case FacebookLoginStatus.loggedIn:

          print("Logged In");
          break;
      }
      return facebookLoginResult;
    }


  signupWith()async{
    loadProgress();
    FacebookLoginResult facebookLoginResult = await _handleFBSignIn();
    final accessToken = facebookLoginResult.accessToken.token;
    if (facebookLoginResult.status == FacebookLoginStatus.loggedIn) {
      final facebookAuthCred =
      FacebookAuthProvider.getCredential(accessToken: accessToken);
      final user =      await _auth.signInWithCredential(facebookAuthCred);
      print("User : " + user.additionalUserInfo.toString());


      bool trustSelfSigned = true;
      HttpClient httpClient = new HttpClient()
        ..badCertificateCallback =
        ((X509Certificate cert, String host, int port) => trustSelfSigned);
      IOClient ioClient = new IOClient(httpClient);


      final graphResponse = await ioClient.get(
          'https://graph.facebook.com/v2.12/me?fields=name,first_name,last_name,email,picture &access_token=${accessToken}');

      final data = json.decode(graphResponse.body);



      String name = data["name"].toString();
      String first_name = data["first_name"].toString();
      String last_name = data["last_name"].toString();
      String email = data["email"].toString();
      String id = data["id"].toString();
      final picData = data["picture"];
      String url = picData["data"]["url"].toString();
      print(url.toString());

      facebookServerSideSignUp(id,email,name,first_name,last_name,url);


    }
  }

  facebookServerSideSignUp(String id,String email,String username,String firstname,String lastname,String imageUrl) async
  {
    String device = "";

    if (Platform.isAndroid) {

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";

    }

    final uri = API.socialsignin;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "loginType": "facebook",
      "facebookId":id,
      "email":email,
      "imgUrl": imageUrl,
      "firstName":firstname,
      "lastName": lastname,
      "device_type": device,
      "device_token": fcmToken
    };

    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    loadProgress();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:context,isSucces: true,message:data["message"]);
        String id = data["data"]["data"]["id"].toString();
        String user_type = data["data"]["data"]["user_type"].toString();
        String reg_type = data["data"]["data"]["reg_type"].toString();
        String google_id = data["data"]["data"]["google_id"].toString();
        String facebook_id = data["data"]["data"]["facebook_id"].toString();
        String user_name = data["data"]["data"]["user_name"].toString();
        String first_name = data["data"]["data"]["first_name"].toString();
        String  last_name = data["data"]["data"]["last_name"].toString();
        String gender = data["data"]["data"]["gender"].toString();
        String email = data["data"]["data"]["email"].toString();
        String google_email = data["data"]["data"]["google_email"].toString();
        String  facebook_email = data["data"]["data"]["facebook_email"].toString();
        String  email_varified = data["data"]["data"]["email_varified"].toString();
        String   image = data["data"]["data"]["image"].toString();
        String  google_image = data["data"]["data"]["google_image"].toString();
        String  facebook_image = data["data"]["data"]["facebook_image"].toString();
        String   driving_id = data["data"]["data"]["driving_id"].toString();
        String   drive_frontimage = data["data"]["data"]["drive_frontimage"].toString();
        String   drive_backimage = data["data"]["data"]["drive_backimage"].toString();
        String   drive_image_verification = data["data"]["data"]["drive_image_verification"].toString();
        String  driving_cancle_cause = data["data"]["data"]["driving_cancle_cause"].toString();

        String  driving_exp = data["data"]["data"]["driving_exp"].toString();
        String  phone_code = data["data"]["data"]["phone_code"].toString();
        String   phone = data["data"]["data"]["phone"].toString();
        String   phone_verification = data["data"]["data"]["phone_verification"].toString();
        String   birth_year = data["data"]["data"]["birth_year"].toString();
        String  bio = data["data"]["data"]["bio"].toString();
        String  identity_document_verified = data["data"]["data"]["identity_document_verified"].toString();
        String  profile_image_status = data["data"]["data"]["profile_image_status"].toString();
        String  status = data["data"]["data"]["status"].toString();
        String  device_type = data["data"]["data"]["device_type"].toString();
        String  device_token = data["data"]["data"]["device_token"].toString();
        String  added_date = data["data"]["data"]["added_date"].toString();
        String  update_date = data["data"]["data"]["update_date"].toString();

        String  rating = data["rating"]["avg_rating"]["avg_rating"].toString();
        List list = data["rating"]["rating_master"];
        print(id);


        ShareMananer.setLoginDetails(id, user_type, reg_type, google_id, facebook_id, user_name, first_name,last_name, gender,
            email, google_email, facebook_email, email_varified, image, google_image, facebook_image, driving_id,
            drive_frontimage, drive_backimage, drive_image_verification, driving_cancle_cause, driving_exp,
            phone_code, phone, phone_verification, birth_year, bio, identity_document_verified, profile_image_status,
            status, device_type, device_token, added_date, update_date, rating,list.length.toString(),true);

        Firestore.instance.collection('users').document(id).setData(
            {
              'name': first_name+" "+last_name,
              'email': email,
              'id': id,
              "fcm": fcmToken,
              "isOnline": true,
              "profileImg": API.baseProfileImageUrl+image,
              "lastMessage": ""
            });


        Future.delayed(Duration(seconds: 1), () {
          AppRoutes.makeFirst(context,HomeScreen());


        });


      } else {


        String dataString = data["message"].toString();
        // dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {

      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }
  void _toggleLogin() {
    setState(() {

      _obscureTextLogin = !_obscureTextLogin;
    });
  }
}
