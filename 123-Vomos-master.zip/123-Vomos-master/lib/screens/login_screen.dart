import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/alert_widget.dart';
import 'package:vamos/components/app_alert_widget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/screens/forgot_password_screen.dart';
import 'package:vamos/screens/signup_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:device_info/device_info.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  State<LoginScreen> createState() => _LoginScreen();
}

class _LoginScreen extends State<LoginScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String fcmToken="";
  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();
  bool isLoding=false;
  final FirebaseMessaging _fcm = FirebaseMessaging();
  TextEditingController loginEmailController = new TextEditingController();
  TextEditingController loginPasswordController = new TextEditingController();

  FirebaseAuth _auth = FirebaseAuth.instance;

   submitLogInDetails() async {
    String device = "";

    if (Platform.isAndroid) {

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";

    }
    final uri = API.login;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "email": loginEmailController.text.toString(),
      "password": loginPasswordController.text.toString(),
      "device_type": device,
      "device_token": fcmToken
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

   // print(jsonBody);
    //print(response.body);


    if (statusCode == 200) {
      if (data["status"] == true) {
      showDisplayAllert(context:context,isSucces: true,message: (data["message"]));


        String id = data["data"]["id"].toString();
        String user_type = data["data"]["user_type"].toString();
        String reg_type = data["data"]["reg_type"].toString();
        String google_id = data["data"]["google_id"].toString();
        String facebook_id = data["data"]["facebook_id"].toString();
        String user_name = data["data"]["user_name"].toString();
        String first_name = data["data"]["first_name"].toString();
        String  last_name = data["data"]["last_name"].toString();
        String gender = data["data"]["gender"].toString();
        String email = data["data"]["email"].toString();
        String google_email = data["data"]["google_email"].toString();
        String  facebook_email = data["data"]["facebook_email"].toString();
        String  email_varified = data["data"]["email_varified"].toString();
        String   image = data["data"]["image"].toString();
        String  google_image = data["data"]["google_image"].toString();
        String  facebook_image = data["data"]["facebook_image"].toString();
        String   driving_id = data["data"]["driving_id"].toString();
        String   drive_frontimage = data["data"]["drive_frontimage"].toString();
        String   drive_backimage = data["data"]["drive_backimage"].toString();
        String   drive_image_verification = data["data"]["drive_image_verification"].toString();
        String  driving_cancle_cause = data["data"]["driving_cancle_cause"].toString();

        String  driving_exp = data["data"]["driving_exp"].toString();
        String  phone_code = data["data"]["phone_code"].toString();
        String   phone = data["data"]["phone"].toString();
        String   phone_verification = data["data"]["phone_verification"].toString();
        String   birth_year = data["data"]["birth_year"].toString();
        String  bio = data["data"]["bio"].toString();
        String  identity_document_verified = data["data"]["identity_document_verified"].toString();
        String  profile_image_status = data["data"]["profile_image_status"].toString();
        String  status = data["data"]["status"].toString();
        String  device_type = data["data"]["device_type"].toString();
        String  device_token = data["data"]["device_token"].toString();
        String  added_date = data["data"]["added_date"].toString();
        String  update_date = data["data"]["update_date"].toString();
        String  rating = data["rating"]["avg_rating"]["avg_rating"].toString();
        List list = data["rating"]["rating_master"];



       ShareMananer.setLoginDetails(id, user_type, reg_type, google_id, facebook_id, user_name, first_name,last_name, gender,
           email, google_email, facebook_email, email_varified, image, google_image, facebook_image, driving_id,
           drive_frontimage, drive_backimage, drive_image_verification, driving_cancle_cause, driving_exp,
           phone_code, phone, phone_verification, birth_year, bio, identity_document_verified, profile_image_status,
           status, device_type, device_token, added_date, update_date, rating,list.length.toString(),true);


        Firestore.instance.collection('users').document(id).setData(
            {
              'name': first_name+" "+last_name,
              'email': email,
              'id': id,
              "fcm": fcmToken,
              "isOnline": true,
              "profileImg": API.baseProfileImageUrl+image,
              "lastMessage": ""
            });

        loadProgress();
        Future.delayed(Duration(seconds: 1), () {
          AppRoutes.makeFirst(context,HomeScreen());


        });


      // signUpWithFirebase(loginEmailController.text,loginPasswordController.text,data["message"].toString(),image);


      } else {
        loadProgress();
        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");

        showDisplayAllert(context:context,isSucces: false,message: dataString);
      }
    } else {
      loadProgress();
     showDisplayAllert(context:context,isSucces: false,message: data["message"]);

    }

  }

  Future signUpWithFirebase(String email,String password,String serverMessage,String image)async{

    try{


      AuthResult result=await _auth.signInWithEmailAndPassword(email: email, password: password);

      FirebaseUser user =result.user;
      
      
      Firestore.instance.collection("users").document(user.uid).
      updateData({'isOnline':true,'profileImg':API.baseProfileImageUrl+image,"fcm":fcmToken});

      print(user.email.toString());
      showDisplayAllert(context:context,isSucces: true,message:serverMessage);
      loadProgress();
      Future.delayed(Duration(seconds: 1), () {
        AppRoutes.makeFirst(context,HomeScreen());


      });




    }catch (e){

    }

  }


  @override
  Widget build(BuildContext context) {



    return Scaffold(
      key: _scaffoldKey,
    //  resizeToAvoidBottomInset: false,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.logIn,
        ),
      ),
      body: Container(
        width: double.maxFinite,
        height: double.maxFinite,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: ExactAssetImage(Assets.banner),
            fit: BoxFit.fill
          )
        ),
        child: Stack(children: <Widget>[
          SingleChildScrollView(child:
          Column(children: <Widget>[
            SizedBox(height: AppSize.large,),
            Container(
              margin: EdgeInsets.all(4*SizeConfig.widthMultiplier),
              child:  Card(
                elevation: 5.0,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0)
                ),
                child: Container(

                  width: double.maxFinite,
                  child: Column(children: <Widget>[

                    SizedBox(height: AppSize.large,),

                    Text(
                      Constants.faceBookSubtitle,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 2.0*SizeConfig.textMultiplier,color: Colors.black),),

                    SizedBox(height: AppSize.large,),

                    Container(
                        width: SizeConfig.widthMultiplier*70,
                        child: SignInButton(
                          Buttons.Facebook,
                          onPressed: () {
                            signupWith();

                          },)


                    ),

                    SizedBox(height: AppSize.large,),


                    Row(children: <Widget>[
                      Expanded(
                        flex: 4,
                        child: Container(
                          height: 1.0,
                          color: Colors.grey,),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                          child:  Text(
                            Constants.or,
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize:2.0*SizeConfig.textMultiplier,color: Colors.black),),),
                      ),
                      Expanded(
                        flex: 4,
                        child: Container(
                          height: 1.0,
                          color: Colors.grey,),
                      )

                    ],),

                    SizedBox(height: AppSize.large,),

                    Form(
                      key: _loginFormKey,
                      child: Column(children: <Widget>[
                        Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              left:6.0*SizeConfig.widthMultiplier,
                              right:6.0*SizeConfig.widthMultiplier),
                          child: TextFormField(
                            validator: (value) {
                              return FieldValidator.validateEmail(value);
                            },
                            controller: loginEmailController,
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: 2.0*SizeConfig.textMultiplier,
                                color: Colors.black),
                            decoration: InputDecoration(
                              labelText: Constants.enterEmail,
                              labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                              border: InputBorder.none,
                              icon: Icon(
                                FontAwesomeIcons.envelope,
                                color: Colors.black,
                                size: AppFontSize.textIcon,
                              ),

                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            // top:0.5*SizeConfig.heightMultiplier,
                              left:6.0*SizeConfig.widthMultiplier,
                              right:6.0*SizeConfig.widthMultiplier),
                          width: double.maxFinite,
                          height: 1.0,
                          color: Colors.grey[400],
                        ),
                        Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              top:2.0*SizeConfig.heightMultiplier,
                              left:6.0*SizeConfig.widthMultiplier,
                              right:6.0*SizeConfig.widthMultiplier),
                          child: TextFormField(
                            validator: (String value) {
                              return FieldValidator.validateEmptyCheck(value);
                            },
                            controller: loginPasswordController,
                            obscureText: _obscureTextLogin,
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: 16.0,
                                color: Colors.black),
                            decoration: InputDecoration(
                              labelText: Constants.enterPassword,
                              labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                              border: InputBorder.none,
                              icon: Icon(
                                FontAwesomeIcons.lock,
                                color: Colors.black,
                                size: AppFontSize.textIcon,
                              ),

                              suffixIcon: GestureDetector(
                                onTap: (){
                                  _toggleLogin();
                                },
                                child: Icon(
                                  _obscureTextLogin
                                      ? FontAwesomeIcons.eye
                                      : FontAwesomeIcons.eyeSlash,
                                  size: AppFontSize.textIcon,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            // top:1.0*SizeConfig.heightMultiplier,
                              left:6.0*SizeConfig.widthMultiplier,
                              right:6.0*SizeConfig.widthMultiplier),
                          width: double.maxFinite,
                          height: 1.0,
                          color: Colors.grey[400],
                        ),

                        SizedBox(height: AppSize.large,),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[

                           Container(
                                width: SizeConfig.widthMultiplier*30,
                                child:CustomRoundButtonWidget(
                                  buttonWidth: SizeConfig.widthMultiplier*30,
                                  title: Constants.login,
                                  callback: () async {

                                    if(_loginFormKey.currentState.validate())
                                    {
                                      loadProgress();

                                      submitLogInDetails();
//                                   isLoding = await showDialog(
//                                       context: context,
//                                       builder: (BuildContext context) {
//                                         return Center(
//                                           child: CircularProgressIndicator(),
//                                         );
//                                       });
                                    }
                                  },
                                ) ),

                            Container(
                                width: SizeConfig.widthMultiplier*40,
                                child:  GestureDetector(
                                  onTap: (){
                                    print("sdasd00");
                                    AppRoutes.goto(context,ForgotPassword());
                                  },
                                  child: Text(
                                    Constants.forgotPassword,
                                    textAlign: TextAlign.end,
                                    style: TextStyle(fontSize: 2.0*SizeConfig.textMultiplier,color: Colors.black),),
                                )),

                          ],),

                        SizedBox(height: AppSize.large,),

                        GestureDetector(
                          onTap: (){
                            AppRoutes.replace(context, SignUpScreen());
                          },
                          child:  Text(
                            Constants.notYetMember,
                            textAlign: TextAlign.end,
                            style: TextStyle(fontSize: 2.0*SizeConfig.textMultiplier,color: AppTheme.accentColor),
                          ),
                        ),



                        SizedBox(height: AppSize.large,),

                      ],),
                    )
                  ],),
                ),

              ),
            )
          ],),),
          isLoding? Container(
            color: Colors.black.withOpacity(0.5),
            width: double.maxFinite,
            height: SizeConfig.heightMultiplier*90,
            child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),)),

          ):SizedBox(height: 0.0,),
        ],),
      ),
    );



  }


  @override
  void initState() {
    _fcm.getToken().then((String token) {
      assert(token != null);
      print(token);
      setState(() {
        fcmToken=token;
      });

    });
  }

  void loadProgress(){
    setState(() {
      isLoding =!isLoding;
    });

  }

  Future<FacebookLoginResult> _handleFBSignIn() async {
    FacebookLogin facebookLogin = FacebookLogin();
    facebookLogin.loginBehavior = FacebookLoginBehavior.webViewOnly;
    FacebookLoginResult facebookLoginResult =
    await facebookLogin.logIn(['email']);

    print("Dcsfsfsdfs"+facebookLoginResult.status.toString());

    switch (facebookLoginResult.status) {
      case FacebookLoginStatus.cancelledByUser:
        print("Cancelled");
        loadProgress();
        break;
      case FacebookLoginStatus.error:
        print("error");
        loadProgress();
        break;
      case FacebookLoginStatus.loggedIn:

        print("Logged In");
        break;
    }
    return facebookLoginResult;
  }


  signupWith()async{
    loadProgress();
    FacebookLoginResult facebookLoginResult = await _handleFBSignIn();
    final accessToken = facebookLoginResult.accessToken.token;
    print(" sdsds"+ accessToken.toString());
    if (facebookLoginResult.status == FacebookLoginStatus.loggedIn) {
      final facebookAuthCred =
      FacebookAuthProvider.getCredential(accessToken: accessToken);
      final user =      await _auth.signInWithCredential(facebookAuthCred);
      print("User : " + user.additionalUserInfo.toString());


      bool trustSelfSigned = true;
      HttpClient httpClient = new HttpClient()
        ..badCertificateCallback =
        ((X509Certificate cert, String host, int port) => trustSelfSigned);
      IOClient ioClient = new IOClient(httpClient);


      final graphResponse = await ioClient.get(
          'https://graph.facebook.com/v2.12/me?fields=name,first_name,last_name,email,picture &access_token=${accessToken}');

      final data = json.decode(graphResponse.body);



      String name = data["name"].toString();
      String first_name = data["first_name"].toString();
      String last_name = data["last_name"].toString();
      String email = data["email"].toString();
      String id = data["id"].toString();
      final picData = data["picture"];
      String url = picData["data"]["url"].toString();
      print(url.toString());

      facebookServerSideSignUp(id,email,name,first_name,last_name,url);


    }
  }

  facebookServerSideSignUp(String id,String email,String username,String firstname,String lastname,String imageUrl) async
  {
    String device = "";

    if (Platform.isAndroid) {

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";

    }

    final uri = API.socialsignin;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "loginType": "facebook",
      "facebookId":id,
      "email":email,
      "imgUrl": imageUrl,
      "firstName":firstname,
      "lastName": lastname,
      "device_type": device,
      "device_token": fcmToken
    };

    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    loadProgress();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        showDisplayAllert(context:context,isSucces: true,message:data["message"]);
        String id = data["data"]["data"]["id"].toString();
        String user_type = data["data"]["data"]["user_type"].toString();
        String reg_type = data["data"]["data"]["reg_type"].toString();
        String google_id = data["data"]["data"]["google_id"].toString();
        String facebook_id = data["data"]["data"]["facebook_id"].toString();
        String user_name = data["data"]["data"]["user_name"].toString();
        String first_name = data["data"]["data"]["first_name"].toString();
        String  last_name = data["data"]["data"]["last_name"].toString();
        String gender = data["data"]["data"]["gender"].toString();
        String email = data["data"]["data"]["email"].toString();
        String google_email = data["data"]["data"]["google_email"].toString();
        String  facebook_email = data["data"]["data"]["facebook_email"].toString();
        String  email_varified = data["data"]["data"]["email_varified"].toString();
        String   image = data["data"]["data"]["image"].toString();
        String  google_image = data["data"]["data"]["google_image"].toString();
        String  facebook_image = data["data"]["data"]["facebook_image"].toString();
        String   driving_id = data["data"]["data"]["driving_id"].toString();
        String   drive_frontimage = data["data"]["data"]["drive_frontimage"].toString();
        String   drive_backimage = data["data"]["data"]["drive_backimage"].toString();
        String   drive_image_verification = data["data"]["data"]["drive_image_verification"].toString();
        String  driving_cancle_cause = data["data"]["data"]["driving_cancle_cause"].toString();

        String  driving_exp = data["data"]["data"]["driving_exp"].toString();
        String  phone_code = data["data"]["data"]["phone_code"].toString();
        String   phone = data["data"]["data"]["phone"].toString();
        String   phone_verification = data["data"]["data"]["phone_verification"].toString();
        String   birth_year = data["data"]["data"]["birth_year"].toString();
        String  bio = data["data"]["data"]["bio"].toString();
        String  identity_document_verified = data["data"]["data"]["identity_document_verified"].toString();
        String  profile_image_status = data["data"]["data"]["profile_image_status"].toString();
        String  status = data["data"]["data"]["status"].toString();
        String  device_type = data["data"]["data"]["device_type"].toString();
        String  device_token = data["data"]["data"]["device_token"].toString();
        String  added_date = data["data"]["data"]["added_date"].toString();
        String  update_date = data["data"]["data"]["update_date"].toString();

        String  rating = data["rating"]["avg_rating"]["avg_rating"].toString();
        List list = data["rating"]["rating_master"];
        print(id);


        ShareMananer.setLoginDetails(id, user_type, reg_type, google_id, facebook_id, user_name, first_name,last_name, gender,
            email, google_email, facebook_email, email_varified, image, google_image, facebook_image, driving_id,
            drive_frontimage, drive_backimage, drive_image_verification, driving_cancle_cause, driving_exp,
            phone_code, phone, phone_verification, birth_year, bio, identity_document_verified, profile_image_status,
            status, device_type, device_token, added_date, update_date, rating,list.length.toString(),true);

        Firestore.instance.collection('users').document(id).setData(
            {
              'name': first_name+" "+last_name,
              'email': email,
              'id': id,
              "fcm": fcmToken,
              "isOnline": true,
              "profileImg": API.baseProfileImageUrl+image,
              "lastMessage": ""
            });


        Future.delayed(Duration(seconds: 1), () {
          AppRoutes.makeFirst(context,HomeScreen());


        });


      } else {


        String dataString = data["message"].toString();
        // dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {

      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  void _toggleLogin() {
    setState(() {

      _obscureTextLogin = !_obscureTextLogin;
    });
  }
}
