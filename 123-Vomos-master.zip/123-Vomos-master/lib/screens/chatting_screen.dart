import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fcm_push/fcm_push.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:intl/intl.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/booking_request_wiget.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/chating_wiget.dart';
import 'package:vamos/components/completed_trips_wiget.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/components/messages_wiget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:vamos/model/device_token_model.dart';

class ChattingScreen extends StatefulWidget {
  String chatUserId, fcmToken,mainUserID,mainUserName,chatUserName,mainUserProfile;

  ChattingScreen({@required this.chatUserId, @required this.fcmToken,@required this.mainUserID,@required this.mainUserName,@required this.chatUserName,@required this.mainUserProfile});

  @override
  State<StatefulWidget> createState() => new _ChattingScreen();
}



class _ChattingScreen extends State<ChattingScreen> {
  var listMessage;
  List<DeviceTokenModel> listDevice =new List<DeviceTokenModel>();
  final ScrollController listScrollController = new ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController sendMessageController = new TextEditingController();

  FirebaseAuth _auth = FirebaseAuth.instance;



  @override
  void initState() {
    print(widget.mainUserID);
    print(widget.chatUserName);
    getFcmTokenList();
  }

  getFcmTokenList() async {

    final uri = API.getDeviceTokenID;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": widget.chatUserId,
    };
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(body.toString());
    print(response.body);

   // loadProgress();
    if (statusCode == 200) {
      if (data["status"] == "true") {

        final List listData = data["data"]["devices"];

        for(int i =0;i<listData.length;i++)
          {
            String id=listData[i]["id"].toString();
            String user_id=listData[i]["user_id"].toString();
            String device_type=listData[i]["device_type"].toString();
            String device_token=listData[i]["device_token"].toString();


            listDevice.add(new DeviceTokenModel(id,user_id,device_type,device_token));
          }


      } else {

        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
        showDisplayAllert(context:context,isSucces: false,message:dataString);
      }
    } else {
      showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: widget.chatUserName,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        color: Colors.white,
        width: double.maxFinite,
        child: Column(
          children: <Widget>[
            Flexible(
              child: StreamBuilder(
                // stream: Firestore.instance.collection('users').snapshots(),

                stream: Firestore.instance
                    .collection("message")
                    .document(widget.mainUserID)
                    .collection(widget.chatUserId)
                    .orderBy("timestamp", descending: true)
                    .snapshots(),


                builder: (context, snapshot) {



                  if (!snapshot.hasData) {
                    return Center(
                        child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                                AppTheme.primaryColor)));
                  } else {

                    return ListView.builder(
                      reverse: true,
                      controller: listScrollController,
                      padding: EdgeInsets.only(bottom: 10.0),
                      itemCount: snapshot.data.documents.length,
                      scrollDirection: Axis.vertical,
                      itemBuilder: (BuildContext context, int index) {

//                        Firestore.instance
//                            .collection('message')
//                            .document(  widget.mainUserID)
//                            .collection(widget.chatUserId).document(snapshot.data.documents[index]
//                        ["messageRef"]).updateData({"seen":true});

                        return Column(
                          children: <Widget>[
                            ChattingWidget(
                                isDateShow: index == 0 ? true : false,
                                AppUSerId:   widget.mainUserID,
                                chatUserId: snapshot.data.documents[index]
                                    ["from"],
                                dateTime: snapshot.data.documents[index]
                                    ["dateTime"],
                                message: snapshot.data.documents[index]
                                    ["message"]),
                          ],
                        );
                      },
                    );
                  }
                },
              ),
            ),
            buildInput()
          ],
        ),
      ),
    );
  }

  sendMessage() async {

    String messge = sendMessageController.text;
    sendMessageController.text="";

    var date = new DateTime.now().millisecondsSinceEpoch;

    DateTime timeStamp = DateTime.fromMillisecondsSinceEpoch(date);

    String dateFormate = DateFormat("dd-MM-yy hh:mm a")
        .format(DateTime.parse(timeStamp.toString()));

    DocumentReference docRef = await  Firestore.instance
        .collection('message')
        .document(  widget.mainUserID)
        .collection(widget.chatUserId)
        .add({
      'to': widget.chatUserId,
      'from':   widget.mainUserID,
      'message': messge,
      "timestamp": date,
      "dateTime": dateFormate,
      "seen": true,
      "messageRef":""
    });

    Firestore.instance
        .collection('message')
        .document(  widget.mainUserID)
        .collection(widget.chatUserId).document(docRef.documentID).updateData({"messageRef":docRef.documentID});


     Firestore.instance
        .collection('message')
        .document(widget.chatUserId)
        .collection(  widget.mainUserID)
        .add({
      'to': widget.chatUserId,
      'from':   widget.mainUserID,
      'message': messge,
      "timestamp": date,
      "dateTime": dateFormate,
      "seen": false,
      "messageRef":""
    });


    QuerySnapshot querySnapshot = await Firestore.instance.collection("users").where("id" ,isEqualTo: widget.chatUserId).getDocuments();
    var list = querySnapshot.documents;

    String  name,lastMessage,profileImage;
    for(int i=0;i<list.length;i++)
      {
        print("dssssssssssssssssssssssssssssssssssssssssss");
        name = list[i]["name"].toString();
        profileImage = list[i]["profileImg"].toString();

      }





    Firestore.instance.collection('usersChat').document("${widget.mainUserID}With${widget.chatUserId}").setData(
        {
          'id':widget.mainUserID,
          'name':name,
          'to': widget.chatUserId,
          "from": widget.mainUserID,
          "profileImg": profileImage,
          "lastMessage": messge,
          "timestamp": date,
          "dateTime": dateFormate,
        });


    Firestore.instance.collection('usersChat').document("${widget.chatUserId}With${widget.mainUserID}").setData(
        {
          'id':widget.chatUserId,
          'name': widget.mainUserName,
          'from': widget.chatUserId,
          "to": widget.mainUserID,
          "profileImg": widget.mainUserProfile,
          "lastMessage": messge,
          "timestamp": date,
          "dateTime": dateFormate,
        });





//    Firestore.instance
//        .collection('message')
//        .document(widget.chatUserId)
//        .collection(  widget.mainUserID).document(def2.documentID).updateData({"messageRef":def2.documentID});

    final FCM fcm = new FCM(API.fcmServer);


    for(int i=0;i<listDevice.length;i++){
      final Message fcmMessage = new Message()
        ..to = listDevice[i].device_token
        ..title = widget.mainUserName
        ..body = messge;

      fcm.send(fcmMessage);


    }

//    print("00000 "+listDevice[0].device_token);
//    final Message fcmMessage = new Message()
//      ..to = widget.fcmToken
//      ..title = widget.mainUserName
//      ..body = sendMessageController.text;
//
//    final String messageID = await fcm.send(fcmMessage);

    //sendMessageController.text = "";
    listScrollController.animateTo(0.0,
        duration: Duration(milliseconds: 300), curve: Curves.easeOut);

    //   Firestore.instance.collection("users").document(mainUserID).updateData({'isOnline':false});
  }

  Widget buildInput() {
    return Container(
      child: Row(
        children: <Widget>[
          // Button send image

          // Edit text
          Flexible(
            child: Container(
              margin: EdgeInsets.only(left: 5.0),
              child: TextField(
                maxLines: 7,
                minLines: 1,
                style: TextStyle(color: AppTheme.primaryColor, fontSize: 15.0),
                controller: sendMessageController,
                decoration: InputDecoration.collapsed(
                  hintText: 'Type your message...',
                  hintStyle: TextStyle(color: Colors.grey),
                ),
              ),
            ),
          ),

          // Button send message
          Material(
            child: new Container(
              margin: new EdgeInsets.symmetric(horizontal: 8.0),
              child: new IconButton(
                icon: new Icon(Icons.send),
                onPressed: (){

                  if(sendMessageController.text!="") {
                    sendMessage();
                  }
                },
                color: AppTheme.primaryColor,
              ),
            ),
            color: Colors.white,
          ),
        ],
      ),
      width: double.infinity,
      // height: 50.0,
      decoration: new BoxDecoration(
          border:
              new Border(top: new BorderSide(color: Colors.grey, width: 0.5)),
          color: Colors.white),
    );
  }
}
