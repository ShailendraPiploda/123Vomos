
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/size_config.dart';

class BookingPaymentScreen extends StatefulWidget{
  String final_price,price,total_seat,redirectUrl,msg,booking_process,referenceCode,signature,referencia,flag,uuid,prueba;


  BookingPaymentScreen(this.final_price, this.price, this.total_seat,
      this.redirectUrl, this.msg, this.booking_process, this.referenceCode,
      this.signature, this.referencia, this.flag, this.uuid, this.prueba);

  @override
   _BookingPaymentScreen createState() => new _BookingPaymentScreen();

}

class _BookingPaymentScreen extends State<BookingPaymentScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final flutterWebviewPlugin = new FlutterWebviewPlugin();
  String userIdMain="";
  String urlPayment  ="https://www.123-vamos.com/";

  paymentGenrateUrl() async {

    final uri ="https://www.pagoagil.net/onestep";
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/json',
    };






    Map<String, dynamic> body = {
      "uuid": widget.uuid,
      "tipo": "onestep",
      "referencia": widget.referencia,
      "referencia_producto": '',
      "moneda": "COP",
      "iva": "",
      "base": "",
      "otros_valores": "0",
      "url_ipn":  API.baseUrl+"/book/pagoagilipn",
      "url_respuesta": API.baseUrl+"/book/pagoagilresponse",
      "idioma": "es",
      "tipo_documento": "",
      "documento": "",
      "pais": "CO",
      "medio_pago": "",
      "prueba": widget.prueba,
      "descripcion_producto": "viaje(s)",
      "monto": widget.final_price,
      "correo": "",
      "direccion": "",
      "cantidad_producto": widget.total_seat,
      "nombres": "",
      "apellidos": "",
      "telefono": "",
      "celular": "",
      "ciudad": "",
      "provincia": "",

    };







    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');

    print(body.toString());
    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: jsonBody,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
 //   final data = json.decode(response.body);

    print(body.toString());
    print(response.body);
    print(statusCode);


    flutterWebviewPlugin.launch(response.body);
    String selectedUrl = json.decode(response.body)["payment_request"]['longurl'].toString() +"?embed=form";
    print(selectedUrl);
    setState(() {

    });

   // progressLoad();
    if (statusCode == 200) {

    } else {
    //  showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }

  }

  @override
  void initState() {



    ShareMananer.getUserDetails().then((data) {
      userIdMain = data["id"];
      print(userIdMain);

    });
    flutterWebviewPlugin.onUrlChanged.listen((String url) {
      print(url);



      if (url.contains('https://www.123-vamos.com'))
        {
          print("mainUrl :"+url);
          Uri uri = Uri.parse(url);
          String codigo_retorno = uri.queryParameters['codigo_retorno'];
          String codigo_respuesta = uri.queryParameters['codigo_respuesta'];
          String referencia = uri.queryParameters['referencia'];
          print("mainUrl :"+codigo_retorno);
          print("mainUrl :"+codigo_respuesta);
          print("mainUrl :"+referencia);
          AppRoutes.dismiss(context);
        }


    });
  }

  String getQueryString(Map params, {String prefix: '&', bool inRecursion: false}) {

    String query = '';

    params.forEach((key, value) {

      if (inRecursion) {
        key = '[$key]';
      }

      if (value is String || value is int || value is double || value is bool) {
        query += '$prefix$key=$value';
      } else if (value is List || value is Map) {
        if (value is List) value = value.asMap();
        value.forEach((k, v) {
          query += getQueryString({k: v}, prefix: '$prefix$key', inRecursion: true);
        });
      }
    });

    return query;
  }


  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> body = {
      "uuid": widget.uuid,
      "tipo": "onestep",
      "referencia": widget.referencia,
      "referencia_producto": '',
      "moneda": "COP",
      "iva": "",
      "base": "",
      "otros_valores": "0",
      "url_ipn":  API.baseUrl+"/book/pagoagilipn",
      "url_respuesta": API.baseUrl+"/book/pagoagilresponse",
      "idioma": "es",
      "tipo_documento": "",
      "documento": "",
      "pais": "CO",
      "medio_pago": "",
      "prueba": widget.prueba,
      "descripcion_producto": "viaje(s)",
      "monto": widget.final_price,
      "correo": "",
      "direccion": "",
      "cantidad_producto": widget.total_seat,
      "nombres": "",
      "apellidos": "",
      "telefono": "",
      "celular": "",
      "ciudad": "",
      "provincia": "",

    };

    Map<String, dynamic> body2 = {
      "public-key": "pub_test_Q5yDA9xoKdePzhSGeVe9HAez7HgGORGf",
      "currency": "COP",
      "amount-in-cents": "4950000",
      "reference": "sJK4489dDjkd390ds02",
      "redirect-url": API.baseUrl,


    };


    String query = getQueryString(body2);
    print("fgfhfghfghfgh "+query);

    // TODO: implement build

    return   WebviewScaffold(
      url:"https://sandbox.wompi.co/v1?"+query,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.payment,
        ),
      ),
      withZoom: true,
      withJavascript: true,
      allowFileURLs: true,
      appCacheEnabled: true,
      mediaPlaybackRequiresUserGesture: true,
      withOverviewMode: true,
      withLocalStorage: true,
      hidden: true,
      initialChild: Container(
        color: Colors.white,
        child: const Center(
          child: Text('Waiting.....'),
        ),
      ),
    );


  }


}