import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/io_client.dart';
import 'package:http/http.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:device_info/device_info.dart';
class ForgotPassword extends StatefulWidget{

   @override
   _ForgotPassword createState() => new _ForgotPassword();

}

class _ForgotPassword extends State<ForgotPassword> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController emailController = new TextEditingController();
  String userIdMain="";
  bool isLoding=false;
  var _formKey = GlobalKey<FormState>();

  void showInSnackBar(String value) {
    FocusScope.of(context).requestFocus(new FocusNode());
    _scaffoldKey.currentState?.removeCurrentSnackBar();
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.white,
            fontSize: 16.0,
            fontFamily: "WorkSansSemiBold"),
      ),
      backgroundColor: Colors.blue,
      duration: Duration(seconds: 3),
    ));
  }


  submitForgatePasswordDetails() async {
    String device = "",deviceID="";

    if (Platform.isAndroid) {
      var androidInfo = await DeviceInfoPlugin().androidInfo;
      deviceID= androidInfo.androidId.toString();

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";
      var androidInfo = await DeviceInfoPlugin().iosInfo;
      deviceID= androidInfo.identifierForVendor.toString();
    }
    final uri = API.forgotPassword;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "email": emailController.text.toString(),
      "device_type": device,
      "device_token": deviceID
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');

    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(jsonBody);
    print(response.body);

    loadProgress();
    print(statusCode);
    if (statusCode == 200) {

      if (data["status"]=="true") {
        print(statusCode);
        showDisplayAllert(context:context,isSucces: true,message: (data["message"]));


      } else {
        String dataString = data["message"].toString();
      //  dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");

        showDisplayAllert(context:context,isSucces: false,message: dataString);

            }
    } else {
         showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

    }
  }



  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(
      resizeToAvoidBottomInset: false,
      key: _scaffoldKey,
    //  resizeToAvoidBottomInset: false,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.forgotPassword,
        ),
      ),
        bottomNavigationBar: BottomDrawerWidgget(),
      body: Container(
        width: double.maxFinite,
        decoration: new BoxDecoration(
            image: DecorationImage(
                image: ExactAssetImage(Assets.background),
                fit: BoxFit.cover
            )
        ),
        child:Form(
          key: _formKey,
          child:  Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                SizedBox(height: AppSize.mediumLarge),
                Container(
                  padding: EdgeInsets.all(20),
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(125),
                  ),
                  child: Image(
                      width: 100.0,
                      height: 100.0,
                      fit: BoxFit.contain,
                      image: new AssetImage(Assets.app_logo)
                  ),
                ),
                SizedBox(height:AppSize.mediumLarge,),
                Center(
                  child: Card(
                    elevation: 2.0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Container(
                      padding: EdgeInsets.only(top: AppSize.small),
                      child: Container(
                        color: Colors.transparent,
                        width: SizeConfig.widthMultiplier*80,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[

                            Container(
                              width: double.maxFinite,
                              padding: EdgeInsets.only(
                                  left:6.0*SizeConfig.widthMultiplier,
                                  right:6.0*SizeConfig.widthMultiplier),


                              child: TextFormField(
                                validator: (String value) {

                                  return FieldValidator.validateEmail(value);
                                },
                                controller: emailController,
                                keyboardType: TextInputType.emailAddress,
                                style: TextStyle(
                                    fontFamily: "WorkSansSemiBold",
                                    fontSize: 16.0,
                                    color: Colors.black),
                                decoration: InputDecoration(
                                  labelText: Constants.enterEmail,
                                  labelStyle: TextStyle(color: Colors.grey,fontSize: AppFontSize.textHint),
                                  border: InputBorder.none,
                                  icon: Icon(
                                    FontAwesomeIcons.envelope,
                                    color: Colors.black,
                                    size:AppFontSize.textIcon,
                                  ),

                                ),
                              ),
                            ),

                            Container(
                              margin: EdgeInsets.only(
                                bottom:5*SizeConfig.heightMultiplier,
                                  left:6.0*SizeConfig.widthMultiplier,
                                  right:6.0*SizeConfig.widthMultiplier),
                              width: double.maxFinite,
                              height: 1.0,
                              color: Colors.grey[400],
                            ),


                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height:AppSize.mediumLarge,),
                !isLoding?Container(
                  width: SizeConfig.widthMultiplier*80,
                  child: CustomRoundButtonWidget(
                    buttonWidth: SizeConfig.widthMultiplier*80,
                    title: Constants.forgotPassword,
                    callback:() async {
                                if(_formKey.currentState.validate()){
                                  loadProgress();
                                submitForgatePasswordDetails();
                                }

                    } ,
                  ),
                ):Container(child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),),
                    )
              ]
          ),
        ),
      )
    );


  }

  void loadProgress(){
    setState(() {

      print(isLoding);
      isLoding =!isLoding;
    });

  }

}