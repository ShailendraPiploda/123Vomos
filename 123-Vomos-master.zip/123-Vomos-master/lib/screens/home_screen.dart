import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_border_button.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/round_border_button.dart';
import 'package:vamos/components/round_white_border_button.dart';
import 'package:vamos/components/side_drawer_widget.dart';
import 'package:vamos/screens/post_a_trips_screen.dart';
import 'package:vamos/screens/search_trips_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class HomeScreen extends StatefulWidget{

  State<HomeScreen> createState()=> _HomeScreen();
}

class _HomeScreen extends State<HomeScreen>{
  final GlobalKey<ScaffoldState> _scaffoldKey =
  new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: false,
      resizeToAvoidBottomPadding: false,
      appBar: PreferredSize(preferredSize: Size.fromHeight(AppSize.xxL),
      child: CustomAppBarWidget(
        title: Constants.homeScreenTitle,
        callMenu: (){
          _scaffoldKey.currentState.openDrawer();
        },
      ),),
      bottomNavigationBar: BottomDrawerWidgget(isGoBack: true,),
      drawer: SideDrawerWidget(),
      body: Container(
        decoration: BoxDecoration(
          color: Colors.white,
            image: DecorationImage(

               colorFilter: new ColorFilter.mode(Colors.black.withOpacity(0.5), BlendMode.dstATop),
                image: ExactAssetImage(Assets.banner),
                fit: BoxFit.cover
            )
        ),
        width: double.maxFinite,
        child: Column(

          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[

            SizedBox(height: AppSize.xxL,),

          Container(
            alignment: Alignment.center,
            width: screenSize.width*.70,
            child: Image.asset(Assets.app_logo)  ),

          SizedBox(height: AppSize.mediumLarge,),

          Container(
            alignment: Alignment.center,
            width: screenSize.width*.90,
            child: Text(Constants.appDialog,textAlign: TextAlign.center,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s22)),

          ),
          SizedBox(height: AppSize.xxL,),

          Container(
            width: screenSize.width*.70,
            child: RoundBorderButtonWidget(
              buttonWidth: screenSize.width*.70,
              title: Constants.searchForTrip,
              callback: (){
                AppRoutes.goto(context, SearchTripsScreen());
              },
            ),
          ),
          SizedBox(height: AppSize.large,),
          Container(
            width: screenSize.width*.70,
            child: RoundWhiteBorderButtonWidget(
              buttonWidth: screenSize.width*.70,
              title: Constants.postATrip,
              callback: (){
                AppRoutes.goto(context, PostATripScreen());
              },
            ),
          ),





        ],),
      ),
    );
  }

}