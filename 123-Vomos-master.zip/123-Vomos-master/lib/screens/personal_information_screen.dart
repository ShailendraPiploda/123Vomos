import 'dart:convert';
import 'dart:io';

import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/bottom_drawer_widet.dart';
import 'package:vamos/components/custom_app_bar_widget.dart';
import 'package:vamos/components/custom_round_button.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/model/phone_code_model.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';
import 'package:device_info/device_info.dart';
import 'package:http/http.dart' as http;
import 'home_screen.dart';
import 'package:path/path.dart';
import 'package:async/async.dart';

class PersonalInformationScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _PersonalInformationScreen();
}

class _PersonalInformationScreen extends State<PersonalInformationScreen> {
  File _profileImage=null;
  bool isLoding=false;
  String base64Image="";
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController emailController = new TextEditingController();
  TextEditingController firstNameController = new TextEditingController();
  TextEditingController lastNameController = new TextEditingController();
  TextEditingController phoneCodeController = new TextEditingController();
  TextEditingController phoneController =
      new TextEditingController();
  TextEditingController _infoDobController = new TextEditingController();
  TextEditingController bioController = new TextEditingController();

  List<PhoneCodeModel>phoneList = new List();
  bool _obscureTextLogin = true;
  var _loginFormKey = GlobalKey<FormState>();
  String _groupValue = "2";

  String first_name = "",
      last_name = "",
      email = "",
      phoneCode = "",
      id = "",
      user_type = "",
      reg_type = "",
      google_id = "",
      facebook_id = "",
      user_name = "",
      gender = "",
      google_email = "",
      facebook_email = "",
      email_varified = "",
      image = "",
      google_image = "",
      facebook_image = "",
      driving_id = "",
      drive_frontimage = "",
      drive_backimage = "",
      drive_image_verification = "",
      driving_cancle_cause = "",
      driving_exp = "",
      phone_code = "",
      phone = "",
      phone_verification = "",
      birth_year = "",
      bio = "",
      identity_document_verified = "",
      profile_image_status = "",
      status = "",
      device_type = "",
      device_token = "",
      added_date = "",
      update_date;


  getPhoneCode() async {
    final uri = API.getPhoneCode;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };



    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    http.Response response = await ioClient.get(
        uri,
        headers: headers,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    loadProgress();

    if (statusCode == 200) {
      if (data["status"] == "true") {

        List countrylist = data["data"]["Country"];

       for(int i=0;i<countrylist.length;i++)
         {
           String name=countrylist[i]["name"].toString();
           String iso=countrylist[i]["iso"].toString();
           String phonecode=countrylist[i]["phonecode"].toString();
           
           phoneList.add(new PhoneCodeModel(phonecode, iso, name));

         }


    } else {
      showDisplayAllert(
          context: this.context, isSucces: false, message: data["message"]);
    }
  }
  }

  submitProfileDetailsWithImage() async {
    String device = "",deviceID="";

    if (Platform.isAndroid) {
      var androidInfo = await DeviceInfoPlugin().androidInfo;
      deviceID= androidInfo.androidId.toString();

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";
      var androidInfo = await DeviceInfoPlugin().iosInfo;
      deviceID= androidInfo.identifierForVendor.toString();
    }


    var uri = Uri.parse(API.profileUpdate);
    var stream = new http.ByteStream(DelegatingStream.typed(_profileImage.openRead()));
    var length = await _profileImage.length();

    MultipartFile multipartFile = new MultipartFile('userimage', stream, length,filename:basename(_profileImage.path));

    var request = new MultipartRequest("POST",uri );
    request.files.add(multipartFile);
    request.fields["user_id"]=id;
    request.fields["first_name"]=firstNameController.text.toString();
    request.fields["last_name"]=lastNameController.text.toString();
    request.fields["email"]=emailController.text.toString();
    request.fields["phone_code"]=phoneCodeController.text.toString();
    request.fields["phone"]=phoneController.text.toString();
    request.fields["birth_year"]=_infoDobController.text.toString();
    request.fields["gender"]=_groupValue;
    request.fields["bio"]=bioController.text.toString();
   // request.fields["userimage"]=this.multipartFile;
    request.fields["device_type"]=device;
    request.fields["device_token"]=deviceID;

    request.headers[HttpHeaders.contentTypeHeader] = 'multipart/form-data;charset=utf-8';
    request.send().then((response)async  {


      if (response.statusCode == 200) {

        print("Uploaded!");

        final data = json.decode(await response.stream.bytesToString());
        print(data.toString());

      if (data["status"] == "true") {
        loadProgress();
        showDisplayAllert(context:this.context,isSucces: true,message: (data["message"]));

        String id = data["data"]["id"].toString();
        String user_type = data["data"]["user_type"].toString();
        String reg_type = data["data"]["reg_type"].toString();
        String google_id = data["data"]["google_id"].toString();
        String facebook_id = data["data"]["facebook_id"].toString();
        String user_name = data["data"]["user_name"].toString();
        String first_name = data["data"]["first_name"].toString();
        String  last_name = data["data"]["last_name"].toString();
        String gender = data["data"]["gender"].toString();
        String email = data["data"]["email"].toString();
        String google_email = data["data"]["google_email"].toString();
        String  facebook_email = data["data"]["facebook_email"].toString();
        String  email_varified = data["data"]["email_varified"].toString();
        String   image = data["data"]["image"].toString();
        String  google_image = data["data"]["google_image"].toString();
        String  facebook_image = data["data"]["facebook_image"].toString();
        String   driving_id = data["data"]["driving_id"].toString();
        String   drive_frontimage = data["data"]["drive_frontimage"].toString();
        String   drive_backimage = data["data"]["drive_backimage"].toString();
        String   drive_image_verification = data["data"]["drive_image_verification"].toString();
        String  driving_cancle_cause = data["data"]["driving_cancle_cause"].toString();

        String  driving_exp = data["data"]["driving_exp"].toString();
        String  phone_code = data["data"]["phone_code"].toString();
        String   phone = data["data"]["phone"].toString();
        String   phone_verification = data["data"]["phone_verification"].toString();
        String   birth_year = data["data"]["birth_year"].toString();
        String  bio = data["data"]["bio"].toString();
        String  identity_document_verified = data["data"]["identity_document_verified"].toString();
        String  profile_image_status = data["data"]["profile_image_status"].toString();
        String  status = data["data"]["status"].toString();
        String  device_type = data["data"]["device_type"].toString();
        String  device_token = data["data"]["device_token"].toString();
        String  added_date = data["data"]["added_date"].toString();
        String  update_date = data["data"]["update_date"].toString();
        String  rating = data["rating"]["avg_rating"]["avg_rating"].toString();
        List list = data["rating"]["rating_master"];

//        String  rating = "0";
//        String list = "0";




        Firestore.instance.collection("users").document(id).
        updateData({'profileImg':API.baseProfileImageUrl+image});






        ShareMananer.setLoginDetails(id, user_type, reg_type, google_id, facebook_id, user_name, first_name,last_name, gender,
            email, google_email, facebook_email, email_varified, image, google_image, facebook_image, driving_id,
            drive_frontimage, drive_backimage, drive_image_verification, driving_cancle_cause, driving_exp,
            phone_code, phone, phone_verification, birth_year, bio, identity_document_verified, profile_image_status,
            status, device_type, device_token, added_date, update_date, rating,list.length.toString(),true);

        Future.delayed(Duration(seconds: 2), () {
          print("sdasdas000");
          AppRoutes.dismiss(this.context);


        });


      } else {
        loadProgress();
        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");

        showDisplayAllert(context:this.context,isSucces: false,message: dataString);
      }
    } else {
      loadProgress();
      showDisplayAllert(context:this.context,isSucces: false,message: response.reasonPhrase);

    }

    });

  }

  submitProfileDetails() async {
    String device = "",deviceID="";

    if (Platform.isAndroid) {
      var androidInfo = await DeviceInfoPlugin().androidInfo;
      deviceID= androidInfo.androidId.toString();

      device = "Android";
    } else if (Platform.isIOS) {
      device = "IOS";
      var androidInfo = await DeviceInfoPlugin().iosInfo;
      deviceID= androidInfo.identifierForVendor.toString();
    }
    final uri = API.profileUpdate;
    final headers = {
      HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
    };
    Map<String, dynamic> body = {
      "user_id": id,
      "first_name": firstNameController.text.toString(),
      "last_name": lastNameController.text.toString(),
      "email": emailController.text.toString(),
      "phone_code": phoneCodeController.text.toString(),
      "phone": phoneController.text.toString(),
      "birth_year": _infoDobController.text.toString(),
      "gender": _groupValue,
      "bio": bioController.text.toString(),
      "device_type": device,
      "device_token": deviceID
    };
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');


    bool trustSelfSigned = true;
    HttpClient httpClient = new HttpClient()
      ..badCertificateCallback =
      ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient);
    Response response = await ioClient.post(
      uri,
      headers: headers,
      body: body,
      encoding: encoding,
    );

    int statusCode = response.statusCode;
    final data = json.decode(response.body);

    print(jsonBody);
     print(response.body);


    if (statusCode == 200) {
      if (data["status"] == "true") {
        loadProgress();
        showDisplayAllert(context:this.context,isSucces: true,message: (data["message"]));

        String id = data["data"]["id"].toString();
        String user_type = data["data"]["user_type"].toString();
        String reg_type = data["data"]["reg_type"].toString();
        String google_id = data["data"]["google_id"].toString();
        String facebook_id = data["data"]["facebook_id"].toString();
        String user_name = data["data"]["user_name"].toString();
        String first_name = data["data"]["first_name"].toString();
        String  last_name = data["data"]["last_name"].toString();
        String gender = data["data"]["gender"].toString();
        String email = data["data"]["email"].toString();
        String google_email = data["data"]["google_email"].toString();
        String  facebook_email = data["data"]["facebook_email"].toString();
        String  email_varified = data["data"]["email_varified"].toString();
        String   image = data["data"]["image"].toString();
        String  google_image = data["data"]["google_image"].toString();
        String  facebook_image = data["data"]["facebook_image"].toString();
        String   driving_id = data["data"]["driving_id"].toString();
        String   drive_frontimage = data["data"]["drive_frontimage"].toString();
        String   drive_backimage = data["data"]["drive_backimage"].toString();
        String   drive_image_verification = data["data"]["drive_image_verification"].toString();
        String  driving_cancle_cause = data["data"]["driving_cancle_cause"].toString();

        String  driving_exp = data["data"]["driving_exp"].toString();
        String  phone_code = data["data"]["phone_code"].toString();
        String   phone = data["data"]["phone"].toString();
        String   phone_verification = data["data"]["phone_verification"].toString();
        String   birth_year = data["data"]["birth_year"].toString();
        String  bio = data["data"]["bio"].toString();
        String  identity_document_verified = data["data"]["identity_document_verified"].toString();
        String  profile_image_status = data["data"]["profile_image_status"].toString();
        String  status = data["data"]["status"].toString();
        String  device_type = data["data"]["device_type"].toString();
        String  device_token = data["data"]["device_token"].toString();
        String  added_date = data["data"]["added_date"].toString();
        String  update_date = data["data"]["update_date"].toString();

        String  rating = data["rating"]["avg_rating"]["avg_rating"].toString();
        List list = data["rating"]["rating_master"];



        ShareMananer.setLoginDetails(id, user_type, reg_type, google_id, facebook_id, user_name, first_name,last_name, gender,
            email, google_email, facebook_email, email_varified, image, google_image, facebook_image, driving_id,
            drive_frontimage, drive_backimage, drive_image_verification, driving_cancle_cause, driving_exp,
            phone_code, phone, phone_verification, birth_year, bio, identity_document_verified, profile_image_status,
            status, device_type, device_token, added_date, update_date, rating,list.length.toString(),true);

        Future.delayed(Duration(seconds: 2), () {
          print("sdasdas000");
          AppRoutes.dismiss(this.context);


        });


      } else {
        loadProgress();
        String dataString = data["message"].toString();
        dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");

        showDisplayAllert(context:this.context,isSucces: false,message: dataString);
      }
    } else {
      loadProgress();
      showDisplayAllert(context:this.context,isSucces: false,message: data["message"]);

    }

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(AppSize.xxL),
        child: CustomAppBarWidget(
          title: Constants.personalInformation,
        ),
      ),
      bottomNavigationBar: BottomDrawerWidgget(isGoBack: false,),
      body: Container(
        color: Colors.white,
        width: double.maxFinite,
        child:Stack(children: <Widget>[
          SingleChildScrollView(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: AppSize.medium,
                ),
                Form(
                  key: _loginFormKey,
                  child: Container(
                    margin: EdgeInsets.only(
                        left: SizeConfig.widthMultiplier,
                        right: SizeConfig.widthMultiplier),
                    width: double.maxFinite,
                    child: Column(
                      children: <Widget>[


                        Container(
                          child: GestureDetector(
                            onTap: (){
                              _showImagePicker(context);
                            },
                            child: Stack(children: <Widget>[
                              Material(
                                elevation: 4.0,
                                shape: CircleBorder(),
                                clipBehavior: Clip.hardEdge,
                                color: Colors.transparent,
                                child:image=="null" && facebook_image.isEmpty?Ink.image(
                                  image:  AssetImage(Assets.avtar),
                                  fit: BoxFit.cover,
                                  width: SizeConfig.widthMultiplier*35,
                                  height: SizeConfig.widthMultiplier*35,
                                  child: InkWell(
                                    onTap: () {},
                                  ),
                                ):Container(
                                  child: _profileImage ==null? FadeInImage.assetNetwork(placeholder: Assets.avtar,image:image=="null"?facebook_image: API.baseProfileImageUrl+image,fit: BoxFit.cover,): Image.file(_profileImage,fit: BoxFit.cover),

                                  width: SizeConfig.widthMultiplier*35,
                                  height: SizeConfig.widthMultiplier*35,

                                ),
                              ),
                              Positioned(
                                  right: 10.0,
                                  top: 5.0,
                                  child: GestureDetector(
                                      onTap: (){
                                        _showImagePicker(context);
                                      },
                                      child: Icon(Icons.camera,size: AppSize.mediumLarge,color: Colors.black54,))),
                            ],),
                          ),
                        ),
                        Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          child: TextFormField(
                            validator: (String value) {
                              return FieldValidator.validateEmptyCheck(value);
                            },
                            controller: firstNameController,
                            keyboardType: TextInputType.text,
                            textCapitalization: TextCapitalization.words,
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: 16.0,
                                color: Colors.black),
                            decoration: InputDecoration(
                              labelText: Constants.firstName,
                              labelStyle: TextStyle(
                                  color: Colors.grey,
                                  fontSize: AppFontSize.textHint),
                              border: InputBorder.none,
                              icon: Icon(FontAwesomeIcons.user,
                                  color: Colors.black,
                                  size: AppFontSize.textIcon),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            // top:0.5*SizeConfig.heightMultiplier,
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          width: double.maxFinite,
                          height: 1.0,
                          color: Colors.grey[400],
                        ),
                        Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          child: TextFormField(
                            validator: (String value) {
                              return FieldValidator.validateEmptyCheck(value);
                            },
                            controller: lastNameController,
                            keyboardType: TextInputType.text,
                            textCapitalization: TextCapitalization.words,
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: 16.0,
                                color: Colors.black),
                            decoration: InputDecoration(
                              labelText: Constants.lastName,
                              labelStyle: TextStyle(
                                  color: Colors.grey,
                                  fontSize: AppFontSize.textHint),
                              border: InputBorder.none,
                              icon: Icon(FontAwesomeIcons.user,
                                  color: Colors.black,
                                  size: AppFontSize.textIcon),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            // top:0.5*SizeConfig.heightMultiplier,
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          width: double.maxFinite,
                          height: 1.0,
                          color: Colors.grey[400],
                        ),
                        Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          child: TextFormField(
                            validator: (String value) {
                              return FieldValidator.validateEmail(value);
                            },
                            readOnly: true,
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: 16.0,
                                color: Colors.black),
                            decoration: InputDecoration(
                              labelText: Constants.enterEmail,
                              labelStyle: TextStyle(
                                  color: Colors.grey,
                                  fontSize: AppFontSize.textHint),
                              border: InputBorder.none,
                              icon: Icon(FontAwesomeIcons.envelope,
                                  color: Colors.black,
                                  size: AppFontSize.textIcon),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            // top:0.5*SizeConfig.heightMultiplier,
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          width: double.maxFinite,
                          height: 1.0,
                          color: Colors.grey[400],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[

                            Container(
                              width: SizeConfig.widthMultiplier*40,
                              child: Column(children: <Widget>[
                                Container(
                                  padding: EdgeInsets.only(
                                      left: 6.0 * SizeConfig.widthMultiplier,
                                      right: 6.0 * SizeConfig.widthMultiplier),
                                  width: SizeConfig.widthMultiplier * 40,
                                  child: TextFormField(
                                    controller: phoneCodeController,
                                    textAlign: TextAlign.start,
                                    validator: (String value) {
                                      return FieldValidator.validateEmptyCheck(value);
                                    },
                                    readOnly: true,
                                    onTap: (){
                                      showPhoneCode();
                                    },
                                    keyboardType: TextInputType.text,
                                    style: TextStyle(
                                        fontFamily: "WorkSansSemiBold",
                                        fontSize: 16.0,
                                        color: Colors.black),

                                    decoration: InputDecoration(
                                      icon: Icon(Icons.phone,
                                          color: Colors.black,
                                          size: AppFontSize.textIcon),
                                      labelText: Constants.phoneCode,
                                      labelStyle: TextStyle(
                                          color: Colors.grey,
                                          fontSize: AppFontSize.textHint),
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(
                                      top:0.5*SizeConfig.heightMultiplier,
                                      left: 6.0 * SizeConfig.widthMultiplier,
                                      right: 6.0 * SizeConfig.widthMultiplier
                                  ),
                                  width: double.maxFinite,
                                  height: 1.0,
                                  color: Colors.grey[400],
                                ),

                              ],),
                            ),

                            Container(
                              width: SizeConfig.widthMultiplier*50,
                              child: Column(children: <Widget>[
                                Container(
                                  padding: EdgeInsets.only(
                                      left: 1.0 * SizeConfig.widthMultiplier,
                                      right: 1.0 * SizeConfig.widthMultiplier),
                                  width: SizeConfig.widthMultiplier * 50,
                                  child: TextFormField(
                                    controller: phoneController,
                                    validator: (String value) {
                                      return FieldValidator.validateEmptyCheck(value);
                                    },
                                    keyboardType: TextInputType.phone,
                                    style: TextStyle(
                                        fontFamily: "WorkSansSemiBold",
                                        fontSize: 16.0,
                                        color: Colors.black),
                                    decoration: InputDecoration(
                                      labelText: Constants.enterPhone,
                                      labelStyle: TextStyle(
                                          color: Colors.grey,
                                          fontSize: AppFontSize.textHint),
                                      border: InputBorder.none,

                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(
                                    top:0.5*SizeConfig.heightMultiplier,
                                    // left: 6.0 * SizeConfig.widthMultiplier,
                                    // right: 6.0 * SizeConfig.widthMultiplier
                                  ),
                                  width: double.maxFinite,
                                  height: 1.0,
                                  color: Colors.grey[400],
                                ),
                              ],),
                            )


                          ],
                        ),



                        Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.only(
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          child: TextFormField(
                            controller: _infoDobController,
                            validator: (String value) {
                              return FieldValidator.validateEmptyCheck(value);
                            },
                            style: TextStyle(
                                fontFamily: "WorkSansSemiBold",
                                fontSize: 16.0,
                                color: Colors.black),
                            decoration: InputDecoration(
                              labelText: Constants.selectDob,
                              labelStyle: TextStyle(
                                  color: Colors.grey,
                                  fontSize: AppFontSize.textHint),
                              border: InputBorder.none,
                              icon: Icon(FontAwesomeIcons.calendar,
                                  color: Colors.black,
                                  size: AppFontSize.textIcon),
                            ),
                            readOnly: true,
                            onTap: () async {
                              DateTime date = DateTime(1900);
                              FocusScope.of(context)
                                  .requestFocus(new FocusNode());


                              date = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1800),
                                lastDate:  DateTime.now(),
                                builder: (BuildContext context, Widget child) {
                                  return Theme(
                                    data: ThemeData(
                                      primaryColor:
                                      AppTheme.colors.loginGradientStart,
                                      accentColor:
                                      AppTheme.colors.loginGradientStart,
                                      primaryColorDark:
                                      AppTheme.colors.loginGradientStart,
                                      primarySwatch: Colors.orange,
                                    ),
                                    child: child,
                                  );
                                },
                              );

                              if (date.toString() != "null") {
                                _infoDobController.text =
                                    date.toString().substring(0,date.toString().indexOf(" "));
                                print(DateTime.now());

                              }

                              print(_infoDobController.text);
                            },
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            // top:0.5*SizeConfig.heightMultiplier,
                              left: 6.0 * SizeConfig.widthMultiplier,
                              right: 6.0 * SizeConfig.widthMultiplier),
                          width: double.maxFinite,
                          height: 1.0,
                          color: Colors.grey[400],
                        ),
                        SizedBox(
                          height: AppSize.medium,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                                width: SizeConfig.widthMultiplier * 45,
                                child: Row(
                                  children: <Widget>[
                                    Radio(
                                      onChanged: (newValue) =>
                                          setState(() => _groupValue = newValue),
                                      value: "1",
                                      activeColor: AppTheme.accentColor,
                                      groupValue: _groupValue,
                                    ),
                                    Text(
                                      'Male',
                                      style: TextStyle(
                                          fontFamily: "WorkSansSemiBold",
                                          fontSize: 16.0,
                                          color: Colors.black),
                                    ),
                                  ],
                                )),
                            Container(
                                width: SizeConfig.widthMultiplier * 45,
                                child: Row(
                                  children: <Widget>[
                                    Radio(
                                      activeColor: AppTheme.accentColor,
                                      onChanged: (newValue) =>
                                          setState(() => _groupValue = newValue),
                                      value: "2",
                                      groupValue: _groupValue,
                                    ),
                                    Text(
                                      'Female',
                                      style: TextStyle(
                                          fontFamily: "WorkSansSemiBold",
                                          fontSize: 16.0,
                                          color: Colors.black),
                                    ),
                                  ],
                                )),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              top: 10.0, bottom: 10.0, left: 10.0, right: 10.0),
                          child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.only(
                                left: 6.0 * SizeConfig.widthMultiplier,
                                right: 6.0 * SizeConfig.widthMultiplier),

                            // padding: EdgeInsets.all(2.0),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border:
                                Border.all(width: 1.0, color: Colors.grey)),
                            child: TextFormField(
                              controller: bioController,
                              maxLines: 6,
                              validator: (String value) {
                                return FieldValidator.validateEmptyCheck(value);
                              },
                              keyboardType: TextInputType.text,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: Constants.persnoalInfo,
                                  hintStyle:
                                  TextStyle(fontSize: AppFontSize.textHint)),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: AppSize.large,
                        ),
                        CustomRoundButtonWidget(
                          title: Constants.update,
                          callback: () {
                            if(_loginFormKey.currentState.validate())
                            {
                              loadProgress();
                              if(_profileImage!=null)
                              {
                                submitProfileDetailsWithImage();
                              }
                              else{
                                submitProfileDetails();
                              }

                            }
                            //AppRoutes.replace(context, LoginScreen());
                          },
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: AppSize.medium,
                ),
              ],
            ),
          ),
          isLoding?Container(
              color: Colors.black.withOpacity(0.5),
              child: Center( child: CircularProgressIndicator(backgroundColor:AppTheme.accentColor,valueColor: new AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),))):
          SizedBox(width: 0.0,),
        ],)
      ),
    );
  }

  @override
  void initState() {
    loadProgress();
    getPhoneCode();

    ShareMananer.getUserDetails().then((data) {
      id =data["id"];
      user_type =data["nuser_typeame"];
      reg_type =data["reg_type"];
      google_id =data["google_id"];
      facebook_id =data["facebook_id"];
      user_name =data["user_name"];
      first_name =data["first_name"];
      last_name =data["last_name"];
      gender =data["gender"];
      email =data["email"];
      google_email =data["google_email"];
      facebook_email =data["facebook_email"];
      email_varified =data["email_varified"];
      image =data["image"];
      google_image =data["google_image"];
      facebook_image =data["facebook_image"];
      driving_id =data["driving_id"];
      drive_frontimage =data["drive_frontimage"];
      drive_backimage =data["drive_backimage"];
      drive_image_verification =data["drive_image_verification"];
      driving_cancle_cause =data["driving_cancle_cause"];
      driving_exp =data["driving_exp"];
      phone_code =data["phone_code"];
      phone =data["phone"];
      phone_verification =data["phone_verification"];
      birth_year =data["birth_year"];
      bio =data["bio"];
      identity_document_verified =data["identity_document_verified"];
      profile_image_status =data["profile_image_status"];
      status =data["status"];
      device_type =data["device_type"];
      device_token =data["device_token"];
      added_date =data["navme"];
      update_date =data["update_date"];



      firstNameController.text=first_name;
      lastNameController.text=last_name;
      phoneCodeController.text=phone_code;
      phoneController.text=phone=="null"?"":phone;
      _infoDobController.text=birth_year=="null"?"":birth_year;
      emailController.text=email;
      bioController.text=bio=="null"?"":bio;

      setState(() {
        _groupValue=gender;
      });


    });
  }


  void showPhoneCode() {
    showDialog(
        context: this.context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: phoneList.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        setState(() {
                          phoneCodeController.text = phoneList[index].phonecode.toString();
                          print(phoneCodeController.text);
                        });


                      //  print(index);
                        Navigator.pop(context);
                      },
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(phoneList[index].name+"( "+phoneList[index].phonecode+" )",
                                      style: TextStyle(fontSize: 18.0)),
                                )
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Container(
                                  height: 1.0,
                                  color: Colors.grey[400],
                                )),
                          ],
                        ),
                      ));
                },
              ),
            ),
          );
        });
  }


  _openGallery(BuildContext context) async{

    var picture =await ImagePicker.pickImage(source: ImageSource.gallery,imageQuality: 10);
    
    setState(() {
      _profileImage=picture;
      base64Image=base64Encode(picture.readAsBytesSync());
    });
    Navigator.of(context).pop();
  }

  _openCamera(BuildContext context)async{


    var picture =await ImagePicker.pickImage(source: ImageSource.camera,imageQuality: 10);

    setState(() {
      _profileImage=picture;
    });
    Navigator.of(context).pop();
  }

  Future<bool>_showImagePicker(BuildContext context)
  {
    return showDialog(context: context,
    builder: (BuildContext context){
      return AlertDialog(
        title: Text("Make Your Choice"),
        content: SingleChildScrollView(
          child: ListBody(children: <Widget>[
            GestureDetector(
              onTap: (){
                _openGallery(context);
              },
              child: Text("Gallery"),
            ),
            SizedBox(height: AppSize.medium,)
            ,

            GestureDetector(
              onTap:(){
                _openCamera(context);
              },
              child: Text("Camera"),
            ),
          ],),
        ),
      );
    });
  }

  void loadProgress(){
    setState(() {
      isLoding =!isLoding;
    });

  }

  void _toggleLogin() {
    setState(() {
      _obscureTextLogin = !_obscureTextLogin;
    });
  }
}
