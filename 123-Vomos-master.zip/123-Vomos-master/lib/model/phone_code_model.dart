class PhoneCodeModel {

  String phonecode,iso,name;

  PhoneCodeModel(this.phonecode, this.iso, this.name);

}