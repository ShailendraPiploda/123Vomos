class VechileModel{

  String id,brand_id,status,createAt,updateAt,model_no;

  VechileModel(this.id, this.brand_id, this.model_no,this.status, this.createAt,
      this.updateAt);


}