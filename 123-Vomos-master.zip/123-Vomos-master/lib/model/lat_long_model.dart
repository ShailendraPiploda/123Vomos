class LatLongModel{
  String locationName;
  double lat,long;

  LatLongModel(this.lat, this.long,this.locationName);


}