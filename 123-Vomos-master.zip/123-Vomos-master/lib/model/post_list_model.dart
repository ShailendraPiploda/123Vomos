class PostListModel{
  String id,trackId,user_id,title,description,start_time,end_time,starting_location,end_location,total_distance,
      increase_parcent,total_cost,total_cost_old,total_seat,seat_available,flexible,interval_time,booking_process
  ,status,added_date,updated_date;

  PostListModel(this.id, this.trackId, this.user_id, this.title,
      this.description, this.start_time, this.end_time, this.starting_location,
      this.end_location, this.total_distance, this.increase_parcent,
      this.total_cost, this.total_cost_old, this.total_seat,
      this.seat_available, this.flexible, this.interval_time,
      this.booking_process, this.status, this.added_date, this.updated_date);


}
