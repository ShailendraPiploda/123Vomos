class TripDetailLocationModel{
  String id,trackId,trip_id,location_a_name,location_a_lat,location_a_long,location_b_name,location_b_lat,location_b_long
  ,departure_datetime,arrival_datetime,halt_time,total_distance,actual_price,total_price,total_booked,duration;

  TripDetailLocationModel(this.id, this.trackId, this.trip_id,
      this.location_a_name, this.location_a_lat, this.location_a_long,
      this.location_b_name, this.location_b_lat, this.location_b_long,
      this.departure_datetime, this.arrival_datetime, this.halt_time,
      this.total_distance, this.actual_price, this.total_price,
      this.total_booked, this.duration);


}