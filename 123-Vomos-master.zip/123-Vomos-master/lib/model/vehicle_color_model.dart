class VechileColorModel{

  String id,color_name_es,color_name_en,color_code,status,created_at,updated_at;

  VechileColorModel(this.id,this.status, this.created_at,
      this.updated_at,this.color_code,this.color_name_en,this.color_name_es);


}