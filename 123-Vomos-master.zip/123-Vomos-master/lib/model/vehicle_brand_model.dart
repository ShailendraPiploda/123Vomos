class VechileBrandModel{

  String id,brand,status,createAt,updateAt;

  VechileBrandModel(this.id, this.brand, this.status, this.createAt,
      this.updateAt);


}