class DeviceTokenModel{
  String id,user_id,device_type,device_token;

  DeviceTokenModel(this.id, this.user_id, this.device_type, this.device_token);


}