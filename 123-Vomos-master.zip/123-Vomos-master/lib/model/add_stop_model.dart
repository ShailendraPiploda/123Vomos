import 'package:flutter/cupertino.dart';

class AddStopModel {
  final TextEditingController editingController;
  double lat,long;

  AddStopModel(this.editingController, this.lat, this.long);


}