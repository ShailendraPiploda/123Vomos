import 'package:flutter/cupertino.dart';

class TripRouteDetails{
  String origin_addresses,destination_addresses,distance,duration,price,date,mainDate,mainPrice;
  TextEditingController stopController;
  int seconds;

  TripRouteDetails(this.origin_addresses, this.destination_addresses,this.distance,
      this.duration, this.price,this.date,this.stopController,this.seconds,this.mainDate,this.mainPrice);


}