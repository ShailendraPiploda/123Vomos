class SearchModel{
  String trip_id,user_id,seat_available,start_time,interval_time,booking_process,first_name,last_name,birth_year,
      from,to,total_price,departure_datetime,seat_booked,location_a_lat,location_a_long,location_b_lat,location_b_long,google_image
  ,facebook_image,image,email_varified,identity_document_verified,ratting;

  SearchModel(this.trip_id, this.user_id, this.seat_available, this.start_time,
      this.interval_time, this.booking_process, this.first_name, this.last_name,
      this.birth_year, this.from, this.to, this.total_price,
      this.departure_datetime, this.seat_booked, this.location_a_lat,
      this.location_a_long, this.location_b_lat, this.location_b_long,
      this.google_image, this.facebook_image, this.image, this.email_varified,
      this.identity_document_verified,this.ratting);


}