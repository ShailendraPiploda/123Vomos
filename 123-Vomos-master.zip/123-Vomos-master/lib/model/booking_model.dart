class BookingModel{
  String id,trackId,transaction_id,transaction_details,user_id,driver_id,trip_id,booking_type,driver_accept,request_time,
  booking_status,reminder_email_status,refund_status,refunded_amount,cancel_reason,reason_category,booking_location_start_id,booking_location_end_id
  ,total_distance,total_price,no_of_seat,trip_completed_mail_sent,trip_completed_mail_sent_five_days_after,added_date ,updated_date,
      location_a_name,location_b_name,first_name,last_name,image,facebook_image,avg_rating;

  BookingModel(this.id, this.trackId, this.transaction_id,
      this.transaction_details, this.user_id, this.driver_id, this.trip_id,
      this.booking_type, this.driver_accept, this.request_time,
      this.booking_status, this.reminder_email_status, this.refund_status,
      this.refunded_amount, this.cancel_reason, this.reason_category,
      this.booking_location_start_id, this.booking_location_end_id,
      this.total_distance, this.total_price, this.no_of_seat,
      this.trip_completed_mail_sent,
      this.trip_completed_mail_sent_five_days_after, this.added_date,
      this.updated_date, this.location_a_name, this.location_b_name,
      this.first_name, this.last_name, this.image, this.facebook_image,this.avg_rating);


}