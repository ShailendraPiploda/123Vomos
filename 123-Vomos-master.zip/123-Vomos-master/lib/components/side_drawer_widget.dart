import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:vamos/components/profile_image_widget.dart';
import 'package:vamos/screens/booking_request_screen.dart';
import 'package:vamos/screens/change_password.dart';
import 'package:vamos/screens/completed_trips_screen.dart';
import 'package:vamos/screens/current_reservation_screen.dart';
import 'package:vamos/screens/current_trips_screen.dart';
import 'package:vamos/screens/login_screen.dart';
import 'package:vamos/screens/messages_screen.dart';
import 'package:vamos/screens/payment_details_screen.dart';
import 'package:vamos/screens/personal_information_screen.dart';
import 'package:vamos/screens/posted_trips.dart';
import 'package:vamos/screens/reservation_cancel_screen.dart';
import 'package:vamos/screens/reservation_history_screen.dart';
import 'package:vamos/screens/vehicle_screen.dart';
import 'package:vamos/screens/verification_screen.dart';
import 'package:vamos/screens/welcome_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class SideDrawerWidget extends StatefulWidget {
  @override
  _SideDrawerWidget createState() => new _SideDrawerWidget();
}

class _SideDrawerWidget extends State<SideDrawerWidget> {
  bool _profileExpan = true;
  bool _postTripExpan = false;
  bool _resercationExpan = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
            AppTheme.colors.loginGradientEnd,
            AppTheme.colors.loginGradientStart
          ], begin: Alignment.topLeft, end: Alignment.bottomRight)),
          width: screenSize.width * .80,
          height: screenSize.height,
          child: ListView(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            children: <Widget>[
              ProfileImageWidget(),
              SizedBox(height: AppSize.mediumLarge),
              SizedBox(height: AppSize.small),
              // profile menu
              Container(
                  child: Column(
                children: <Widget>[
                  GestureDetector(
                      onTap: () {
                        setState(() {
                          if (_profileExpan) {
                            _profileExpan = false;
                          } else {
                            _profileExpan = true;
                          }
                        });
                      },
                      child: Row(
                        children: <Widget>[
                          SizedBox(
                            width: AppSize.small,
                          ),
                          Icon(Icons.person, color: Colors.white, size: AppSize.medium,),
                          SizedBox(
                            width: AppSize.small,
                          ),
                          Text(
                            Constants.profile,
                            style: AppTheme.textStyle.screenTitle.copyWith(
                                color: Colors.white,
                                fontSize: AppFontSize.s16,
                                fontWeight: FontWeight.w600),
                          ),
                          SizedBox(width: AppSize.small),
                          Icon(
                            _profileExpan ? Icons.arrow_drop_down : Icons.arrow_right,
                            size: 40.0,
                            color: Colors.white,
                          ),

                        ],
                      ),
                  ),

                  _profileExpan
                      ? Container(
                    margin: EdgeInsets.only(left: 50.0),
                    child: ListView(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      children: <Widget>[
                        InkWell(
                          onTap: () {
                            print("click");
                            AppRoutes.dismiss(context);
                            AppRoutes.goto(context, PersonalInformationScreen());
                          },
                          child: Container(
                            margin: EdgeInsets.only(top: 10.0),
                            child: Text(
                              Constants.personalInformation,
                              style: AppTheme.textStyle.lightText.copyWith(
                                  color: Colors.white,
                                  fontSize: AppFontSize.s16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                          width:screenSize.width*.80,
                          height: 1.0,
                          color: Colors.grey,

                        ),
                        InkWell(
                          onTap: () {
                            AppRoutes.dismiss(context);
                            AppRoutes.goto(context, VerificationScreen());
                          },
                          child: Container(
                            margin: EdgeInsets.only(top: 10.0),
                            child: Text(
                              Constants.verification,
                              style: AppTheme.textStyle.lightText.copyWith(
                                  color: Colors.white,
                                  fontSize: AppFontSize.s16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                          width:screenSize.width*.80,
                          height: 1.0,
                          color: Colors.grey,

                        ),
                        InkWell(
                          onTap: () {
                            AppRoutes.dismiss(context);
                            AppRoutes.goto(context, VehicleScreen());
                          },
                          child: Container(
                            margin: EdgeInsets.only(top: 10.0),
                            child: Text(
                              Constants.vehical,
                              style: AppTheme.textStyle.lightText.copyWith(
                                  color: Colors.white,
                                  fontSize: AppFontSize.s16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),

                        Container(
                          margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                          width:screenSize.width*.80,
                          height: 1.0,
                          color: Colors.grey,

                        ),
                        InkWell(
                          onTap: () {
                            AppRoutes.dismiss(context);
                            AppRoutes.goto(context, ChangePassword());
                          },
                          child: Container(
                            margin: EdgeInsets.only(top: 10.0),
                            child: Text(
                              Constants.chagePassword,
                              style: AppTheme.textStyle.lightText.copyWith(
                                  color: Colors.white,
                                  fontSize: AppFontSize.s16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                      : SizedBox(width: AppSize.small),
                  Container(
                    margin: EdgeInsets.only(top: 4.0),
                    height: 1.0,
                    width: screenSize.width * .80,
                    color: Colors.grey,
                  )
                ],
              )),

              // post trip menu
              Container(
                  child: Column(
                    children: <Widget>[
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              if (_postTripExpan) {
                                _postTripExpan = false;
                              } else {
                                _postTripExpan = true;
                              }
                            });
                          },
                          child:   Row(
                            children: <Widget>[
                              SizedBox(
                                width: AppSize.small,
                              ),
                              Icon(Icons.directions_car, color: Colors.white, size: AppSize.medium,),
                              SizedBox(
                                width: AppSize.small,
                              ),
                              Text(
                                Constants.postTrips,
                                style: AppTheme.textStyle.screenTitle.copyWith(
                                    color: Colors.white,
                                    fontSize: AppFontSize.s16,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(width: AppSize.small),
                              Icon(
                                _postTripExpan ? Icons.arrow_drop_down : Icons.arrow_right,
                                size: 40.0,
                                color: Colors.white,
                              ),

                            ],
                          ),
                      ),

                      _postTripExpan
                          ? Container(
                        margin: EdgeInsets.only(left: 50.0),
                        child: ListView(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, BookingRequestScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.bookingRequest,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                              width:screenSize.width*.80,
                              height: 1.0,
                              color: Colors.grey,

                            ),
                            InkWell(
                              onTap: () {
                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, CurrentTripstScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.currentTrip,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                              width:screenSize.width*.80,
                              height: 1.0,
                              color: Colors.grey,

                            ),
                            InkWell(
                              onTap: () {
                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, PostedTripsScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.postTrips,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                              width:screenSize.width*.80,
                              height: 1.0,
                              color: Colors.grey,

                            ),
                            InkWell(
                              onTap: () {
                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, CompletedTripstScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.completedTrips,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                          : SizedBox(width: AppSize.small),
                      Container(
                        margin: EdgeInsets.only(top: 4.0),
                        height: 1.0,
                        width: screenSize.width * .80,
                        color: Colors.grey,
                      )
                    ],
                  )),

              // reservation menu
              Container(
                  child: Column(
                    children: <Widget>[
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              if (_resercationExpan) {
                                _resercationExpan = false;
                              } else {
                                _resercationExpan = true;
                              }
                            });
                          },
                          child: Row(
                            children: <Widget>[
                              SizedBox(
                                width: AppSize.small,
                              ),
                              Icon(Icons.book, color: Colors.white, size: AppSize.medium,),
                              SizedBox(
                                width: AppSize.small,
                              ),
                              Text(
                                Constants.reservations,
                                style: AppTheme.textStyle.screenTitle.copyWith(
                                    color: Colors.white,
                                    fontSize: AppFontSize.s16,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(width: AppSize.small),
                              Icon(
                                _resercationExpan ? Icons.arrow_drop_down : Icons.arrow_right,
                                size: 40.0,
                                color: Colors.white,
                              ),

                            ],
                          ),
                      ),

                      _resercationExpan
                          ? Container(
                        margin: EdgeInsets.only(left: 50.0),
                        child: ListView(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, CurrentReservationScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.currentReservation,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                              width:screenSize.width*.80,
                              height: 1.0,
                              color: Colors.grey,

                            ),

                            InkWell(
                              onTap: () {

                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, ReservationHistoryScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.reservationHistory,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 30.0,top: 5.0,bottom: 5.0),
                              width:screenSize.width*.80,
                              height: 1.0,
                              color: Colors.grey,

                            ),
                            InkWell(
                              onTap: () {

                                AppRoutes.dismiss(context);
                                AppRoutes.goto(context, ReservationCancelScreen());
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 10.0),
                                child: Text(
                                  Constants.reservationCancel,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.white,
                                      fontSize: AppFontSize.s16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                          : SizedBox(width: AppSize.small),
                      Container(
                        margin: EdgeInsets.only(top: 4.0),
                        height: 1.0,
                        width: screenSize.width * .80,
                        color: Colors.grey,
                      )
                    ],
                  )),


              // payment menu
              Container(
                margin: EdgeInsets.only(top: 10.0),
                  child: InkWell(
                    onTap: () {

                      AppRoutes.dismiss(context);
                      AppRoutes.goto(context, PaymentDetailsScreen());
                    },
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: AppSize.small,
                        ),
                        Icon(Icons.payment, color: Colors.white, size: AppSize.medium,),
                        SizedBox(
                          width: AppSize.small,
                        ),
                        Text(
                          Constants.paymentDetails,
                          style: AppTheme.textStyle.screenTitle.copyWith(
                              color: Colors.white,
                              fontSize: AppFontSize.s16,
                              fontWeight: FontWeight.w600),
                        ),
                        SizedBox(width: AppSize.small),

                      ],
                    ),
                  ),),

              Container(
                margin: EdgeInsets.only(top: 10.0),
                height: 1.0,
                width: screenSize.width * .80,
                color: Colors.grey,
              ),
              // logout menu
              Container(
                margin: EdgeInsets.only(top: 10.0),
                child: InkWell(
                  onTap: () {



                    ShareMananer.LogOut(context);


                  },
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: AppSize.small,
                      ),
                      Icon(Icons.exit_to_app, color: Colors.white, size: AppSize.medium,),
                      SizedBox(
                        width: AppSize.small,
                      ),
                      Text(
                        Constants.logout,
                        style: AppTheme.textStyle.screenTitle.copyWith(
                            color: Colors.white,
                            fontSize: AppFontSize.s16,
                            fontWeight: FontWeight.w600),
                      ),
                      SizedBox(width: AppSize.small),

                    ],
                  ),
                ),),

            ],
          ),
        ),
      ),
    );

  }
}
