import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

import 'alert_widget.dart';

class AlertButton extends StatelessWidget {
  final String title;
  final GestureTapCallback callback;
  final ButtonType buttonType;
  final AlertType alertType;

  const AlertButton({
    Key key,
    this.title,
    @required this.callback,
    @required this.buttonType,
    @required this.alertType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      child: Container(
        constraints: BoxConstraints(
          minHeight: AppSize.extraLarge,
          maxHeight: AppSize.extraLarge,
          maxWidth: AppSize.s80,
          minWidth: AppSize.s70,
        ),
        decoration: new BoxDecoration(
          borderRadius: const BorderRadius.all(
            Radius.circular(5.0),
          ),
        ),
        padding: EdgeInsets.symmetric(horizontal: AppSize.extraSmall),
        child: Center(
          child: Text(
            (buttonType == ButtonType.positiveButton)
                ? (title ?? Constants.positiveButtonText)
                : (title ?? Constants.negativeButtonText),
            style: (buttonType == ButtonType.positiveButton)
                ? AppTheme.textStyle.timerTextActive
                : AppTheme.textStyle.alertText,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
      onTap: callback,
    );
  }
}