import 'package:flutter/material.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_color.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class RoundWhiteBorderButtonWidget extends StatelessWidget{
  final String title;
  final GestureTapCallback callback;
  final double buttonWidth;
  bool isButtonColorReverse=  false;
  RoundWhiteBorderButtonWidget({ @required this.title, @required this.callback, @required this.buttonWidth,this.isButtonColorReverse});
  @override
  Widget build(BuildContext context) {

    if(isButtonColorReverse==null)
    {
      isButtonColorReverse=false;
    }
    // TODO: implement build
    return Container(
      decoration: new BoxDecoration(
        color: !isButtonColorReverse?Colors.white:AppTheme.accentColor,
        borderRadius: BorderRadius.all(Radius.circular(AppSize.mediumLarge)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.grey,
            offset: Offset(1.0, 6.0),
            blurRadius: 10.0,
          ),

        ],
      ),

      child: MaterialButton(
          highlightColor: Colors.transparent,
          splashColor: !isButtonColorReverse?AppTheme.accentColor:Colors.white,
          //shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5.0))),
          child: Padding(
            padding: const EdgeInsets.symmetric(
                vertical: 15.0, horizontal: 10.0),
            child: Text(
              title,
              style:AppTheme.textStyle.buttonText.copyWith(fontSize: 20.0,color: AppTheme.primaryColor),
            ),
          ),
          onPressed: () {
            callback();
          }
      ),
    );
  }
}