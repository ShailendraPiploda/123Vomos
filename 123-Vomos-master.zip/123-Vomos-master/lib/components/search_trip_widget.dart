import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/seat_widget.dart';
import 'package:vamos/screens/search_details_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_text_style.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class SearcgTripsWidget extends StatefulWidget {

  String imageUrl,rating,years,email,document;
  String customerName, locationFrom,locationTo, dateTime,paidAmount, noOfSeatToBook;

  GestureTapCallback onTap;

  SearcgTripsWidget(
      {@required this.email,@required this.document,@required this.imageUrl,@required this.rating,this.locationTo,@required this.years, @required this.customerName, @required this.onTap,
        @required this.locationFrom, @required this.dateTime,@required this.paidAmount, @required this.noOfSeatToBook});

  @override
  _SearcgTripsWidget createState() => new _SearcgTripsWidget();

}

class _SearcgTripsWidget extends State<SearcgTripsWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.maxFinite,
        margin:EdgeInsets.all(5.0),
        child: Card(
          elevation: 5.0,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(2.0),),
          child:Container(
            padding: EdgeInsets.all(5.0),
            child: InkWell(

              onTap: (){
                widget.onTap();
              },

              child: Column(children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      width: SizeConfig.widthMultiplier*45,
                      child: Row(children: <Widget>[
                        Icon(Icons.location_on,color: AppTheme.primaryColor,),
                        Container(
                          child:  Text("From",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                        ),
                      ],),
                    ),


                    Container(
                      padding: EdgeInsets.only(right: 10.0),
                      width: SizeConfig.widthMultiplier*45,
                      child:  Text(Constants.currancy+widget.paidAmount+"/Seat",textAlign: TextAlign.end,style: AppTheme.textStyle.heading1.copyWith(color: AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                    ),
                  ],),

                SizedBox(height: 5.0,),

                Row(
                 crossAxisAlignment: CrossAxisAlignment.start,
                 mainAxisAlignment: MainAxisAlignment. spaceBetween,
                  children: <Widget>[

                    Container(
                      margin: EdgeInsets.only(left: 20.0),
                      width: SizeConfig.widthMultiplier*45,
                      child:  Text(widget.locationFrom,
                          textAlign: TextAlign.start,
                          style: AppTheme.textStyle.lightText.copyWith(
                              color: Colors.grey, fontSize: AppFontSize.s14)),
                    ),

                    Container(
                      padding: EdgeInsets.only(right: 10.0),
                      width: SizeConfig.widthMultiplier*42,
                      child:  Text(widget.dateTime, textAlign: TextAlign.end,
                        style: AppTheme.textStyle.lightText.copyWith(
                            color: Colors.grey, fontSize: AppFontSize.s14)),
                    ),


                  ],),

                SizedBox(height: AppSize.medium,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      width: SizeConfig.widthMultiplier*30,
                      child: Row(children: <Widget>[
                        Icon(Icons.location_on,color: AppTheme.primaryColor,),
                        Container(
                          child:  Text("To",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                        ),
                      ],),
                    ),


                    Container(
                      padding: EdgeInsets.only(right: 10.0),
                      height: 10.0,
                      alignment: Alignment.centerRight,
                      width: SizeConfig.widthMultiplier*40,
                      child:  ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: int.parse(widget.noOfSeatToBook),
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          return SeatWidget();
                        },
                      ),
                    ),
                  ],),



                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 5.0,),

                    Container(
                      margin: EdgeInsets.only(left: 20.0),
                      width: SizeConfig.widthMultiplier*40,
                      child:  Text(widget.locationTo, textAlign: TextAlign.start,
                        style: AppTheme.textStyle.lightText.copyWith(
                            color: Colors.grey, fontSize: AppFontSize.s14)),
                    ),


                  ],),

              SizedBox(height: AppSize.medium,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                        width: SizeConfig.widthMultiplier*50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                          Card(
                            shape: CircleBorder(side: BorderSide(
                                color: Colors.grey, width: 0.5
                            )),
                            child:Material(
                              elevation: 4.0,
                              shape: CircleBorder(),
                              clipBehavior: Clip.hardEdge,
                              color: Colors.transparent,
                              child:Container(
                                child: FadeInImage.assetNetwork(placeholder: Assets.avtar,image: widget.imageUrl,fit: BoxFit.cover,),
                                // fit: BoxFit.cover,
                                width: SizeConfig.widthMultiplier*12,
                                height: SizeConfig.widthMultiplier*12,

                              ),
                            ),
                          ),
                            SizedBox(width: AppSize.extraSmall,),
                          Container(width: SizeConfig.widthMultiplier*30,
                            child:   Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                //  SizedBox(height: AppSize.large,),
                                Text(
                                  widget.customerName,
                                  style: AppTheme.textStyle.heading1
                                      .copyWith(
                                      color: Colors.grey,
                                      fontSize: AppFontSize.s14),
                                ),
                                SizedBox(height: AppSize.extraSmall,),
                                RatingBar(
                                    itemSize: 20.0,
                                    initialRating: double.parse(widget.rating),
                                    minRating: 1,
                                    direction: Axis.horizontal,
                                    allowHalfRating: true,
                                    itemCount: 5,
                                    itemBuilder: (context, _) => Icon(
                                      Icons.star,
                                      color: AppTheme.accentColor,

                                    )),

                                // SizedBox(height: AppSize.small,),

                              ],
                            ),)
                        ],)
                    ),

                    Container(
                      padding: EdgeInsets.only(right: 10.0),
                      width: SizeConfig.widthMultiplier*40,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: <Widget>[


                          Container(

                            child: Text(Constants.idVerified,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14),),
                          ),

                        SizedBox(height: AppSize.extraSmall,),
                          Container(
                           width: SizeConfig.widthMultiplier*40,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: <Widget>[
                              Icon(Icons.description,color: widget.document=="1"?AppTheme.primaryColor: Colors.grey,size: AppSize.medium,),
                              SizedBox(width: AppSize.medium,),
                              Icon(Icons.email,color: widget.email=="1"?AppTheme.primaryColor: Colors.grey,size: AppSize.medium,),

                            ],),
                          ),

                        ],
                      ),
                    )
                  ],
                ),
                
                SizedBox(height: AppSize.small,),


              ],),
            ),
          ),)

    );
  }
}
