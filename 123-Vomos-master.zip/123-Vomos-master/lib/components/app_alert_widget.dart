import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

import 'alert_button_widget.dart';
import 'alert_icon_widget.dart';
import 'alert_widget.dart';

class AppAlert extends StatefulWidget {
  final String text;
  final String title;
  final AlertType alertType;
  final String positiveButtonText;
  final String negativeButtonText;
  final GestureTapCallback positiveButtonOnTap;
  final GestureTapCallback negativeButtonOnTap;
  final bool popAfter;

  AppAlert({
    @required this.text,
    @required this.alertType,
    this.title,
    @required this.positiveButtonOnTap,
    this.negativeButtonOnTap,
    this.positiveButtonText,
    this.negativeButtonText,
    this.popAfter = true,
  });

  @override
  _AppAlertState createState() => _AppAlertState();
}

class _AppAlertState extends State<AppAlert> with TickerProviderStateMixin {
  AnimationController _controller;
  Animation _animation;
  bool animationComplete = false;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(vsync: this, duration: Duration(milliseconds: 800));

    _animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.elasticInOut,
    ));

    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          animationComplete = true;
        });
      }
    });
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {},
      child: AnimatedBuilder(
          animation: _controller,
          builder: (BuildContext context, Widget child) {
            return FadeTransition(
              opacity: _controller,
              child: Transform(
                transform: animationComplete
                    ? Matrix4.translationValues(_animation.value * screenSize.width * -1.0, 0.0, 0.0)
                    : Matrix4.translationValues(_animation.value * screenSize.width, 0.0, 0.0),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: AppSize.smallMedium),
                        padding: EdgeInsets.all(AppSize.small),
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.white,
                              spreadRadius: 10.0,
                              blurRadius: 50.0,
                            ),
                          ],
                          borderRadius: BorderRadius.circular(15.0),
                          color: Colors.white,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Material(
                              color: Colors.white,
                              child: Column(
                                children: <Widget>[
                                  getAlertIcon(widget.alertType),
                                  Padding(
                                    padding: EdgeInsets.all(AppSize.small),
                                    child: Text(
                                      widget.text,
                                      style: AppTheme.textStyle.alertText,
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                  (widget.negativeButtonText == null && widget.negativeButtonOnTap == null)
                                      ? AlertButton(
                                    buttonType: ButtonType.positiveButton,
                                    title: widget.positiveButtonText,
                                    callback: () async {
                                      await _controller.reverse();

                                      if (widget.popAfter) {
                                        print("Alert-------------> poped");
                                        AppRoutes.dismissAlert(context);
                                      }
                                      widget.positiveButtonOnTap();

                                      print("Alert-------------> positiveButton");
                                    },
                                    alertType: widget.alertType,
                                  )
                                      : Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: <Widget>[
                                      AlertButton(
                                        buttonType: ButtonType.negativeButton,
                                        title: widget.negativeButtonText,
                                        callback: () async {
                                          await _controller.reverse();

                                          if (widget.popAfter) {
                                            print("Alert-------------> poped");
                                            AppRoutes.dismissAlert(context);
                                          }
                                          widget.negativeButtonOnTap();

                                          print("Alert-------------> negativeButton");
                                        },
                                        alertType: widget.alertType,
                                      ),
                                      AlertButton(
                                        buttonType: ButtonType.positiveButton,
                                        title: widget.positiveButtonText,
                                        callback: () async {
                                          await _controller.reverse();
                                          if (widget.popAfter) {
                                            print("Alert-------------> poped");
                                            AppRoutes.dismissAlert(context);
                                          }
                                          widget.positiveButtonOnTap();

                                          print("Alert-------------> positiveButton");
                                        },
                                        alertType: widget.alertType,
                                      )
                                    ],
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
    );
  }
}