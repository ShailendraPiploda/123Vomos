import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_text_style.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class ReservationHistoryWidget extends StatefulWidget {
  String imageUrl,rating;
  String customerName, locationFrom,locationTo,  dateTime, paidAmount, noOfSeatToBook;

  GestureTapCallback onTap;

  ReservationHistoryWidget(
      {@required this.imageUrl,
      @required this.customerName,
      @required this.onTap,
        @required this.rating,
        @required this.locationFrom,@required this.locationTo,
      @required this.dateTime,
      @required this.paidAmount,
      @required this.noOfSeatToBook});

  @override
  _ReservationHistoryWidget createState() => new _ReservationHistoryWidget();
}

class _ReservationHistoryWidget extends State<ReservationHistoryWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: screenSize.width*.90,
        margin:EdgeInsets.all(5.0),
        child: Card(
          elevation: 5.0,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(2.0),),
          child:InkWell(

            child: Container(
              padding: EdgeInsets.all(5.0),
              child: Column(children: <Widget>[

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      width: SizeConfig.widthMultiplier*45,
                      child: Row(children: <Widget>[
                        Icon(Icons.location_on,color: AppTheme.primaryColor,),
                        Container(
                          child:  Text("From",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                        ),
                      ],),
                    ),


                    Container(
                      padding: EdgeInsets.only(right: 5.0),
                      width: SizeConfig.widthMultiplier*45,
                      child:  Text(widget.dateTime,textAlign: TextAlign.end,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                    ),
                  ],),

                SizedBox(height: 5.0,),

                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment. spaceBetween,
                  children: <Widget>[

                    Container(
                      margin: EdgeInsets.only(left: 20.0),
                      width: SizeConfig.widthMultiplier*40,
                      child:  Text(widget.locationFrom,textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                    ),





                  ],),

                SizedBox(height: AppSize.small,),

                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[

                    Container(
                        width: SizeConfig.widthMultiplier*50,
                        child: Column(children: <Widget>[
                          Row(children: <Widget>[
                            Icon(Icons.location_on,color: AppTheme.primaryColor,),
                            Container(
                              child:  Text("To",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                            ),
                          ],),

                          SizedBox(height: 5.0,),

                          Container(
                            margin: EdgeInsets.only(left: 20.0),
                            width: SizeConfig.widthMultiplier*50,
                            child:  Text(widget.locationTo,textAlign: TextAlign.justify,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                          ),

                          SizedBox(height: AppSize.small,),
                          Container(
                              width: SizeConfig.widthMultiplier*50,
                              child: Row(children: <Widget>[
                                Card(
                                  shape: CircleBorder(side: BorderSide(
                                      color: Colors.grey, width: 0.5
                                  )),
                                  child: Container(
                                    width: SizeConfig.widthMultiplier*15,
                                    height:SizeConfig.widthMultiplier*15,
                                    child: Icon(Icons.person, color: AppTheme.colors.loginGradientStart, size: AppSize.extraLarge,),
                                  ),
                                ),

                                Container(width: SizeConfig.widthMultiplier*30,
                                  child:   Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: <Widget>[
                                      //  SizedBox(height: AppSize.large,),
                                      Text(widget.customerName, style: AppTheme.textStyle.lightHeading.copyWith(color: Colors.black,fontSize: AppFontSize.s16),),
                                      SizedBox(height: AppSize.extraSmall,),
                                      RatingBar(
                                          itemSize: 20.0,
                                          initialRating: double.parse(widget.rating),
                                          minRating: 1,
                                          direction: Axis.horizontal,
                                          allowHalfRating: true,
                                          itemCount: 5,
                                          itemBuilder: (context, _) => Icon(
                                            Icons.star,
                                            color: AppTheme.accentColor,

                                          )),

                                      // SizedBox(height: AppSize.small,),

                                    ],
                                  ),)
                              ],)
                          ),


                        ],)
                    ),


                    Container(
                        alignment: Alignment.centerRight,
                        width: SizeConfig.widthMultiplier*40,
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: <Widget>[


                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: <Widget>[

                                Container(
                                  child:  Text(Constants.paidAmount,textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                                ),
                              ],),

                            SizedBox(height: 5.0,),




                            Container(
                              padding: EdgeInsets.only(right: 5.0),
                              width: SizeConfig.widthMultiplier*45,
                              // width: SizeConfig.widthMultiplier*65,
                              child:  Text(Constants.currancy+widget.paidAmount,textAlign: TextAlign.end,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                            ),


                            SizedBox(height: AppSize.medium,),

                            Container(
                              alignment: Alignment.centerRight,
                              margin: EdgeInsets.only(right: 5.0),
                               width: SizeConfig.widthMultiplier*40,
                              child:     Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: <Widget>[
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: <Widget>[
                                    Icon(Icons.event_seat,color: AppTheme.primaryColor,),
                                    SizedBox(width: AppSize.extraSmall,),
                                    Container(
                                      child:  Text(widget.noOfSeatToBook,textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                                    ),
                                  ],),
                              Container(
                            //  margin: EdgeInsets.only(right: 5.0),
                              //  width: SizeConfig.widthMultiplier*40,
                              child:   RaisedButton(
                                splashColor: AppTheme.accentColor,
                                color: AppTheme.primaryColor,
                                textColor: Colors.white,
                                child: Text(Constants.feedbackRating),
                                onPressed: (){
                                  widget.onTap();
                                },
                              ),
                            ),
                                ],
                              ),
                            ),

                          ],)
                    ),
                  ],),









              ],),
            ),
          ),)

    );
  }
}
