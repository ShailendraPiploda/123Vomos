import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:vamos/components/seat_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_text_style.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class BookingWidget extends StatefulWidget {

  String imageUrl;
  String customerName, locationFrom,locationTo, dateTime1, dateTime2, rating, email;

  GestureTapCallback onAcceptTap,onRejectTab,onTabDetails,onTabChat;

  BookingWidget(
      {@required this.onTabChat,@required this.onTabDetails,@required this.imageUrl, @required this.customerName, @required this.onAcceptTap, @required this.onRejectTab,
        @required this.locationTo, @required this.locationFrom, @required this.dateTime1, @required this.dateTime2, @required this.rating, @required this.email});

  @override
  _BookingWidget createState() => new _BookingWidget();

}

class _BookingWidget extends State<BookingWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: screenSize.width*.90,
        margin:EdgeInsets.all(5.0),
        child: GestureDetector(
          onTap: (){
            widget.onTabDetails();
          },
          child: Card(
            elevation: 5.0,
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2.0),),
            child:InkWell(

              child: Container(
                padding: EdgeInsets.all(5.0),
                child: Column(children: <Widget>[

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[

                      Container(
                        width: SizeConfig.widthMultiplier*45,
                        child: Row(children: <Widget>[
                          Icon(Icons.location_on,color: AppTheme.primaryColor,),
                          Container(
                            child:  Text("From",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                          ),
                        ],),
                      ),


                      Container(
                        padding: EdgeInsets.only(right: 5.0),
                        width: SizeConfig.widthMultiplier*45,
                        child:  Text(widget.dateTime1,textAlign: TextAlign.end,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                      ),
                    ],),

                  SizedBox(height: 5.0,),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment. spaceBetween,
                    children: <Widget>[

                      Container(
                        margin: EdgeInsets.only(left: 20.0),
                        width: SizeConfig.widthMultiplier*40,
                        child:  Text(widget.locationFrom,textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                      ),

                      Container(
                        margin: EdgeInsets.only(right: 5.0),
                      //  width: SizeConfig.widthMultiplier*40,
                        child:   RaisedButton(
                          splashColor: AppTheme.accentColor,
                          color: AppTheme.primaryColor,
                          textColor: Colors.white,
                          child: Text(Constants.accept),
                          onPressed: (){
                            widget.onAcceptTap();
                          },
                        ),
                      ),




                    ],),

                //  SizedBox(height: AppSize.small,),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[

                      Container(
                       width: SizeConfig.widthMultiplier*65,
                        child: Column(children: <Widget>[
                          Row(children: <Widget>[
                            Icon(Icons.location_on,color: AppTheme.primaryColor,),
                            Container(
                              child:  Text("To",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                            ),
                          ],),

                          SizedBox(height: 5.0,),

                          Container(
                            margin: EdgeInsets.only(left: 20.0),
                            width: SizeConfig.widthMultiplier*65,
                            child:  Text(widget.locationTo,textAlign: TextAlign.justify,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                          ),

                          SizedBox(height: AppSize.small,),
                          Container(
                              width: screenSize.width*.65,
                              child: Row(children: <Widget>[
                                Card(
                                  shape: CircleBorder(side: BorderSide(
                                      color: Colors.grey, width: 0.5
                                  )),
                                  child: Container(
                                    width: screenSize.width*.15,
                                    height: screenSize.width*.15,
                                    child:  CachedNetworkImage(
                                      imageUrl:widget.imageUrl,
                                      imageBuilder: (context, imageProvider) => Container(
                                        width: SizeConfig.widthMultiplier * 15,
                                        height: SizeConfig.widthMultiplier * 15,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          //  borderRadius: BorderRadius.circular(16.0),
                                          image: DecorationImage(
                                            image: imageProvider,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                      //  placeholder: (context, url) => CircularProgressIndicator(),
                                      // errorWidget: (context, url, error) => Icon(Icons.error),
                                    ),
                                  ),
                                ),

                                Container(width: screenSize.width*.30,
                                  child:   Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: <Widget>[
                                      //  SizedBox(height: AppSize.large,),
                                      Text(widget.customerName, style: AppTheme.textStyle.lightHeading.copyWith(color: Colors.black,fontSize: AppFontSize.s16),),
                                      SizedBox(height: AppSize.extraSmall,),
                                      RatingBar(
                                          itemSize: 20.0,
                                          initialRating: double.parse(widget.rating),
                                          minRating: 1,
                                          direction: Axis.horizontal,
                                          allowHalfRating: true,
                                          itemCount: 5,
                                          itemBuilder: (context, _) => Icon(
                                            Icons.star,
                                            color: AppTheme.accentColor,

                                          )),

                                      // SizedBox(height: AppSize.small,),

                                    ],
                                  ),)
                              ],)
                          ),


                        ],)
                      ),


                      Container(
                        alignment: Alignment.centerRight,
                        width: SizeConfig.widthMultiplier*27,
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: <Widget>[


                          RaisedButton(
                            splashColor: AppTheme.primaryColor,
                            color: AppTheme.accentColor,
                            textColor: Colors.white,
                            child: Text(Constants.reject),
                            onPressed: (){
                              widget.onRejectTab();
                            },
                          ),
                          SizedBox(height: AppSize.smallMedium,),
                        Container(
                        width: screenSize.width*.30,
                        child:  Container(
                          width: screenSize.width*.45,
                          child:  GestureDetector(
                              onTap:(){
                                widget.onTabChat();
                          },child: Icon(Icons.chat,size: AppSize.mediumLarge,color: AppTheme.primaryColor,)),
                        ),)
                        ],)
                      ),
                    ],),










                  Container(
                    padding: EdgeInsets.only(left: 5.0),
                    width: screenSize.width*.90,
                    child:Text(widget.dateTime2,textAlign: TextAlign.start,style: AppTheme.textStyle.lightText.copyWith(color: Colors.grey,fontSize: AppFontSize.s12)),
                  ),

                ],),
              ),
            ),),
        )

    );
  }
}
