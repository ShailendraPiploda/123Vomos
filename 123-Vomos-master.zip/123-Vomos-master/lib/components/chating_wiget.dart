import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:bubble/bubble.dart';
import 'package:vamos/utils/size_config.dart';

class ChattingWidget extends StatefulWidget {

  String AppUSerId;
  String chatUserId,  dateTime,message;
  bool isDateShow=false;
  GestureTapCallback onTap;

  ChattingWidget({ @required this.chatUserId, @required this.onTap,
         @required this.dateTime,@required this.message,@required this.AppUSerId,@required this.isDateShow});

  @override
  _ChattingWidget createState() => new _ChattingWidget();

}

class _ChattingWidget extends State<ChattingWidget> {


  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10.0),
      child: Column(children: <Widget>[
      widget.AppUSerId==widget.chatUserId ?Column(
        children: <Widget>[
          Bubble(
            margin: BubbleEdges.only(top: 5.0,right: 5.0),
            shadowColor: AppTheme.primaryColor,
            elevation: 2,
            alignment: Alignment.topRight,
            nip: BubbleNip.rightTop,
            color: AppTheme.accentColor,
            //color: Color.fromARGB(255, 225, 255, 199),
            child: Text(widget.message,style: TextStyle(color: Colors.white),),
          ),
          widget.isDateShow ?Container(
            margin: EdgeInsets.only(top: AppSize.extraSmall,right:AppSize.small),
            width: double.maxFinite,
            height: AppSize.smallMedium,
            child:  Text(widget.dateTime,textAlign: TextAlign.right,style: AppTheme.textStyle.hintText.copyWith(color: Colors.grey,fontSize: AppFontSize.s12),)
            ,):SizedBox(height: 0.0,)
        ],
      ):Column(children: <Widget>[
        Bubble(
          margin: BubbleEdges.only(top: 5.0,left: 5.0),
          shadowColor: AppTheme.primaryColor,
          elevation: 2,
          alignment: Alignment.topLeft,
          nip: BubbleNip.leftTop,
          child: Text(widget.message),
        ),
        widget.isDateShow ?Container(
          margin: EdgeInsets.only(top: AppSize.extraSmall,left:AppSize.small),
          width: double.maxFinite,
          height: AppSize.smallMedium,
          child:  Text(widget.dateTime,textAlign: TextAlign.left,style: AppTheme.textStyle.hintText.copyWith(color: Colors.grey,fontSize: AppFontSize.s12),)
          ,):SizedBox(height: 0.0,)
      ],)
      ],),
    );
  }
}
