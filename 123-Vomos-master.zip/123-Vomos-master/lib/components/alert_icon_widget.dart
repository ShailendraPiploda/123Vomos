import 'package:flutter/material.dart';
import 'package:vamos/utils/app_assets.dart';

import 'alert_widget.dart';

Widget getAlertIcon(AlertType type) {
  switch (type) {
    case AlertType.Success:
      break;
    case AlertType.Warning:
//      return Image(
//        image: AssetImage(Assets.alarm),
//        height: 50.0,
//      );
      break;

    case AlertType.Error:
//      return Image(
//        image: AssetImage(Assets.sad),
//        height: 50.0,
//      );
      break;

    case AlertType.Internet:
//      return Image(
//        image: AssetImage(Assets.internet),
//        height: 50.0,
//      );
      break;

    case AlertType.Locked:
      return Image(
        image: AssetImage(Assets.iconLocked),
        height: 50.0,
        color: Colors.red,
      );
      break;
  }
//  return Image(
//    image: AssetImage(Assets.success),
//    height: 50.0,
//  );
}