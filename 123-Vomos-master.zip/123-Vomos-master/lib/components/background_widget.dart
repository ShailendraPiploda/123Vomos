import 'package:flutter/material.dart';
import 'package:vamos/utils/app_size.dart';

class BackgroundWidget extends StatelessWidget {
  final String image;
  final Widget child;

  const BackgroundWidget({
    Key key,
    this.image,
    this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: screenSize.width,
      height: screenSize.height,
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage(image),
            fit: BoxFit.fill
        ),
      ),
      child: child,
    );
  }
}