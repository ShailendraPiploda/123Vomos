import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:vamos/screens/post_a_trips_screen.dart';
import 'package:vamos/screens/post_trip_details.dart';
import 'package:vamos/screens/search_details_screen.dart';
import 'package:vamos/screens/update_post_a_trips_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_text_style.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class PostTripsWidget extends StatefulWidget {


  final String totalSeats, locationFrom,locationTo, dateTime1, dateTime2, pricePerSeat,id;

  GestureTapCallback onTap;

  PostTripsWidget(
      { @required this.id, @required this.totalSeats, @required this.onTap,
        @required this.locationFrom, @required this.locationTo, @required this.dateTime1, @required this.dateTime2, @required this.pricePerSeat});

  @override
  _PostTripsWidget createState() => new _PostTripsWidget();

}

class _PostTripsWidget extends State<PostTripsWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: screenSize.width*.90,
        margin:EdgeInsets.all(5.0),      
        child: Card(
          elevation: 5.0,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(2.0),),
          child:Container(
            padding: EdgeInsets.all(5.0),
            child: InkWell(

              onTap: (){
                  AppRoutes.goto(context,PostTripDetailsScreen(widget.id));
              },
              
              child: Column(children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      alignment: Alignment.centerLeft,
                      width: SizeConfig.widthMultiplier*45,
                      child: Row(children: <Widget>[
                        Icon(Icons.location_on,color: AppTheme.primaryColor,),
                        Container(
                          child:  Text("From",textAlign: TextAlign.start,
                              style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                        ),
                      ],),
                    ),


                    Container(
                      margin: EdgeInsets.only(right: 5.0),
                      alignment: Alignment.centerRight,
                      width: SizeConfig.widthMultiplier*45,
                      child:  Text(Constants.currancy+widget.pricePerSeat+"/Seat",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color: AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                    ),
                  ],),

                SizedBox(height: 5.0,),

                Row(
                  // crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment. spaceBetween,
                  children: <Widget>[

                    Container(
                      margin: EdgeInsets.only(left: 20.0),
                      width: SizeConfig.widthMultiplier*40,
                      child:  Text(widget.locationFrom,textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                    ),

                    Container(
                      margin: EdgeInsets.only(right: 5.0),
                      alignment: Alignment.centerRight,
                      width: SizeConfig.widthMultiplier*45,
                      child:  Text(widget.dateTime1,textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                    ),


                  ],),

                SizedBox(height: AppSize.medium,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Container(
                      width: SizeConfig.widthMultiplier*45,
                      child: Row(children: <Widget>[
                        Icon(Icons.location_on,color: AppTheme.primaryColor,),
                        Container(
                          child:  Text("To",textAlign: TextAlign.start,style: AppTheme.textStyle.heading1.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                        ),
                      ],),
                    ),

                    Container(
                      margin: EdgeInsets.only(right: 5.0),
                      alignment: Alignment.centerRight,
                      width: SizeConfig.widthMultiplier*45,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[

                        Icon(Icons.event_seat,color: AppTheme.primaryColor,),
                          SizedBox(width: AppSize.extraSmall,),
                        Container(
                          child:  Text(widget.totalSeats,textAlign: TextAlign.start,style: AppTheme.textStyle.screenTitle.copyWith(color:AppTheme.primaryColor,fontSize: AppFontSize.s14)),
                        ),
                      ],),
                    ),



                  ],),



                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[

                    Container(
                      margin: EdgeInsets.only(left: 20.0),
                      width: SizeConfig.widthMultiplier*45,
                      child:  Text(widget.locationTo,textAlign: TextAlign.justify,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
                    ),


//                    Container(
//                      margin: EdgeInsets.only(right: 5.0),
//                      alignment: Alignment.centerRight,
//                      width: SizeConfig.widthMultiplier*40,
//                      child:  Text(widget.totalSeats,textAlign: TextAlign.end,style: AppTheme.textStyle.heading1.copyWith(color: Colors.black,fontSize: AppFontSize.s14)),
//                    ),


                  ],),

                SizedBox(height: AppSize.medium,),



                Row(
                  children: <Widget>[
                    Container(
                      width: screenSize.width*.15,
                      child:  GestureDetector(
                          onTap: (){
                            AppRoutes.goto(context,UpdatePostATripScreen(widget.id));
                          },
                          child: Icon(Icons.mode_edit,size: AppSize.mediumLarge,color: AppTheme.primaryColor,)),
                    ),
                    Container(
                      width: screenSize.width*.15,
                      child:  GestureDetector(
                          onTap: (){
                            widget.onTap();
                          },
                          child: Icon(Icons.delete,size: AppSize.mediumLarge,color: AppTheme.primaryColor,)),
                    ),
                    SizedBox(width: screenSize.width*.15,),
                    Container(
                      margin: EdgeInsets.only(right: 5.0),
                      alignment: Alignment.centerRight,
                      width: screenSize.width*.45,
                      child:Text(widget.dateTime2,textAlign: TextAlign.start,style: AppTheme.textStyle.lightText.copyWith(color: Colors.grey,fontSize: AppFontSize.s12)),
                    ),
                  ],),


              ],),
            ),
          ),)

    );
  }
}
