import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class CustomAppBarWidget extends StatelessWidget {
  final String title;
  final List<Widget> actions;
  final GestureTapCallback callMenu;

  const CustomAppBarWidget({Key key, this.title, this.actions, this.callMenu,}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      width: screenSize.width,
      decoration: BoxDecoration(
        color: AppTheme.primaryColor
      ),
      child: Container(
        padding: EdgeInsets.only(top: AppSize.medium),
        height: AppSize.s70,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Constants.titlename == title || title == Constants.homeScreenTitle
                ? IconButton(
              icon: Icon(Icons.menu, color: Colors.white,size: AppSize.mediumLarge,),
              onPressed: (){
                callMenu();
              },
            )
                : IconButton(
              icon: Icon(Icons.arrow_back_ios, color: Colors.white,size: AppSize.mediumLarge),
              onPressed: (){
                AppRoutes.dismiss(context);
              },
            ),
            Container(
              alignment: Alignment.centerLeft,
              width: SizeConfig.widthMultiplier*80,
              child: Constants.titlename == title
                  ? SizedBox(width: 0.0,)
                  : Text(title.replaceAll('\n', ' '), style: AppTheme.textStyle.screenTitle.copyWith(fontWeight: FontWeight.w600, fontSize: AppFontSize.s20,color: Colors.white),),
            ),
          ],
        ),
      ),
    );
  }
}