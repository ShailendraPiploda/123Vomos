import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vamos/components/popup_widget.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

import 'app_alert_widget.dart';

enum AlertType {
  Success,
  Warning,
  Error,
  Internet,
  Locked,
}

void showAlert({@required BuildContext context, @required String message, bool barrierDismissible = false}) {
  showDialog(
    context: context,
    builder: (context) => AppAlert(
      positiveButtonOnTap: () {
        AppRoutes.dismiss(context);
      },
      alertType: AlertType.Success,
      text: message,
    ),
    barrierDismissible: barrierDismissible,
  );
}

void showLoginAlert({@required BuildContext context, @required String message, bool barrierDismissible = false}) {
  showDialog(
    context: context,
    builder: (context) => AppAlert(
      positiveButtonOnTap: () {
//        AppRoutes.goto(context, HomeScreen());
      },
      negativeButtonOnTap: (){

      },
      alertType: AlertType.Locked,
      text: message,
    ),
    barrierDismissible: barrierDismissible,
  );
}

void showErrorAlert({@required BuildContext context, String message, bool barrierDismissible = false}) {
  showDialog(
    context: context,
    builder: (context) => AppAlert(
      positiveButtonOnTap: () {},
      alertType: AlertType.Error,
      text: message,
    ),
    barrierDismissible: barrierDismissible,
  );
}

void showWarningAlert({@required BuildContext context, @required String message}) {
  showDialog(
    context: context,
    builder: (context) => AppAlert(
      positiveButtonOnTap: () {},
      alertType: AlertType.Warning,
      text: message,
    ),
    barrierDismissible: false,
  );
}

void showWIPAlert({@required BuildContext context}) {
  showDialog(
    context: context,
    builder: (context) => AppAlert(
      positiveButtonOnTap: () {},
      alertType: AlertType.Success,
      text: Constants.wip,
    ),
    barrierDismissible: false,
  );
}

void showEXITAlert({@required BuildContext context}) {
  showDialog(
    context: context,
    builder: (context) => AppAlert(
      positiveButtonOnTap: () {},
      alertType: AlertType.Warning,
      text: Constants.exit,
      negativeButtonOnTap: () {
        SystemNavigator.pop();
      },
      negativeButtonText: "Yes",
      positiveButtonText: "No",
    ),
    barrierDismissible: false,
  );
}

void showPopup(BuildContext context, Widget widget, String title,
    {BuildContext popupContext}) {
  Navigator.push(
      context,
      PopupWidget(
        top: AppSize.medium,
        left: AppSize.medium,
        right: AppSize.large,
        bottom: AppSize.extraLarge,
        child: widget,
      )
  );
}

