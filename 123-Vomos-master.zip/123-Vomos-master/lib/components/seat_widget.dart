import 'package:flutter/material.dart';
import 'package:vamos/screens/search_details_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_text_style.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class SeatWidget extends StatefulWidget {


  @override
  _SeatWidget createState() => new _SeatWidget();

}

class _SeatWidget extends State<SeatWidget> {
  @override
  Widget build(BuildContext context) {
    return Icon(Icons.event_seat,color: AppTheme.accentColor,);
  }
}
