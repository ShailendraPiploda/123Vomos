import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/screens/chatting_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/theme/theme_text_style.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/utils/size_config.dart';

class MessagesWidget extends StatefulWidget {
  String imageUrl, fcmToken;
  String chatUserName,
      dateTime,
      lastMessage,
      chatUserId,
      mainUserID,
      mainUserName,
  mainUserImage;

  GestureTapCallback onTap;

  MessagesWidget(
      {@required this.imageUrl,
      @required this.chatUserName,
      @required this.mainUserID,
      @required this.mainUserName,
      @required this.dateTime,
      @required this.lastMessage,
      @required this.chatUserId,
      @required this.fcmToken,
        @required this.mainUserImage});

  @override
  _MessagesWidget createState() => new _MessagesWidget();
}

class _MessagesWidget extends State<MessagesWidget> {


  @override
  Widget build(BuildContext context) {
    return  Container(
        width: double.maxFinite,
        margin: EdgeInsets.symmetric(
          horizontal: 5.0,
        ),
        child: Column(
          children: <Widget>[
            Container(
              child: InkWell(
                onTap: () {
                  AppRoutes.goto(
                      context,
                      ChattingScreen(
                        mainUserProfile: widget.mainUserImage,
                        chatUserId: widget.chatUserId,
                        fcmToken: widget.fcmToken,
                        mainUserID: widget.mainUserID,
                        mainUserName: widget.mainUserName,
                        chatUserName: widget.chatUserName,
                      ));
                },
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                            width: screenSize.width * .20,
                            child: Row(
                              children: <Widget>[
                                Card(
                                  shape: CircleBorder(
                                      side: BorderSide(
                                          color: Colors.grey, width: 0.5)),
                                  child: Material(
                                    elevation: 4.0,
                                    shape: CircleBorder(),
                                    clipBehavior: Clip.hardEdge,
                                    color: Colors.transparent,
                                    child: Container(
                                      child: widget.imageUrl!=null
                                          ? FadeInImage.assetNetwork(
                                              placeholder: Assets.avtar,
                                              image:widget.imageUrl,
                                              fit: BoxFit.cover,
                                            )
                                          : Image.asset(Assets.avtar),
                                      // fit: BoxFit.cover,
                                      width: SizeConfig.widthMultiplier * 15,
                                      height: SizeConfig.widthMultiplier * 15,
                                    ),
                                  ),
                                ),
                              ],
                            )),
                        Container(
                          width: screenSize.width * .70,
                          child: Column(
                            children: <Widget>[
                              Container(
                                width: screenSize.width * .70,
                                child: Text(
                                  widget.chatUserName,
                                  style: AppTheme.textStyle.lightHeading
                                      .copyWith(
                                          color: Colors.black,
                                          fontSize: AppFontSize.s16),
                                ),
                              ),
                              Container(
                                width: screenSize.width * .70,
                                child: Text(
                                  widget.lastMessage,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.grey,
                                      fontSize: AppFontSize.s16),
                                ),
                              ),
                              Container(
                                alignment: Alignment.centerRight,
                                width: screenSize.width * .70,
                                child: Text(
                                  widget.dateTime,
                                  style: AppTheme.textStyle.lightText.copyWith(
                                      color: Colors.grey,
                                      fontSize: AppFontSize.s12),
                                ),
                              ),
                              Container(
                                width: screenSize.width * .70,
                                margin: EdgeInsets.symmetric(vertical: 2.0),
                                height: 1.0,
                                color: Colors.grey,
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ));
  }

  @override
  void initState() {


  }



}
