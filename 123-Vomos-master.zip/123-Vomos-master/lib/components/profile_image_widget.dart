import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/ShareManager.dart';
import 'package:vamos/utils/app_assets.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';
import 'custom_app_bar_widget.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class ProfileImageWidget extends StatefulWidget{


  @override
  _ProfileImageWidget createState() => new _ProfileImageWidget();



}

class _ProfileImageWidget extends State<ProfileImageWidget>{
  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey();
  String userName="User Name";
  String userProfile="",userReview="0";
  var ratting=0.0;


  @override
  Widget build(BuildContext context) {

    ShareMananer.getUserDetails().then((userData){
      setState(() {
        userName=userData["first_name"].toString() +" "+ userData["last_name"].toString();
       String  img =userData["image"].toString();

       userProfile = img!="null"?API.baseProfileImageUrl+img:userData["facebook_image"].toString();
       userReview=userData["revieew"].toString();

       String damRatting = userData["avg_rating"].toString();

       if(damRatting=="null")
         {
           ratting=0.0;
         }
       else{
         ratting = double.parse(userData["avg_rating"].toString());
       }



      });

    });

    return   Container(
      margin: EdgeInsets.only(top: 20.0),
      child:Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(width: AppSize.small,),
          Card(
            shape: CircleBorder(side: BorderSide(
                color: Colors.grey, width: 0.5
            )),
            elevation: 12.0,
            child:   Material(
              elevation: 4.0,
              shape: CircleBorder(),
              clipBehavior: Clip.hardEdge,
              color: Colors.transparent,
              child:Container(
                child: !userProfile.isEmpty?FadeInImage.assetNetwork(placeholder: Assets.avtar,image: userProfile,fit: BoxFit.cover,): Image.asset(Assets.avtar),
               // fit: BoxFit.cover,
                width: SizeConfig.widthMultiplier*20,
                height: SizeConfig.widthMultiplier*20,

              ),
            ),
          ),
          SizedBox(width: AppSize.extraSmall,),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
              //  SizedBox(height: AppSize.large,),
                Text(userName,textAlign: TextAlign.left, style: AppTheme.textStyle.lightHeading.copyWith(color: Colors.white,fontSize: AppFontSize.s22),),
                SizedBox(height: AppSize.extraSmall,),
        Row(children: <Widget>[
            RatingBar(
                itemSize: 25.0,
                initialRating: ratting,
                minRating: 1,
                direction: Axis.horizontal,
                allowHalfRating: true,
                itemCount: 5,
                itemBuilder: (context, _) => Icon(
                  Icons.star,
                  color: AppTheme.primaryColor,

                )),
            Text(" (${userReview})", style: AppTheme.textStyle.lightText.copyWith(color: Colors.white,),),
        ],)

               // SizedBox(height: AppSize.small,),

              ],
            ),
          ),
//          Padding(
//            padding: EdgeInsets.fromLTRB(AppSize.small, 0.0, AppSize.small, 0.0),
//            child: Container(
//              height: 0.5,
//              decoration: BoxDecoration(
//                boxShadow: [
//                  BoxShadow(
//                    color: Colors.white,
//                    spreadRadius: 5.0,
//                    blurRadius: 35.0,
//                  ),
//                ],
//                borderRadius: BorderRadius.circular(15.0),
//                color: Colors.white30,
//              ),
//            ),
//          ),
        ],
      ),
    );;
  }

}
