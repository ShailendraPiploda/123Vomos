import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:vamos/screens/post_a_trips_next_map_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_constants.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/app_validator.dart';
import 'package:vamos/utils/size_config.dart';

class TripStopWidget extends StatefulWidget {

  String date,address,distance,duration,price;
  int index;
  TextEditingController controller;
  GestureTapCallback onTap;

  TripStopWidget(
      {@required this.date,
      @required this.address,
      @required this.duration,
        @required this.distance,
        @required this.price,
        @required this.index,
        @required this.onTap(),
        @required this.controller});

  @override
  _TripStopWidget createState() => new _TripStopWidget();
}

class _TripStopWidget extends State<TripStopWidget> {
 // TextEditingController controller=new TextEditingController();
  PostATripNextMapScreenState postATripNextMapScreen = new PostATripNextMapScreenState();

  @override
  Widget build(BuildContext context) {
    return  Column(children: <Widget>[
      Container(
        padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
              child: Row(children: <Widget>[
                Icon(Icons.transfer_within_a_station,color: AppTheme.primaryColor,),
                Text(Constants.nextStop)
              ],),
            ),

            Container(
              child: Row(

                children: <Widget>[
                  Icon(Icons.update,color: AppTheme.primaryColor,),
                  Text(widget.date)
                ],),
            ),
          ],
        ),
      ),

      SizedBox(height: AppSize.small,),

      Container(
        padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier*1),
        margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

        decoration:  BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(15),
            border: new Border.all(width: 1,color: Colors.grey[200])

        ),
        child:Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3,vertical: SizeConfig.widthMultiplier*3),

              width: SizeConfig.widthMultiplier*90,
              child: Text(widget.address,
    style: TextStyle(
    //  fontFamily: "WorkSansSemiBold",
    fontSize: 14.0,
    color: Colors.black),),),

            Container(
              width: double.maxFinite,
            //  margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*5,right: SizeConfig.widthMultiplier*5),

              padding: EdgeInsets.only(
                  left:1.0*SizeConfig.widthMultiplier,
                  right:1.0*SizeConfig.widthMultiplier),
              decoration:  BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(width: 1.0,color: Colors.grey[200])

              ),


              child: TextFormField(

               // readOnly: true,
                validator: (String value) {
                  return FieldValidator.validateEmptyCheck(value);
                },

                controller: widget.controller,
                keyboardType: TextInputType.number,
                textCapitalization:
                TextCapitalization.words,
                onChanged: (String value){

                  widget.onTap();


                },
    style: TextStyle(
    //  fontFamily: "WorkSansSemiBold",
    fontSize: 14.0,
    color: Colors.black),
                  decoration: InputDecoration(
                  labelText: Constants.stopTimeInMinutes,
                  labelStyle: TextStyle(color: AppTheme.primaryColor,fontSize: AppFontSize.textHint),
                  border: InputBorder.none,
                  icon: Icon(
                    Icons.timer,
                    color: AppTheme.primaryColor,
                    size:AppFontSize.textIcon,
                  ),

                ),
              ),
            ),
          ],
        ),
      ),
      SizedBox(height: AppSize.small,),
      Container(
        margin: EdgeInsets.only(left: SizeConfig.widthMultiplier*3,right: SizeConfig.widthMultiplier*3),

        padding: EdgeInsets.symmetric(horizontal:SizeConfig.widthMultiplier*3),
        child: Row(

          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(widget.distance),

            Text(widget.duration),

            Text(Constants.currancy+widget.price),
          ],
        ),
      ),

      SizedBox(height: AppSize.medium,),

    ],);
  }
}
