import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vamos/screens/messages_screen.dart';
import 'package:vamos/screens/personal_information_screen.dart';
import 'package:vamos/screens/post_a_trips_screen.dart';
import 'package:vamos/screens/search_trips_screen.dart';
import 'package:vamos/theme/theme.dart';
import 'package:vamos/utils/app_routes.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

class BottomDrawerWidgget extends StatelessWidget{
  bool isGoBack =false;

  BottomDrawerWidgget({this.isGoBack});


  @override
  Widget build(BuildContext context) {



    // TODO: implement build
    return Container(
      height: AppSize.xxL,
      padding: EdgeInsets.all(5.0),
      color: AppTheme.primaryColor,
      width: screenSize.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[

          InkWell(
              onTap: () {

                if(isGoBack!=null && isGoBack)
                  {
                    print(isGoBack);
                    AppRoutes.goto(context, MessagesScreen());
                  }
                else{
                  print(isGoBack);

                  AppRoutes.replace(context, MessagesScreen());
                }


              },
              child: Icon(Icons.chat,size: AppSize.mediumLarge,color: Colors.white,)),
          InkWell(
              onTap: () {

                if(isGoBack!=null && isGoBack)
                {
                  AppRoutes.goto(context, SearchTripsScreen());
                }
                else{
                  AppRoutes.replace(context, SearchTripsScreen());
                }

              },
              child: Icon(Icons.search,size: AppSize.mediumLarge,color: Colors.white,)),
          InkWell(
              onTap: () {


                if(isGoBack!=null && isGoBack)
                {
                  AppRoutes.goto(context, PostATripScreen());
                }
                else{
                  AppRoutes.replace(context, PostATripScreen());
                }

              },
              child: Icon(Icons.add_circle,size: AppSize.mediumLarge,color: Colors.white,)),
          InkWell(
              onTap: () {

                if(isGoBack!=null && isGoBack)
                {
                  AppRoutes.goto(context, PersonalInformationScreen());
                }
                else{
                  AppRoutes.replace(context, PersonalInformationScreen());
                }

              },
              child: Icon(Icons.person_outline,size: AppSize.mediumLarge,color: Colors.white,)),
        ],
      ),
    );
  }

}