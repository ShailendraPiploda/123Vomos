class API {
  static final String fcmServer = "AAAA3nlShpg:APA91bFTfNO88PR5Vwil3BDXEupjvZ5bDoJLJ9kqmsDxOC3enHfss5v68VUb3_xuw2h9iKeAtpHG-wQOqJOoVHYJFFhSvuVAyyXrCwhCXkpTJYMJGrJNv0EZknSLqlAzvDPpMDICDlrQ";
  static final String baseUrl = "https://www.123-vamos.com";
  static final String baseProfileImageUrl = "https://www.123-vamos.com/uploads/profile_pictures/preview/";
  static final String basevehiclemageUrl = "https://www.123-vamos.com/uploads/vehicle_pictures/preview/";
  static final String baseDocumentImageUrl = "https://www.123-vamos.com/uploads/identify_document/preview/";

  static final condition = baseUrl + "/terminos-y-condiciones";
  static final policy = baseUrl + "/política-de-confidencialidad";

  static final googleMapApiKey = "AIzaSyCNhQ-SprmfeORJpSnahFsjcEc5GAjQDTs";

  static final logOut = baseUrl + "/api-logout";
  static final getDeviceTokenID = baseUrl + "/api-getdevices";
  static final getCountry = baseUrl + "/get-country";
  static final signUp = baseUrl + "/api-registrate";
  static final login = baseUrl + "/api-login";
  static final forgotPassword = baseUrl + "/api-forgotpass";
  static final changePassword = baseUrl + "/api-changepass";
  static final profileUpdate = baseUrl + "/api-profile";
  static final sendOtp = baseUrl + "/api-verifyphone";
  static final verifyOtp = baseUrl + "/api-checkotp";
  static final getVehicleBrand = baseUrl + "/api-vehiclebrand";
  static final getVehicleModel = baseUrl + "/api-vehiclemodel";
  static final getVehicleColor = baseUrl + "/api-vehiclecolor";
  static final addVehicle = baseUrl + "/api-addvehicle";
  static final getVehicle = baseUrl + "/api-listvehicle";
  static final uploadDocument = baseUrl + "/api-uploaddocument";
  static final getUserDetails = baseUrl + "/api-getuser";
  static final getPhoneCode = baseUrl + "/api-getcountry";
  static final getSetting = baseUrl + "/api-getsetting";
  static final addtrip = baseUrl + "/api-addtrip";
  static final gettrip = baseUrl + "/api-triplist";
  static final addTrip2 = baseUrl + "/api-step2";
  static final getTripDetails = baseUrl + "/api-gettrip";
  static final getAllTripDetails = baseUrl + "/api-tripdetail";
  static final deleteTrip = baseUrl + "/api-postdelete";
  static final updateTrip = baseUrl + "/api-editpost";
  static final searchTrip = baseUrl + "/api-searchtrip";
  static final checktrip = baseUrl + "/api-checktrip";
  static final paymentUrl = "https://www.pagoagil.net/onestep";
  static final bookingRequest = baseUrl + "/api-bookingrequest";
  static final getCurrentReservation = baseUrl + "/api-userbooked";
  static final acceptRequestFromDriver = baseUrl + "/api-acceptreqfromdriver";
  static final rejectRequestFromDriver = baseUrl + "/api-rejectreqfromdriver";
  static final getCompleteUserTrip = baseUrl + "/api-usercompletedtrip";
  static final getReasonCategory = baseUrl + "/api-reasoncategory";
  static final rejectRequestFromUser = baseUrl + "/api-rejectreqfromuser";
  static final getReservationCancel = baseUrl + "/api-useralreadycancelled";
  static final submitFeedback = baseUrl + "/api-submitrating";
  static final saveBankDetails = baseUrl + "/api-createbankdetails";
  static final getBankDetails = baseUrl + "/api-getbankdetail";
  static final socialsignin = baseUrl + "/api-socialsignin";

}
