import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:vamos/utils/app_size.dart';
import 'package:vamos/utils/size_config.dart';

@immutable
class AppTextStyle {
  static const TextDecoration underline = TextDecoration.underline;
  static const TextDecoration lineThrough = TextDecoration.lineThrough;

  static const String _regular = "WorkSansRegular";
  static const String _bold = "WorkSansBold";
  static const String _light = "WorkSansLight";
  static const String _medium = "WorkSansMedium";
  static const String _semiBold = "WorkSansSemiBold";
  static const String _helena = "Helena";

  final TextStyle heading1;
  final TextStyle alertText;
  final TextStyle alertTitle;
  final TextStyle hintText;
  final TextStyle errorStyle;
  final TextStyle lightHeading;
  final TextStyle lightText;
  final TextStyle timerTextActive;
  final TextStyle timerTextInActive;
  final TextStyle buttonText;
  final TextStyle screenTitle;

  AppTextStyle({
    this.screenTitle,
    this.timerTextActive,
    this.timerTextInActive,
    this.heading1,
    this.lightHeading,
    this.alertText,
    this.alertTitle,
    this.hintText,
    this.errorStyle,
    this.lightText,
    this.buttonText,
  });

  AppTextStyle.getStyle()
      :
        screenTitle = new TextStyle(
          fontFamily: _bold,
          fontSize: AppFontSize.s20,
          color: Colors.white,
          inherit: true,
        ),
        buttonText = TextStyle(
          fontFamily: _bold,
          fontSize: AppFontSize.s18,
          color: Colors.white,
          fontWeight: FontWeight.w600,
          inherit: false,
        ),
        timerTextActive = new TextStyle(
          fontFamily: _bold,
          fontSize: AppFontSize.s16,
          color: Colors.black,
          inherit: false,
        ),
        timerTextInActive = new TextStyle(
          fontFamily: _bold,
          fontSize: AppFontSize.s16,
          color: Colors.black,
          decoration: underline,
          inherit: false,
        ),
        lightHeading = new TextStyle(
          fontFamily: _semiBold,
          fontSize: AppFontSize.s26,
          color: Colors.black,
          inherit: false,
        ),

        lightText = new TextStyle(
          fontFamily: _regular,
          fontSize: AppFontSize.s16,
          color: Colors.white,
          inherit: true,
        ),
        heading1 = new TextStyle(
          fontFamily: _regular,
          fontSize: AppFontSize.s20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
          inherit: false,
        ),
        alertTitle = new TextStyle(
          fontFamily: _regular,
          fontSize: AppFontSize.s18,
          fontWeight: FontWeight.bold,
          color: Colors.grey[400],
          inherit: false,
        ),
        alertText = new TextStyle(
          fontFamily: _light,
          fontSize: AppFontSize.s16,
          color: Colors.black,
          inherit: false,
        ),
        hintText = new TextStyle(
          fontFamily: _regular,
          fontSize: AppFontSize.s16,
          color: Colors.white,
          inherit: false,
        ),
        errorStyle = new TextStyle(
          fontFamily: _medium,
          fontSize: AppFontSize.s10,
          color: Colors.red,
          inherit: false,
        );
}
