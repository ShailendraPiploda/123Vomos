import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vamos/api/api.dart';
import 'package:vamos/components/display_alert_widget.dart';
import 'package:vamos/screens/welcome_screen.dart';

import 'app_routes.dart';

class ShareMananer {
  static void setLoginDetails(
      String id,
      String user_type,
      String reg_type,
      String google_id,
      String facebook_id,
      String user_name,
      String first_name,
      String last_name,
      String gender,
      String email,
      String google_email,
      String facebook_email,
      String email_varified,
      String image,
      String google_image,
      String facebook_image,
      String driving_id,
      String drive_frontimage,
      String drive_backimage,
      String drive_image_verification,
      String driving_cancle_cause,
      String driving_exp,
      String phone_code,
      String phone,
      String phone_verification,
      String birth_year,
      String bio,
      String identity_document_verified,
      String profile_image_status,
      String status,
      String device_type,
      String device_token,
      String added_date,
      String update_date,
      String avg_rating,
      String revieew,
      bool isLogin) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('id', id);
    await prefs.setString('user_type', user_type);
    await prefs.setString('reg_type', reg_type);
    await prefs.setString('google_id', google_id);
    await prefs.setString('facebook_id', facebook_id);
    await prefs.setString('user_name', user_name);
    await prefs.setString('first_name', first_name);
    await prefs.setString('last_name', last_name);
    await prefs.setString('gender', gender);
    await prefs.setString('email', email);
    await prefs.setString('google_email', google_email);
    await prefs.setString('facebook_email', facebook_email);
    await prefs.setString('email_varified', email_varified);
    await prefs.setString('image', image);
    await prefs.setString('google_image', google_image);
    await prefs.setString('facebook_image', facebook_image);
    await prefs.setString('driving_id', driving_id);
    await prefs.setString('drive_frontimage', drive_frontimage);
    await prefs.setString('drive_backimage', drive_backimage);
    await prefs.setString('drive_image_verification', drive_image_verification);
    await prefs.setString('driving_cancle_cause', driving_cancle_cause);
    await prefs.setString('driving_exp', driving_exp);
    await prefs.setString('phone_code', phone_code);
    await prefs.setString('phone', phone);
    await prefs.setString('phone_verification', phone_verification);
    await prefs.setString('birth_year', birth_year);
    await prefs.setString('bio', bio);
    await prefs.setString('identity_document_verified', identity_document_verified);
    await prefs.setString('profile_image_status', profile_image_status);
    await prefs.setString('status', status);
    await prefs.setString('device_type', device_type);
    await prefs.setString('device_token', device_token);
    await prefs.setString('added_date', added_date);
    await prefs.setString('driving_cancle_cause', update_date);
    await prefs.setString('avg_rating', avg_rating);
    await prefs.setString('revieew', revieew);
    await prefs.setBool('login', isLogin);


  }

  static Future<String> isLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    bool loginState = prefs.get("login") ?? false;

    if (loginState) {
      String user = prefs.get("user_type");

      if (user == "viewer") {
        return user;
      } else {
        return user;
      }
    }

    return "null";
  }

  static LogOut(BuildContext context) async {

    final FirebaseMessaging _fcm = FirebaseMessaging();
    String fcmToken="";
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID=prefs.get("id");
    FirebaseAuth auth = FirebaseAuth.instance;

    Firestore.instance.collection("users").document(userID).updateData({'isOnline':false});

   // prefs.clear();

    String device = "";

    _fcm.getToken().then((String token)async {
      assert(token != null);
      print(token);


        fcmToken=token;


      if (Platform.isAndroid) {

        device = "Android";
      } else if (Platform.isIOS) {
        device = "IOS";

      }

      final uri = API.logOut;
      final headers = {
        HttpHeaders.contentTypeHeader: 'application/x-www-form-urlencoded',
      };
      Map<String, dynamic> body = {
        "device_type": device,
        "device_token": fcmToken,

      };
      final encoding = Encoding.getByName('utf-8');


      bool trustSelfSigned = true;
      HttpClient httpClient = new HttpClient()
        ..badCertificateCallback =
        ((X509Certificate cert, String host, int port) => trustSelfSigned);
      IOClient ioClient = new IOClient(httpClient);
      Response response = await ioClient.post(
        uri,
        headers: headers,
        body: body,
        encoding: encoding,
      );

      int statusCode = response.statusCode;
      final data = json.decode(response.body);

      print(body.toString());
      print(response.body);

      if (statusCode == 200) {
        if (data["status"] == "true") {
          showDisplayAllert(context:context,isSucces: true,message: (data["message"]));

          prefs.clear();
          AppRoutes.dismiss(context);
          AppRoutes.makeFirst(context, WelcomeScreeen());



        } else {

          print("1");
          String dataString = data["message"].toString();
          dataString = dataString.substring(dataString.indexOf(":"),dataString.length).replaceAll(":", "").replaceAll("{", "").replaceAll("}","").replaceAll("[","").replaceAll("]","");
          showDisplayAllert(context:context,isSucces: false,message:dataString);
        }
      } else {
        print("2");
        showDisplayAllert(context:context,isSucces: false,message: (data["message"]));

      }


    });


  }

  static Future<Map<String, String>> getUserDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    Map<String, String> user = new Map<String, String>();
    user["id"] = prefs.get("id");
    user["user_type"] = prefs.get("user_type");
    user["reg_type"] = prefs.get("reg_type");
    user["google_id"] = prefs.get("google_id");
    user["facebook_id"] = prefs.get("facebook_id");
    user["user_name"] = prefs.get("user_name");
    user["first_name"] = prefs.get("first_name");
    user["last_name"] = prefs.get("last_name");
    user["gender"] = prefs.get("gender");
    user["email"] = prefs.get("email");
    user["google_email"] = prefs.get("google_email");
    user["facebook_email"] = prefs.get("facebook_email");
    user["email_varified"] = prefs.get("email_varified");
    user["image"] = prefs.get("image");
    user["google_image"] = prefs.get("google_image");
    user["facebook_image"] = prefs.get("facebook_image");
    user["drive_frontimage"] = prefs.get("drive_frontimage");
    user["drive_backimage"] = prefs.get("drive_backimage");
    user["drive_image_verification"] = prefs.get("drive_image_verification");
    user["driving_cancle_cause"] = prefs.get("driving_cancle_cause");
    user["driving_exp"] = prefs.get("driving_exp");
    user["phone_code"] = prefs.get("phone_code");
    user["phone"] = prefs.get("phone");
    user["phone_verify_code"] = prefs.get("phone_verify_code");
    user["phone_verification"] = prefs.get("phone_verification");
    user["birth_year"] = prefs.get("birth_year");
    user["reset_password_token"] = prefs.get("reset_password_token");
    user["bio"] = prefs.get("bio");
    user["identity_document_verified"] = prefs.get("identity_document_verified");
    user["profile_image_status"] = prefs.get("profile_image_status");
    user["status"] = prefs.get("status");
    user["device_type"] = prefs.get("device_type");
    user["device_token"] = prefs.get("device_token");
    user["added_date"] = prefs.get("added_date");
    user["update_date"] = prefs.get("update_date");
    user["avg_rating"] = prefs.get("avg_rating");
    user["revieew"] = prefs.get("revieew");




    return user;
  }


  static UpdatePhoneVerificationStatus(String status)async{

    SharedPreferences prefs = await SharedPreferences.getInstance();

    await prefs.setString('phone_verification', status);

  }

  static updateDriverData(String status)async{

    SharedPreferences prefs = await SharedPreferences.getInstance();

    await prefs.setString('drive_image_verification', status);

  }


}
