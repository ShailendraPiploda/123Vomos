import 'package:flutter/material.dart';
import 'package:vamos/utils/size_config.dart';

Size screenSize;
double screenHeightConstant;
double fontConstant;

void appSizeInit(context) {
  screenSize = MediaQuery.of(context).size;
//  screenHeightConstant = screenSize.height * 0.0188;
  screenHeightConstant = screenSize.width * 0.031;
//  screenHeightConstant = (screenSize.height / screenSize.width) * 7.5;
  fontConstant = screenHeightConstant / 12.5;

  print(
      "\n-----------------Device-----------------\n\tHeight : ${screenSize.height.round()}\n\tWidth : ${screenSize.width.round()}\nscreenHeightConstant:${screenHeightConstant.round()}\nfontConstant:${fontConstant.round()}\n--------------------");
}


