import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vamos/components/alert_widget.dart';
import 'package:vamos/components/app_alert_widget.dart';
import 'package:vamos/theme/theme.dart';
import 'app_constants.dart';
import 'app_routes.dart';

void printLog(log) {
//  print(log);
}

bool isFormValid(key) {
  final form = key.currentState;
  if (form.validate()) {
    form.save();
    print('isFormValid:true');

    return true;
  }
  print('isFormValid:false');

  return false;
}

String parseFormatDate(String date) {
  return formatterFddMMMyyyy.format(DateTime.tryParse(date) ?? DateTime.now());
}

backButtonClick({
  @required BuildContext context,
}) {
  print("Back Clicked!");
  showEXITAlert(context: context);
}

Future<bool> isConnected({
  @required BuildContext context,
}) async {
  AppRoutes.showInternetLoader(context);

  DateTime startTime = DateTime.now();
  DateTime endTime = DateTime.now();

  try {
    bool result = false;

    await InternetAddress.lookup('google.com').timeout(Duration(seconds: 30), onTimeout: () {
      result = false;
    }).then((value) async {
      result = value.isNotEmpty && value[0].rawAddress.isNotEmpty;
    });

    if (result) {
      print('isConnected:true');

      endTime = DateTime.now();

      print("Time Taken by isConnected :  ${endTime.difference(startTime).inMilliseconds} Milliseconds");

      AppRoutes.dismissInternetLoader(context);

      return true;
    }
  } on SocketException catch (_) {
    print('isConnected:false\n $_');
  }
  endTime = DateTime.now();

  print("Time Taken by isConnected :  ${endTime.difference(startTime).inMilliseconds} Milliseconds");

  AppRoutes.dismissInternetLoader(context);

  return false;
}

Future<Null> performIfConnected({
  @required GestureTapCallback callBack,
  @required BuildContext context,
  bool exitOption = false,
}) async {
  print("performIfConnected ------>Called ");

  if (await isConnected(context: context)) {
    print("performIfConnected ------>Connected----->callBack called ");
    callBack();
  } else {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AppAlert(
        positiveButtonOnTap: () async {
          print("performIfConnected ------>Not Connected----->Retry ");
          performIfConnected(
            callBack: callBack,
            context: context,
            exitOption: exitOption,
          );
        },
        positiveButtonText: "Retry",
        negativeButtonOnTap: exitOption
            ? () async {
          print("performIfConnected ------>Not Connected----->Exit ");

          SystemNavigator.pop();
        }
            : () {
          print("performIfConnected ------>Not Connected----->Pop ");
        },
        negativeButtonText: exitOption ? "Exit" : "Cancel",
        alertType: AlertType.Internet,
        text: Constants.notConnected,
      ),
    );
  }
}

showTimeOutAlert({
  @required BuildContext context,
  bool popFirst = false,
}) async {
  print("performIfConnected ------>Called ");
  if (popFirst) AppRoutes.dismiss(context);
  showWarningAlert(context: context, message: Constants.timeOutMessage);
}

showSnackBar({
  @required String title,
  @required GlobalKey<ScaffoldState> scaffoldKey,
  Color color,
  int milliseconds = 800,
}) {
  scaffoldKey.currentState?.showSnackBar(
    new SnackBar(
      backgroundColor: color ?? Colors.red,
      duration: Duration(milliseconds: milliseconds),
      content: Container(
        height: 50.0,
        child: Center(
          child: new Text(
            title,
            style: AppTheme.textStyle.lightText.copyWith(color: Colors.white),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    ),
  );
}
